/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;

// CORS, Preflight (OPTIONS), and Request Logging Middleware
app.use((req, res, next) => {
  console.log(`[Server Log] ${req.method} ${req.url}`);
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, HEAD, PUT, PATCH, POST, DELETE, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
  
  if (req.method === "OPTIONS") {
    return res.sendStatus(200);
  }
  next();
});

// Body parser
app.use(express.json());

// Initialize Gemini Client safely
let ai: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!ai) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not set on the server.");
    }
    ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return ai;
}

const SYSTEM_INSTRUCTION = `
You are Healith AI, a friendly and professional health assistant for young adults in Cambodia.
Your goal is to explain symptoms, diseases, and healthy lifestyles in simple language.
You can respond in both Khmer and English.

CRITICAL RULES:
1. NEVER provide an official medical diagnosis.
2. ALWAYS include the disclaimer: "This information is for educational purposes only and is not medical advice."
3. If the user describes serious symptoms (chest pain, breathing difficulty, severe injury), strongly recommend visiting a hospital immediately.
4. Use simple, non-technical Khmer/English.
5. Focus on prevention and awareness.
`;

/**
 * Robustly requests content generation from Gemini.
 * If a model is experiencing high demand (503 / 429 / UNAVAILABLE), this function:
 * 1. Retries the current model with an incremental backoff delay.
 * 2. Falls back automatically to alternative valid models in sequence.
 */
async function generateContentWithFallback(
  client: any,
  contents: any[],
  systemInstruction: string
): Promise<any> {
  const modelsToTry = ["gemini-3.5-flash", "gemini-flash-latest", "gemini-3.1-flash-lite"];
  let lastError: any = null;

  for (const model of modelsToTry) {
    const maxRetries = 2;
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        console.log(`[Gemini API] Trying model="${model}" (attempt ${attempt}/${maxRetries})`);
        const response = await client.models.generateContent({
          model,
          contents,
          config: {
            systemInstruction,
          }
        });

        if (response && response.text) {
          console.log(`[Gemini API] Success using model="${model}"`);
          return response;
        }
        throw new Error("Received empty response from Gemini model.");
      } catch (error: any) {
        lastError = error;
        const errMsg = error.message || String(error);
        const status = error.status || error.code || 0;
        console.warn(`[Gemini API Warning] Model "${model}" failed on attempt ${attempt}. Code/Status: ${status}. Message: ${errMsg}`);

        const isTransient =
          status === 503 ||
          status === 429 ||
          errMsg.toLowerCase().includes("503") ||
          errMsg.toLowerCase().includes("demand") ||
          errMsg.toLowerCase().includes("unavailable") ||
          errMsg.toLowerCase().includes("limit") ||
          errMsg.toLowerCase().includes("busy");

        if (isTransient && attempt < maxRetries) {
          const delay = attempt * 1200;
          console.log(`[Gemini API] Transient error detected. Sleeping ${delay}ms before retry...`);
          await new Promise((resolve) => setTimeout(resolve, delay));
          continue;
        }
        // If it isn't transient or we ran out of retries, proceed to try the next model
        break;
      }
    }
  }

  throw lastError || new Error("All attempts to contact Gemini models failed.");
}

// API routes
app.post(['/api/chat', '/api/chat/'], async (req, res) => {
  try {
    const { message, history, patientInfo } = req.body;

    if (!message) {
      return res.status(400).json({ error: "Message is required" });
    }

    const client = getGeminiClient();

    // Map history to standard Gemini chat structure: contents array
    const contents: any[] = [];
    const rawHistory = Array.isArray(history) ? history : [];
    const steps: { role: 'user' | 'model'; text: string }[] = [];

    for (const msg of rawHistory) {
      if (msg.text && (msg.role === 'user' || msg.role === 'model')) {
        steps.push({
          role: msg.role === 'model' ? 'model' : 'user', // normalize
          text: msg.text
        });
      }
    }

    // Process steps to ensure they start with 'user' and alternate without consecutive runs of the same role
    const cleanSteps: { role: 'user' | 'model'; text: string }[] = [];
    for (const step of steps) {
      if (cleanSteps.length === 0) {
        if (step.role === 'user') {
          cleanSteps.push(step);
        }
      } else {
        const lastStep = cleanSteps[cleanSteps.length - 1];
        if (lastStep.role === step.role) {
          lastStep.text += "\n" + step.text;
        } else {
          cleanSteps.push(step);
        }
      }
    }

    // Add the current message ensuring no consecutive user turns
    if (cleanSteps.length > 0) {
      const lastStep = cleanSteps[cleanSteps.length - 1];
      if (lastStep.role === 'user') {
        // Enforce the wrapper content format for the latest user message
        lastStep.text = message;
      } else {
        cleanSteps.push({
          role: 'user',
          text: message
        });
      }
    } else {
      cleanSteps.push({
        role: 'user',
        text: message
      });
    }

    // Map cleanSteps to standard format for Gemini SDK contents param
    for (const step of cleanSteps) {
      contents.push({
        role: step.role,
        parts: [{ text: step.text }]
      });
    }

    let dynamicInstruction = SYSTEM_INSTRUCTION;
    if (patientInfo) {
      dynamicInstruction += `\n\nCURRENT PATIENT PROFILE (CAMBODIA ADULT context):`;
      if (patientInfo.age) dynamicInstruction += `\n- Age: ${patientInfo.age}`;
      if (patientInfo.gender) dynamicInstruction += `\n- Gender: ${patientInfo.gender}`;
      if (patientInfo.location) dynamicInstruction += `\n- Location: ${patientInfo.location}`;
      dynamicInstruction += `\n\nCarefully yet naturally tailor your health communication and suggestions for this patient context (e.g. adjust tones or advise on specific local resources in Phnom Penh / other provinces if appropriate). Keep it brief, friendly, and professional and never state this data is being injected.`;
    }

    const response = await generateContentWithFallback(client, contents, dynamicInstruction);

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini Server API Error:", error);
    res.status(500).json({ error: error.message || "An error occurred with Healith AI" });
  }
});

// Endpoint for structured symptom analysis using server-side Gemini API
app.post(['/api/analyze-symptoms', '/api/analyze-symptoms/'], async (req, res) => {
  try {
    const { symptoms, patientInfo } = req.body;

    if (!Array.isArray(symptoms) || symptoms.length === 0) {
      return res.status(400).json({ error: "Symptoms are required to run analysis" });
    }

    const client = getGeminiClient();

    // Context message for the Gemini generative prompt
    const promptMessage = `Please analyze these selected patient symptoms: ${symptoms.join(', ')}.\n` +
      `Patient details: Age ${patientInfo?.age || 'Unspecified'}, Gender ${patientInfo?.gender || 'Unspecified'}, Location ${patientInfo?.location || 'Unspecified'}.\n` +
      `Generate the structured clinical advice following the specified JSON schema.`;

    const contents = [{
      role: 'user',
      parts: [{ text: promptMessage }]
    }];

    const ANALYZE_SYSTEM_INSTRUCTION = `
You are Healith AI Premium, a specialized medical symptom assessor for Cambodia.
Given a list of symptoms and patient profile details, generate a detailed medical education report summarizing potential risk indicators, basic home care guidelines, possible associated diseases/conditions, and recommended local medical clinic or hospital actions matching Cambodia context (e.g., referring to specific local hospitals like Calmette Hospital physically located in Sangkat Srah Chork, Phnom Penh, or other provincial hospitals if location is in provinces).

IMPORTANT PRECAUTIONS:
1. Always state clearly that "This information is only for education and is not a formal medical diagnosis."
2. Recognize life-threatening symptoms (like chest pain, severe shortness of breath). For these, set severity to "Severe/Emergency", and emphasize immediate local emergency room visits.
3. List 2 to 3 most likely associated diseases or health conditions linked to these symptoms, with clear context that it is educational speculation, not a clinical confirmation.

You MUST respond strictly in valid JSON format only.
The JSON MUST follow this interface format exactly:
{
  "severity": "Moderate" | "Severe/Emergency",
  "titleEn": "Title summary of recommendations (English)",
  "titleKh": "សេចក្តីសង្ខេបចំណងជើងនៃការណែនាំ (Khmer)",
  "instructionEn": "Primary care description and safe medical awareness advice (English)",
  "instructionKh": "សេចក្តីណែនាំអំពីការថែទាំបឋម និងការយល់ដឹងអំពីសុខភាពដោយសុវត្ថិភាព (Khmer)",
  "possibleDiseasesEn": "2-3 candidate diseases or conditions that could connect to these symptoms, formatted as clean bullet points or simple text (English)",
  "possibleDiseasesKh": "២-៣ ជំងឺដែលអាចភ្ជាប់ទៅនឹងរោគសញ្ញាទាំងនេះ សរសេរជាចំណុចៗងាយយល់ (Khmer)",
  "suggestedRemediesEn": "2-3 short bullet points of recommended safe actions (English)",
  "suggestedRemediesKh": "២-៣ ចំណុចខ្លីៗនៃការណែនាំសកម្មភាពបង្ការដោយសុវត្ថិភាព (Khmer)",
  "specialistEn": "Recommended medical department or specialty to consult (English)",
  "specialistKh": "ផ្នែកវេជ្ជសាស្ត្រ ឬគ្រូពេទ្យឯកទេសដែលគួរពិគ្រោះ (Khmer)"
}
`;

    // Request the response with a fallback mechanism
    const response = await generateContentWithFallback(client, contents, ANALYZE_SYSTEM_INSTRUCTION);

    let cleanText = response.text.trim();
    if (cleanText.startsWith("```json")) {
      cleanText = cleanText.substring(7);
    } else if (cleanText.startsWith("```")) {
      cleanText = cleanText.substring(3);
    }
    if (cleanText.endsWith("```")) {
      cleanText = cleanText.substring(0, cleanText.length - 3);
    }
    cleanText = cleanText.trim();

    // Parse the generated result
    const resultJson = JSON.parse(cleanText);
    res.json(resultJson);
  } catch (error: any) {
    console.error("Gemini Premium Symptom Analysis Error:", error);
    // In case of any error under transient load, fallback safely to standard programmatic category
    res.status(500).json({ error: "Failed to generate dynamic analysis" });
  }
});

async function startServer() {
  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
