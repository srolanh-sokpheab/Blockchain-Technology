/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type Language = 'en' | 'kh';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (en: string, kh: string) => string;
  largeFont: boolean;
  setLargeFont: (val: boolean) => void;
  highContrast: boolean;
  setHighContrast: (val: boolean) => void;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>(() => {
    return (localStorage.getItem('healith_lang') as Language) || 'en';
  });
  const [largeFont, setLargeFontState] = useState<boolean>(() => {
    return localStorage.getItem('healith_large_font') === 'true';
  });
  const [highContrast, setHighContrastState] = useState<boolean>(() => {
    return localStorage.getItem('healith_high_contrast') === 'true';
  });

  const setLanguageAndSave = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('healith_lang', lang);
  };

  const setLargeFont = (val: boolean) => {
    setLargeFontState(val);
    localStorage.setItem('healith_large_font', String(val));
  };

  const setHighContrast = (val: boolean) => {
    setHighContrastState(val);
    localStorage.setItem('healith_high_contrast', String(val));
  };

  const t = (en: string, kh: string) => (language === 'en' ? en : kh);

  // Sync classes to html elem
  useEffect(() => {
    if (largeFont) {
      document.documentElement.classList.add('large-font');
    } else {
      document.documentElement.classList.remove('large-font');
    }
  }, [largeFont]);

  useEffect(() => {
    if (highContrast) {
      document.documentElement.classList.add('high-contrast');
    } else {
      document.documentElement.classList.remove('high-contrast');
    }
  }, [highContrast]);

  return (
    <LanguageContext.Provider value={{ 
      language, 
      setLanguage: setLanguageAndSave, 
      t, 
      largeFont, 
      setLargeFont, 
      highContrast, 
      setHighContrast 
    }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
