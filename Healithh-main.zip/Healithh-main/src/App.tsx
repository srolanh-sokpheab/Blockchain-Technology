/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { LanguageProvider } from './context/LanguageContext';
import Layout from './components/Layout';
import HomePage from './pages/HomePage';
import ChatPage from './pages/ChatPage';
import DictionaryPage from './pages/DictionaryPage';
import HospitalsPage from './pages/HospitalsPage';
import ActivitiesPage from './pages/ActivitiesPage';

export default function App() {
  return (
    <LanguageProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<HomePage />} />
            <Route path="chat" element={<ChatPage />} />
            <Route path="dictionary" element={<DictionaryPage />} />
            <Route path="hospitals" element={<HospitalsPage />} />
            <Route path="activities" element={<ActivitiesPage />} />
            <Route path="symptom" element={<ActivitiesPage />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </LanguageProvider>
  );
}
