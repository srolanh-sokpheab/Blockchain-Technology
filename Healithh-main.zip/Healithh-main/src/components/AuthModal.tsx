/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, User, Mail, Lock, LogIn, UserPlus, LogOut, CheckCircle, ShieldAlert, Shield, Globe, Sun, ZoomIn, Eye } from 'lucide-react';
import { supabaseService } from '../services/supabaseService';
import { useLanguage } from '../context/LanguageContext';
import { cn } from '../utils';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthSuccess?: () => void;
}

export default function AuthModal({ isOpen, onClose, onAuthSuccess }: AuthModalProps) {
  const { 
    t, 
    language, 
    setLanguage, 
    largeFont, 
    setLargeFont, 
    highContrast, 
    setHighContrast 
  } = useLanguage();
  const [isRegister, setIsRegister] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const [currentUser, setCurrentUser] = useState<{ id: string; name: string; email: string } | null>(null);
  const [isEditingAccount, setIsEditingAccount] = useState(false);
  const [editName, setEditName] = useState('');
  const [editEmail, setEditEmail] = useState('');

  const [age, setAge] = useState('26 years');
  const [gender, setGender] = useState('Female');
  const [location, setLocation] = useState('Sangkat Srah Chork, Phnom Penh');

  useEffect(() => {
    const user = supabaseService.getCurrentUser();
    setCurrentUser(user);
    if (user) {
      const suf = user.id || 'demo_tester';
      setAge(localStorage.getItem(`healith_patient_age_${suf}`) || '26 years');
      setGender(localStorage.getItem(`healith_patient_gender_${suf}`) || 'Female');
      setLocation(localStorage.getItem(`healith_patient_location_${suf}`) || 'Sangkat Srah Chork, Phnom Penh');
      setEditName(user.name);
      setEditEmail(user.email);
    }
    setIsEditingAccount(false);
  }, [isOpen]);

  const handleSaveAccountInfo = async () => {
    setError('');
    setSuccessMsg('');
    if (!editName.trim() || !editEmail.trim()) {
      setError(t('Name and Email cannot be empty.', 'ឈ្មោះ និងអ៊ីមែលមិនអាចទទេ។'));
      return;
    }

    setLoading(true);
    try {
      const res = await supabaseService.updateUser(editName, editEmail);
      if (res.success) {
        setSuccessMsg(t('Account info updated successfully!', 'ព័ត៌មានគណនីត្រូវបានផ្លាស់ប្តូរដោយជោគជ័យ!'));
        const user = supabaseService.getCurrentUser();
        setCurrentUser(user);
        setIsEditingAccount(false);
        if (onAuthSuccess) onAuthSuccess();
      } else {
        setError(res.error || t('Failed to update account.', 'បរាជ័យក្នុងការកែសម្រួលព័ត៌មានគណនី។'));
      }
    } catch (err: any) {
      setError(err.message || t('Something went wrong.', 'មានបញ្ហាអ្វីមួយកើតឡើង។'));
    } finally {
      setLoading(false);
    }
  };

  const handleSuubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');
    setLoading(true);

    if (!email.trim() || !password.trim()) {
      setError(t('Please fill in all required fields.', 'សូមបំពេញព័ត៌មានដែលចាំបាច់ទាំងអស់។'));
      setLoading(false);
      return;
    }

    if (isRegister && !name.trim()) {
      setError(t('Please provide your name.', 'សូមបញ្ចូលឈ្មោះរបស់អ្នក។'));
      setLoading(false);
      return;
    }

    try {
      if (isRegister) {
        const res = await supabaseService.signUp(name, email, password);
        if (res.success) {
          setSuccessMsg(t('Registration successful! You are logged in.', 'ការចុះឈ្មោះបានជោគជ័យ! អ្នកបានចូលគណនីរួចហើយ។'));
          setTimeout(() => {
            if (onAuthSuccess) onAuthSuccess();
            onClose();
            // Reset fields
            setName('');
            setEmail('');
            setPassword('');
          }, 1500);
        } else {
          setError(res.error || t('Signup failed', 'ការចុះឈ្មោះបានបរាជ័យ'));
        }
      } else {
        const res = await supabaseService.signIn(email, password);
        if (res.success) {
          setSuccessMsg(t('Logged in successfully! Welcome back.', 'បានចូលគណនីដោយជោគជ័យ! សូមស្វាគមន៍មកវិញ។'));
          setTimeout(() => {
            if (onAuthSuccess) onAuthSuccess();
            onClose();
            // Reset fields
            setEmail('');
            setPassword('');
          }, 1500);
        } else {
          setError(res.error || t('Login failed', 'ការចូលគណនីបានបរាជ័យ'));
        }
      }
    } catch (err: any) {
      setError(err.message || t('Something went wrong. Please try again.', 'មានបញ្ហាអ្វីមួយកើតឡើង។ សូមព្យាយាមម្តងទៀត។'));
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await supabaseService.signOut();
    setSuccessMsg(t('Logged out successfully.', 'បានចាកចេញពីគណនីដោយជោគជ័យ។'));
    setTimeout(() => {
      if (onAuthSuccess) onAuthSuccess();
      onClose();
      setSuccessMsg('');
    }, 1200);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
          {/* Backdrop overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          />

          {/* Dialog Body */}
          <motion.div
            initial={{ y: "100%", opacity: 0.5 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: "100%", opacity: 0.5 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="relative w-full sm:max-w-md bg-white rounded-t-[36px] sm:rounded-[40px] overflow-hidden shadow-2xl z-10 border border-[#F2E4E9] flex flex-col max-h-[90vh]"
          >
            {/* Header branding */}
            <div className="p-6 border-b border-[#F2E4E9] flex items-center justify-between bg-gradient-to-r from-[#FFFAFC] to-white">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-pink-100 flex items-center justify-center text-primary shadow-sm">
                  {currentUser ? <User className="w-5 h-5 fill-primary text-white" /> : <Lock className="w-5 h-5" />}
                </div>
                <div>
                  <h3 className="font-serif font-bold text-primary-dark text-lg leading-none">
                    {currentUser ? t('User profile', 'ព័ត៌មានផ្ទាល់ខ្លួន') : (isRegister ? t('Create Account', 'បង្កើតគណនីថ្មី') : t('Sign In', 'ចូលប្រព័ន្ធ'))}
                  </h3>
                  <p className="text-[10px] text-[#8E6D7A] font-semibold tracking-wider uppercase mt-1">
                    {currentUser ? t('Healith Community Member', 'សមាជិក Healith កម្ពុជា') : t('Access Premium Health App', 'សេវាកម្មសុខភាពឆ្លាតវៃ')}
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-2 hover:bg-[#F9F1F4] text-[#8E6D7A] rounded-full transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Container */}
            <div className="p-6 overflow-y-auto space-y-5">
              {error && (
                <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-100 text-rose-700 text-xs flex items-center gap-2.5">
                  <ShieldAlert className="w-4 h-4 shrink-0" />
                  <p className="font-medium">{error}</p>
                </div>
              )}

              {successMsg && (
                <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-100 text-emerald-700 text-xs flex items-center gap-2.5">
                  <CheckCircle className="w-4 h-4 shrink-0" />
                  <p className="font-medium">{successMsg}</p>
                </div>
              )}

              {currentUser ? (
                // LOGGED IN PORTRAIT
                <div className="space-y-6 py-2">
                  {/* Card 1: Avatar Block as shown in mockup */}
                  <div className="bg-white p-6 rounded-3xl border border-[#F2E4E9] text-center space-y-4 shadow-sm">
                    <div className="w-24 h-24 bg-pink-50 rounded-[32px] border border-primary/10 flex items-center justify-center mx-auto shadow-sm relative">
                      <User className="w-12 h-12 text-primary fill-primary" />
                    </div>

                    {isEditingAccount ? (
                      <div className="space-y-3.5 pt-1 text-left">
                        {/* Name Input */}
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-[#8E6D7A] uppercase tracking-wider">
                            {t('Full Name', 'ឈ្មោះពេញ')}
                          </label>
                          <input
                            type="text"
                            value={editName}
                            onChange={(e) => setEditName(e.target.value)}
                            className="w-full bg-[#FFFAFC] border border-[#F2E4E9] rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-primary/10 focus:border-primary text-slate-800"
                            placeholder={t('Full Name', 'ឈ្មោះពេញ')}
                          />
                        </div>

                        {/* Email Input */}
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-[#8E6D7A] uppercase tracking-wider">
                            {t('Email Address', 'អាសយដ្ឋានអ៊ីមែល')}
                          </label>
                          <input
                            type="email"
                            value={editEmail}
                            onChange={(e) => setEditEmail(e.target.value)}
                            className="w-full bg-[#FFFAFC] border border-[#F2E4E9] rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-primary/10 focus:border-primary text-slate-800"
                            placeholder="yourname@gmail.com"
                          />
                        </div>

                        {/* Action buttons */}
                        <div className="flex gap-2 pt-2">
                          <button
                            type="button"
                            onClick={() => {
                              setIsEditingAccount(false);
                              setEditName(currentUser.name);
                              setEditEmail(currentUser.email);
                            }}
                            className="flex-1 py-2 border border-[#F2E4E9] hover:bg-slate-50 text-[#8E6D7A] rounded-xl text-xs font-bold transition-all cursor-pointer select-none text-center"
                          >
                            {t('Cancel', 'បោះបង់')}
                          </button>
                          <button
                            type="button"
                            onClick={handleSaveAccountInfo}
                            className="flex-1 py-2 bg-primary hover:bg-primary-dark text-white rounded-xl text-xs font-bold transition-all cursor-pointer select-none text-center shadow-sm"
                          >
                            {t('Save', 'រក្សាទុក')}
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        <div className="space-y-1">
                          <h4 className="font-serif font-black text-xl text-primary-dark">{currentUser.name}</h4>
                          <p className="text-xs text-[#8E6D7A] font-semibold">{currentUser.email}</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setEditName(currentUser.name);
                            setEditEmail(currentUser.email);
                            setIsEditingAccount(true);
                          }}
                          className="px-4 py-2 border border-[#F2DCE4] bg-pink-50/50 hover:bg-pink-100 text-primary text-[10px] font-black rounded-full transition-all cursor-pointer select-none flex items-center gap-1.5 mx-auto"
                        >
                          <span>✏️</span>
                          <span>{t('Edit Account Info', 'កែសម្រួលព័ត៌មានគណនី')}</span>
                        </button>
                      </div>
                    )}


                  </div>

                  {/* Card 2: My Profile Section */}
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 px-1 text-left">
                      <Shield className="w-4 h-4 text-primary shrink-0" />
                      <h5 className="font-serif font-black text-primary-dark text-sm">
                        {t('My Profile', 'ប្រវត្តិរូបរបស់ខ្ញុំ')}
                      </h5>
                    </div>

                    {/* Age and Gender Grid */}
                    <div className="grid grid-cols-2 gap-3">
                      <div className="bg-[#FFF6F9]/60 p-4 rounded-2xl border border-[#FAF2F5]/80 flex flex-col gap-1 text-left">
                        <label className="text-[10px] uppercase font-bold tracking-wider text-[#8E6D7A]">
                          {t('Age', 'អាយុ')}
                        </label>
                        <input
                          type="text"
                          value={age}
                          onChange={(e) => {
                            setAge(e.target.value);
                            const suf = currentUser?.id || 'demo_tester';
                            localStorage.setItem(`healith_patient_age_${suf}`, e.target.value);
                          }}
                          className="font-black text-sm text-[#4A3B43] bg-transparent border-none outline-none p-0 focus:ring-0 focus:border-none focus:outline-none placeholder-[#D6BAC6] w-full"
                          placeholder="26 years"
                        />
                      </div>

                      <div className="bg-[#FFF6F9]/60 p-4 rounded-2xl border border-[#FAF2F5]/80 flex flex-col gap-1 text-left">
                        <label className="text-[10px] uppercase font-bold tracking-wider text-[#8E6D7A]">
                          {t('Gender', 'ភេទ')}
                        </label>
                        <select
                          value={gender}
                          onChange={(e) => {
                            setGender(e.target.value);
                            const suf = currentUser?.id || 'demo_tester';
                            localStorage.setItem(`healith_patient_gender_${suf}`, e.target.value);
                          }}
                          className="font-black text-sm text-[#4A3B43] bg-transparent border-none outline-none p-0 focus:ring-0 focus:border-none focus:outline-none cursor-pointer appearance-none w-full"
                        >
                          <option value="Female">{t('Female', 'ស្រី')}</option>
                          <option value="Male">{t('Male', 'ប្រុស')}</option>
                          <option value="Other">{t('Other', 'ផ្សេងៗ')}</option>
                        </select>
                      </div>
                    </div>

                    {/* Location Row */}
                    <div className="bg-[#FFF6F9]/60 p-4 rounded-2xl border border-[#FAF2F5]/80 flex flex-col gap-1 text-left w-full">
                      <label className="text-[10px] uppercase font-bold tracking-wider text-[#8E6D7A]">
                        {t('Location (City or Province)', 'ទីកន្លែងរស់នៅ (ក្រុង ឬ ខេត្ត)')}
                      </label>
                      <input
                        type="text"
                        value={location}
                        onChange={(e) => {
                          setLocation(e.target.value);
                          const suf = currentUser?.id || 'demo_tester';
                          localStorage.setItem(`healith_patient_location_${suf}`, e.target.value);
                        }}
                        className="font-black text-sm text-[#4A3B43] bg-transparent border-none outline-none p-0 focus:ring-0 focus:border-none focus:outline-none placeholder-[#D6BAC6] w-full"
                        placeholder="Sangkat Srah Chork, Phnom Penh"
                      />
                    </div>
                  </div>

                  {/* Card 3: Language Settings */}
                  <div className="bg-[#FFF6F9]/40 p-4 rounded-2xl border border-[#FAF2F5] flex items-center justify-between shadow-[0_2px_8px_-4px_rgba(166,68,110,0.05)] text-left">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-pink-100/70 flex items-center justify-center text-primary shrink-0 shadow-inner">
                        <Globe className="w-5 h-5" />
                      </div>
                      <div className="flex flex-col">
                        <h5 className="font-serif font-black text-primary-dark text-xs leading-tight">
                          {t('Language Settings', 'ការកំណត់ភាសាជាតិ')}
                        </h5>
                        <span className="text-[10px] text-[#8E6D7A] font-semibold">
                          {t('Your Language', 'ភាសារបស់អ្នក')}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => setLanguage(language === 'en' ? 'kh' : 'en')}
                      className="px-4 py-2 bg-pink-50 hover:bg-pink-100 text-primary hover:text-primary-dark transition-all rounded-xl text-xs font-bold flex items-center gap-1.5 border border-[#F2DCE4] shadow-sm cursor-pointer"
                    >
                      {language === 'en' ? (
                        <>
                          <span className="text-base leading-none">🇺🇸</span>
                          <span>English</span>
                        </>
                      ) : (
                        <>
                          <span className="text-base leading-none">🇰🇭</span>
                          <span>ភាសាខ្មែរ</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Card 4: Accessibility Options */}
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 px-1 text-left">
                      <Eye className="w-4 h-4 text-primary shrink-0" />
                      <h5 className="font-serif font-black text-primary-dark text-sm">
                        {t('Accessibility Options', 'ជម្រើសបន្ថែមភាពងាយស្រួល')}
                      </h5>
                    </div>

                    <div className="bg-white p-4 rounded-2xl border border-[#F2E4E9] divide-y divide-[#F9F1F4] text-left">
                      {/* Font Size Toggle */}
                      <div className="flex items-center justify-between pb-3">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 shadow-sm shrink-0">
                            <ZoomIn className="w-4 h-4" />
                          </div>
                          <span className="text-xs font-bold text-[#4A3B43]">
                            {t('Enlarge Font Size', 'ពង្រីកទំហំអក្សរធំជាងមុន')}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setLargeFont(!largeFont)}
                          className={cn(
                            "relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none",
                            largeFont ? "bg-primary" : "bg-slate-200"
                          )}
                        >
                          <span
                            className={cn(
                              "pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out",
                              largeFont ? "translate-x-5" : "translate-x-0"
                            )}
                          />
                        </button>
                      </div>

                      {/* High Contrast Toggle */}
                      <div className="flex items-center justify-between pt-3">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 shadow-sm shrink-0">
                            <Sun className="w-4 h-4" />
                          </div>
                          <span className="text-xs font-bold text-[#4A3B43]">
                            {t('High Contrast Mode', 'របៀបគូសពណ៌ច្បាស់ៗ (High Contrast)')}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setHighContrast(!highContrast)}
                          className={cn(
                            "relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none",
                            highContrast ? "bg-primary" : "bg-slate-200"
                          )}
                        >
                          <span
                            className={cn(
                              "pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out",
                              highContrast ? "translate-x-5" : "translate-x-0"
                            )}
                          />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Logout Action Button */}
                  <button
                    onClick={handleLogout}
                    className="w-full bg-[#FAF2F5] text-rose-600 hover:bg-rose-50 p-4 rounded-2xl font-bold text-xs transition-all active:scale-98 flex items-center justify-center gap-2 border border-rose-100 cursor-pointer mt-2"
                  >
                    <LogOut className="w-4 h-4" />
                    {t('Sign Out / Logout', 'ចាកចេញពីគណនី')}
                  </button>
                </div>
              ) : (
                // LOGIN & REGISTER FORMS
                <form onSubmit={handleSuubmit} className="space-y-4">
                  {isRegister && (
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-[#8E6D7A] uppercase tracking-wider">
                        {t('Full Name', 'ឈ្មោះពេញ')}
                      </label>
                      <div className="relative">
                        <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#D6BAC6]" />
                        <input
                          type="text"
                          placeholder={t('Enter your full name', 'បញ្ចូលឈ្មោះពេញរបស់អ្នក')}
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          className="w-full bg-[#FFFAFC] border border-[#F2E4E9] rounded-2xl pl-12 pr-4 py-3.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/10 focus:border-primary transition-all"
                        />
                      </div>
                    </div>
                  )}

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-[#8E6D7A] uppercase tracking-wider">
                      {t('Email Address', 'អាសយដ្ឋានអ៊ីមែល')}
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#D6BAC6]" />
                      <input
                        type="email"
                        placeholder="yourname@gmail.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full bg-[#FFFAFC] border border-[#F2E4E9] rounded-2xl pl-12 pr-4 py-3.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/10 focus:border-primary transition-all"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-[#8E6D7A] uppercase tracking-wider">
                      {t('Password', 'លេខសម្ងាត់')}
                    </label>
                    <div className="relative">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#D6BAC6]" />
                      <input
                        type="password"
                        placeholder="••••••••"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full bg-[#FFFAFC] border border-[#F2E4E9] rounded-2xl pl-12 pr-4 py-3.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/10 focus:border-primary transition-all"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-primary text-white p-4 rounded-2xl font-bold text-sm hover:bg-primary-dark transition-all active:scale-98 shadow-md shadow-primary/20 flex items-center justify-center gap-2 mt-2 cursor-pointer disabled:opacity-50"
                  >
                    {loading ? (
                      <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <>
                        {isRegister ? <UserPlus className="w-4 h-4" /> : <LogIn className="w-4 h-4" />}
                        {isRegister ? t('Register Account', 'បង្កើតគណនី') : t('Sign In / Log In', 'ចូលប្រព័ន្ធ')}
                      </>
                    )}
                  </button>

                  <div className="pt-3 text-center">
                    <button
                      type="button"
                      onClick={() => {
                        setIsRegister(!isRegister);
                        setError('');
                      }}
                      className="text-xs font-bold text-primary hover:text-primary-dark cursor-pointer underline underline-offset-4"
                    >
                      {isRegister 
                        ? t('Already have an account? Sign In', 'មានគណនីរួចហើយ? ចូលគណនីទីនេះ') 
                        : t('Don\'t have an account? Register', 'មិនទាន់មានគណនី? ចុះឈ្មោះទីនេះ')}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
