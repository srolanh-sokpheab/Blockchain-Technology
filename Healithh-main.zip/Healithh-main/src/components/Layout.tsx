/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { Home, MessageSquare, BookOpen, MapPin, Heart, User, Sparkles, ClipboardList } from 'lucide-react';
import { cn } from '../utils';
import { useLanguage } from '../context/LanguageContext';
import { supabaseService } from '../services/supabaseService';
import AuthModal from './AuthModal';
import WelcomePage from '../pages/WelcomePage';

export default function Layout() {
  const { language, setLanguage, t } = useLanguage();
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authStateCounter, setAuthStateCounter] = useState(0); // For forcing re-render when auth changes
  
  const currentUser = supabaseService.getCurrentUser();

  const handleAuthChange = () => {
    setAuthStateCounter(prev => prev + 1);
  };

  if (!currentUser) {
    return <WelcomePage onAuthSuccess={handleAuthChange} />;
  }

  return (
    <div className="flex flex-col min-h-screen bg-bg-natural font-sans text-[#4A3B43]">
      {/* Header */}
      <header className="sticky top-0 z-40 w-full bg-white/80 backdrop-blur-md border-b border-[#F2E4E9]">
        <div className="flex items-center justify-between px-4 h-16 max-w-lg mx-auto">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center shadow-lg shadow-primary/20">
              <Heart className="w-5 h-5 text-white fill-white" />
            </div>
            <div className="flex flex-col">
              <h1 className="text-2xl font-serif font-bold text-primary-dark leading-none">
                Healith
              </h1>
              <span className="text-[9px] uppercase tracking-tighter text-[#8E6D7A] font-bold mt-0.5">
                {t('Intelligence for Cambodia', 'បញ្ញាសិប្បនិម្មិតសម្រាប់កម្ពុជា')}
              </span>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {/* User Profile Avatar Icon button as shown in mockups */}
            <button
              onClick={() => setIsAuthOpen(true)}
              className={cn(
                "w-9 h-9 rounded-full border flex items-center justify-center transition-all cursor-pointer relative",
                currentUser 
                  ? "bg-pink-50 border-primary text-primary" 
                  : "bg-slate-50 border-slate-200 text-slate-500 hover:text-primary hover:border-primary/50"
              )}
              title={currentUser ? `Profile: ${currentUser.name}` : "Sign In / Register"}
            >
              <User className={cn("w-4 h-4", currentUser ? "fill-primary text-white" : "")} />
              {currentUser && (
                <span className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-emerald-500 border-2 border-white rounded-full" />
              )}
            </button>

            {/* Language Switchers */}
            <div className="flex bg-[#F9F1F4] rounded-full p-0.5 border border-[#F2E4E9] shrink-0">
              <button
                onClick={() => setLanguage('en')}
                className={cn(
                  "px-2.5 py-1 rounded-full text-[9px] font-bold transition-all",
                  language === 'en' ? "bg-primary text-white shadow-sm" : "text-[#8E6D7A]"
                )}
              >
                EN
              </button>
              <button
                onClick={() => setLanguage('kh')}
                className={cn(
                  "px-2.5 py-1 rounded-full text-[9px] font-bold transition-all",
                  language === 'kh' ? "bg-primary text-white shadow-sm" : "text-[#8E6D7A]"
                )}
              >
                KH
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 w-full max-w-lg mx-auto pb-24 overflow-x-hidden">
        <Outlet context={{ onAuthChange: handleAuthChange }} />
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-[#F2E4E9] shadow-[0_-4px_20px_-10px_rgba(166,68,110,0.1)]">
        <div className="flex items-center justify-around h-18 max-w-lg mx-auto">
          <NavButton to="/" icon={<Home className="w-5 h-5" />} label={t('Home', 'ផ្ទះ')} />
          <NavButton to="/activities" icon={<ClipboardList className="w-5 h-5" />} label={t('Tracker', 'តាមដាន')} />
          <NavButton to="/chat" icon={<MessageSquare className="w-5 h-5" />} label={t('AI Chat', 'ជំនួយការ AI')} />
          <NavButton to="/dictionary" icon={<BookOpen className="w-5 h-5" />} label={t('Dictionary', 'វចនានុក្រម')} />
          <NavButton to="/hospitals" icon={<MapPin className="w-5 h-5" />} label={t('Hospitals', 'មន្ទីរពេទ្យ')} />
        </div>
      </nav>

      {/* Auth Modal Trigger */}
      <AuthModal 
        isOpen={isAuthOpen} 
        onClose={() => setIsAuthOpen(false)} 
        onAuthSuccess={handleAuthChange} 
      />
    </div>
  );
}

function NavButton({ to, icon, label }: { to: string; icon: React.ReactNode; label: string }) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        cn(
          "flex flex-col items-center justify-center gap-1.5 w-full h-full transition-all duration-300",
          isActive ? "text-primary scale-105" : "text-[#8E6D7A] hover:text-primary-dark"
        )
      }
    >
      <div className={cn(
        "p-2 rounded-xl transition-all",
        "group-hover:bg-accent/30"
      )}>
        {icon}
      </div>
      <span className="text-[9px] font-bold uppercase tracking-widest">{label}</span>
    </NavLink>
  );
}
