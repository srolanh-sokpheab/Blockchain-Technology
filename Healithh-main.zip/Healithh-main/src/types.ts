/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum Category {
  PREVENTION = 'Prevention',
  DISEASE = 'Disease',
  NUTRITION = 'Nutrition',
  MENTAL_HEALTH = 'Mental Health',
  FIRST_AID = 'First Aid',
}

export interface HealthArticle {
  id: string;
  titleEn: string;
  titleKh: string;
  category: Category;
  symptoms?: string[];
  causes?: string[];
  prevention: string[];
  treatments?: string[];
  riskFactors?: string[];
  contentEn: string;
  contentKh: string;
  imageUrl?: string;
  whenToSeeDoctorEn?: string;
  whenToSeeDoctorKh?: string;
  relatedEn?: string[];
  relatedKh?: string[];
}

export interface Hospital {
  id: string;
  nameEn: string;
  nameKh: string;
  address: string;
  lat: number;
  lng: number;
  rating: number;
  priceRange: '$' | '$$' | '$$$';
  contact: string;
  hours: string;
  isEmergency: boolean;
  services: string[];
  imageUrl: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}
