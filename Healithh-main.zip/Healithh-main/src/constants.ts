/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Category, HealthArticle, Hospital } from './types';

export const HEALTH_ARTICLES: HealthArticle[] = [
  {
    id: 'd1',
    titleEn: 'Dengue Fever',
    titleKh: 'គ្រុនឈាម',
    category: Category.DISEASE,
    symptoms: [
      'High fever (គ្រុនក្តៅខ្លាំង)',
      'Severe headache (ឈឺក្បាលខ្លាំង)',
      'Pain behind eyes (ឈឺផ្នែកខាងក្រោយភ្នែក)',
      'Joint and muscle pain (ឈឺសន្លាក់ និងសាច់ដុំ)',
      'Skin rash (កន្ទួលលើស្បែក)'
    ],
    causes: ['Aedes mosquito bite (មូសខ្លាខាំ)'],
    prevention: [
      'Use mosquito nets (គេងក្នុងមុង)',
      'Eliminate standing water (លុបបំបាត់ទឹកដក់)',
      'Apply mosquito repellent (ប្រើថ្នាំការពារមូស)'
    ],
    treatments: [
      'Hydration therapy (ផឹកទឹកឲ្យបានច្រើន)',
      'Pain relievers like paracetamol (ប្រើថ្នាំបំបាត់ការឈឺចាប់ ដូចជា ប៉ារ៉ាសេតាម៉ុល)',
      'Avoid ibuprofen/aspirin (ជៀសវាងថ្នាំអ៊ីប៊ុយប្រូហ្វេន)'
    ],
    contentEn: 'Dengue fever is a mosquito-transmitted tropical viral disease characterized by high fever, severe pain, and rash.',
    contentKh: 'ជំងឺគ្រុនឈាម គឺជាជំងឺវីរុសត្រូពិកដែលឆ្លងតាមរយៈការខាំរបស់មូសខ្លា ដែលបង្កឲ្យមានអាការគ្រុនក្តៅខ្លាំង ឈឺសន្លាក់ឆ្អឹង និងកន្ទួលស្បែក។',
    imageUrl: 'https://images.unsplash.com/photo-1584036561566-baf8f5f1b144?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'd2',
    titleEn: 'Common Cold',
    titleKh: 'ផ្តាសាយធម្មតា',
    category: Category.PREVENTION,
    symptoms: [
      'Runny nose (ហៀរសំបោរ)',
      'Sore throat (ឈឺបំពង់ក)',
      'Coughing (ក្អក)',
      'Mild headache (ឈឺក្បាលស្រាល)'
    ],
    causes: ['Rhinovirus infection (ការឆ្លងមេរោគ Rhinovirus)'],
    prevention: [
      'Wash hands regularly (លាងដៃឲ្យបានញឹកញាប់)',
      'Avoid touching your face (ជៀសវាងការប៉ះពាល់ផ្ទៃមុខ)',
      'Stay warm during cold weather (រក្សាកម្តៅសរីរាង្គកំឡុងពេលអាកាសធាតុត្រជាក់)'
    ],
    treatments: [
      'Bed rest (សម្រាកឲ្យបានច្រើន)',
      'Steam inhalation (ស្អំ ឬស្ទង់ចំហាយទឹកក្តៅ)',
      'Vitamin C supplements (បន្ថែមវីតាមីន C)'
    ],
    contentEn: 'The common cold is a highly contagious viral infection affecting the upper respiratory tract.',
    contentKh: 'ផ្តាសាយធម្មតា គឺជាការបង្ករោគដោយវីរុសនៅច្រមុះ និងបំពង់កបំពង់ខ្យល់ ដែលងាយនឹងឆ្លងរាលដាល។',
    imageUrl: 'https://images.unsplash.com/photo-1584036533827-45bce166ad94?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'd3',
    titleEn: 'Heat Stroke',
    titleKh: 'ការគាំងកម្តៅ',
    category: Category.FIRST_AID,
    symptoms: [
      'High core temperature (សីតុណ្ហភាពរាងកាយឡើងខ្ពស់ខ្លាំង)',
      'Confusion or altered state (វង្វេងវង្វាន់ ឬសន្លប់)',
      'Rapid, heavy breathing (ដកដង្ហើមញាប់ និងធ្ងន់)',
      'Dry or sweaty skin (ស្បែកស្ងួត ឬបែកញើសខ្លាំង)'
    ],
    causes: ['Prolonged exposure to extreme heat (ការប៉ះនឹងកម្តៅថ្ងៃខ្លាំងក្នុងរយៈពេលយូរ)'],
    prevention: [
      'Drink plenty of fluid (ផឹកទឹកឲ្យបានច្រើន)',
      'Wear loose-fitting, light clothes (ស្លៀកសម្លៀកបំពាក់ស្តើង និងធូរ)',
      'Avoid midday outdoor workouts (ជៀសវាងហាត់ប្រាណក្រោមកម្តៅថ្ងៃត្រង់)'
    ],
    treatments: [
      'Move to shade immediately (ផ្លាស់ទីទៅកន្លែងត្រជាក់ជាបន្ទាន់)',
      'Cool down with cold towels (ប្រើកន្សែងត្រជាក់ស្អំខ្លួន)',
      'Seek emergency service (ស្វែងរកការព្យាបាលបន្ទាន់)'
    ],
    contentEn: 'Heat stroke is a serious condition caused by body overheating from prolonged exposure to high temperatures.',
    contentKh: 'ខ្យល់គរ ឬការគាំងកម្តៅ គឺជាស្ថានភាពធ្ងន់ធ្ងរដែលបណ្តាលមកពីការឡើងកម្តៅខ្លាំងនៃរាងកាយដោយសារការប៉ះនឹងកម្តៅថ្ងៃខ្លាំង។',
    imageUrl: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'd4',
    titleEn: 'Diabetes Mellitus',
    titleKh: 'ទឹកនោមផ្អែម',
    category: Category.DISEASE,
    symptoms: [
      'Frequent urination (នោមញឹកញាប់)',
      'Increased thirst (ស្រេកទឹកខ្លាំង)',
      'Unexplained weight loss (ស្រកទម្ងន់ខុសធម្មតា)',
      'Slow-healing sores (ដំបៅយូរជាសះស្បើយ)'
    ],
    causes: [
      'Insulin resistance (ភាពស៊ាំនៃអាំងស៊ុយលីន)',
      'Genetic predisposition (កត្តាហ្សែន)',
      'High sugar, processed diet (របបអាហារដែលមានជាតិស្ករខ្ពស់)'
    ],
    prevention: [
      'Maintain active exercise habits (រក្សាទម្លាប់ហាត់ប្រាណ)',
      'Balance whole food diets (ញ៉ាំអាហារមានតុល្យភាព)',
      'Regular blood sugar screenings (ពិនិត្យជាតិស្ករក្នុងឈាមជាប្រចាំ)'
    ],
    treatments: [
      'Metformin or insulin injections (ការព្យាបាលដោយអាំងស៊ុយលីន ឬថ្នាំ)',
      'Carbohydrate monitoring (កម្រិតការញ៉ាំកាបូអ៊ីដ្រាត)'
    ],
    contentEn: 'Diabetes is a metabolic disorder resulting in chronic high blood glucose levels.',
    contentKh: 'ជំងឺទឹកនោមផ្អែម គឺជាជំងឺមេតាបូលីសរ៉ាំរ៉ៃដែលបង្កឱ្យកម្រិតជាតិស្ករក្នុងឈាមឡើងខ្ពស់ខុសប្រក្រតី។',
    imageUrl: 'https://images.unsplash.com/photo-1511174511562-5f7f18b874f8?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'd5',
    titleEn: 'Gastritis',
    titleKh: 'រលាកក្រពះ',
    category: Category.NUTRITION,
    symptoms: [
      'Burning stomach ache (ឈឺក្រហាយចុងដង្ហើម)',
      'Bloating and nausea (ហើមពោះ និងចង្អោរ)',
      'Loss of appetite (មិនឃ្លានអាហារ)',
      'Indigestion (ពិបាករំលាយអាហារ)'
    ],
    causes: [
      'Helicobacter pylori infection (ការឆ្លងបាក់តេរី H. pylori)',
      'Skipping meals or eating late (ការញ៉ាំបាយមិនទៀងពេល)',
      'Excessive spicy food consumption (ការញ៉ាំអាហារហឹរឬជូរខ្លាំង)'
    ],
    prevention: [
      'Eat scheduled, timely meals (ញ៉ាំអាហារឲ្យទៀងទាត់)',
      'Limit alcohol and acid inputs (កម្រិតគ្រឿងស្រវឹង និងអាហារទឹកអាស៊ីត)',
      'Practice proper food hygiene (រក្សាអនាម័យចំណីអាហារ)'
    ],
    treatments: [
      'Antacids or PPI medication (ការប្រើប្រាស់ថ្នាំបន្សាបអាស៊ីតក្រពះ)',
      'Eat soft, bland meals (ញ៉ាំអាហារទន់ៗ មិនហឹរ)'
    ],
    contentEn: 'Gastritis is an inflammation, irritation, or erosion of the protective lining of the stomach.',
    contentKh: 'ជំងឺរលាកក្រពះ គឺជាការរលាក ឬរលាត់ភ្នាសការពារខាងក្នុងរបស់ក្រពះ ដែលច្រើនបណ្តាលមកពីការញ៉ាំអាហារមិនទៀងទាត់។',
    imageUrl: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'd6',
    titleEn: 'Depression & Anxiety',
    titleKh: 'ថប់បារម្ភ និងបាក់ទឹកចិត្ត',
    category: Category.MENTAL_HEALTH,
    symptoms: [
      'Persistent sadness (អារម្មណ៍ស្រងូតស្រងាត់រ៉ាំរ៉ៃ)',
      'Loss of interest in hobbies (លែងចង់ធ្វើអ្វីដែលធ្លាប់ចូលចិត្ត)',
      'Insomnia or hyper-somnia (គេងមិនលក់ ឬគេងច្រើនជ្រុល)',
      'Racing thoughts or panic (គិតច្រើនហួសប្រមាណ ឬការភ័យខ្លាច)'
    ],
    causes: [
      'Chemical imbalances in brain (តុល្យភាពគីមីខួរក្បាល)',
      'Severe trauma or life stress (ផលប៉ះពាល់ផ្លូវចិត្តធ្ងន់ធ្ងរ ឬស្ត្រេស)',
      'Physical health issues (បញ្ហាសុខភាពរាងកាយ)'
    ],
    prevention: [
      'Stay linked with support groups (ជជែកជាមួយមនុស្សជិតស្និទ្ធ)',
      'Regular physical movement (ធ្វើលំហាត់ប្រាណជាប្រចាំ)',
      'Maintain steady sleep routines (គេងឲ្យបានគ្រប់គ្រាន់)'
    ],
    treatments: [
      'Cognitive behavioral therapy (ការប្រឹក្សាយោបល់គំនិតផ្លូវចិត្ត)',
      'Meditation and mindfulness (ការធ្វើសមាធិ និងការរៀបចំដង្ហើម)',
      'Antidepressant prescription (ការប្រើប្រាស់ថ្នាំបើចាំបាច់)'
    ],
    contentEn: 'Depression and anxiety are common mental disorders causing lasting emotional distress and daily disruption.',
    contentKh: 'ជំងឺបាក់ទឹកចិត្ត និងជាតិថប់បារម្ភ គឺជាបញ្ហាសុខភាពផ្លូវចិត្តដ៏ទូទៅ ដែលប៉ះពាល់ដល់អារម្មណ៍ និងការរស់នៅប្រចាំថ្ងៃ។',
    imageUrl: 'https://images.unsplash.com/photo-1489659639091-8b687bc4386e?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'd7',
    titleEn: 'Allergies',
    titleKh: 'អាឡែស៊ី',
    category: Category.PREVENTION,
    symptoms: [
      'Itchy watery eyes (រកាំនិងហូរទឹកភ្នែក)',
      'Hives red skin swelling (កន្ទួលរមាស់ក្រហមពេញស្បែក (កន្ទាលត្រអាក))',
      'Frequent throat cough dry (ស្ងួតក្អករមាស់បំពង់ក)'
    ],
    causes: [
      'Pollen grain exposure (លម្អងផ្កាខ្ចាត់ខ្ចាយ)',
      'Dust mites in furniture fabrics (ធូលីក្នុងសាឡុង ឬសំឡីពូក)',
      'Seafood shellfish consumption (បរិភោគគ្រឿងសមុទ្រស្រស់)'
    ],
    prevention: [
      'Vacuum clean home mats weekly (បូមធូលីកម្រាលព្រំផ្ទះរៀងរាល់សប្តាហ៍)',
      'Take warm showers after traveling through dusty cities (ងូតទឹកសម្អាតខ្លួនបន្ទាប់ពីធ្វើដំណើរតាមផ្លូវដីហ៊ុយ)'
    ],
    treatments: [
      'Oral antihistamines (Cetirizine, Loratadine) (ប្រើថ្នាំប្រឆាំងជាតិអ៊ីស្តាមីន ដូចជា Cetirizine រាល់យប់)',
      'Calamine lotion application (លាបម្សៅទឹក Calamine បំបាត់រមាស់)'
    ],
    contentEn: 'Immune hyper-responsiveness triggered by external atmospheric or dietary proteins.',
    contentKh: 'ប្រតិកម្មខ្លាំងហួសហេតុនៃប្រព័ន្ធភាពស៊ាំដែលជម្រុញដោយប្រូតេអ៊ីនក្នុងបរិយាកាស ឬចំណីអាហារខាងក្រៅរាងកាយ។',
    imageUrl: 'https://images.unsplash.com/photo-1581093458791-9f3c3900df4b?auto=format&fit=crop&q=80&w=800',
    whenToSeeDoctorEn: 'Anaphylactic crisis signs like throat swelling, lips inflation, and oxygen drop (Medical emergency).',
    whenToSeeDoctorKh: 'សញ្ញាគ្រោះថ្នាក់បំផុត (Anaphylaxis) ដូចជាហើមបំពង់កហប់ដង្ហើម ហើមបបូរមាត់ និងថប់ខ្យល់ខ្លាំង។',
    relatedEn: ['Asthma', 'Flu & Cold'],
    relatedKh: ['ជំងឺហឺត', 'គ្រុនផ្ដាសាយ']
  },
  {
    id: 'd8',
    titleEn: 'Insomnia',
    titleKh: 'ជំងឺគេងមិនលក់',
    category: Category.MENTAL_HEALTH,
    symptoms: [
      'Lying awake for hours (ដេកផ្ងារបើកភ្នែកធីងៗរាប់ម៉ោង)',
      'Waking too early (ភ្ញាក់ពីដេកលឿនពេកហើយដេកវិញមិនលក់)',
      'Irritability and low focus next day (មួរម៉ៅ និងខ្សោយការផ្តោតអារម្មណ៍នៅថ្ងៃបន្ទាប់)'
    ],
    causes: [
      'High blue screen light exposure before bed (ការលេងទូរស័ព្ទពន្លឺខៀវមុនពេលគេង)',
      'Late night coffee/tea (ការផឹកតែឬកាហ្វេពេលយប់)',
      'Severe mental stress (ភាពតានតឹងស្ត្រេសផ្លូវចិត្តខ្លាំង)'
    ],
    prevention: [
      'Cut all screens one hour before bedroom bedtime (បិទទូរស័ព្ទ កុំព្យូទ័រ ១ម៉ោងមុនពេលចូលគេង)',
      'Build cold, dark, quiet sleep spaces (រៀបចំបន្ទប់គេងឱ្យត្រជាក់ ងងឹត និងស្ងាត់ល្អ)'
    ],
    treatments: [
      'Cognitive behavior relaxation exercises for sleep (លំហាត់ស្មារតីសម្រាលអារម្មណ៍មុនគេង)',
      'Warm chamomile tea (ផឹកតែផ្កាកក្កដា (Chamomile))',
      'Strict routine (គេងនិងភ្ញាក់ម៉ោងដដែលៗ)'
    ],
    contentEn: 'A sleep disorder characterized by persistent difficulty falling or staying asleep.',
    contentKh: 'ជំងឺរំខានដំណេកដែលត្រូវបានកំណត់ដោយការពិបាកគេងលក់ ឬការគេងមិនបានស្កប់ស្កល់ជាបន្តបន្ទាប់។',
    imageUrl: 'https://images.unsplash.com/photo-1511295742364-92767fc4a851?auto=format&fit=crop&q=80&w=800',
    whenToSeeDoctorEn: 'When chronic sleep loss impairs daily physical coordination and lasts past 4 consecutive weeks.',
    whenToSeeDoctorKh: 'នៅពេលកង្វះដំណេកប៉ះពាល់ដល់ការដំណើរការប្រចាំថ្ងៃធ្ងន់ធ្ងរ និងអូសបន្លាយលើសពី៤សប្តាហ៍។',
    relatedEn: ['Headache', 'Stress Management'],
    relatedKh: ['អាការៈឈឺក្បាល', 'ការគ្រប់គ្រងស្រ្តេស']
  }
];

export const HOSPITALS: Hospital[] = [
  {
    id: 'h1',
    nameEn: 'Calmette Hospital',
    nameKh: 'មន្ទីរពេទ្យកាល់ម៉ែត',
    address: 'No. 3, Monivong Blvd, Phnom Penh',
    lat: 11.5794,
    lng: 104.9194,
    rating: 4.2,
    priceRange: '$$',
    contact: '023 426 948',
    hours: '24/7',
    isEmergency: true,
    services: ['Emergency', 'Surgery', 'Cardiology', 'General Medicine'],
    imageUrl: 'https://images.unsplash.com/photo-1586773860418-d319a221f52c?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'h2',
    nameEn: 'Royal Phnom Penh Hospital',
    nameKh: 'មន្ទីរពេទ្យរ៉ូយ៉ាល់ភ្នំពេញ',
    address: 'No. 888, Russian Confederation Blvd, Phnom Penh',
    lat: 11.5646,
    lng: 104.8812,
    rating: 4.8,
    priceRange: '$$$',
    contact: '023 991 000',
    hours: '24/7',
    isEmergency: true,
    services: ['ICU', 'Pediatrics', 'International Patient Service'],
    imageUrl: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&q=80&w=800',
  }
];
