/**
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Footprints, 
  Flame, 
  Droplet, 
  Moon, 
  Plus, 
  Trash2, 
  Check, 
  MessageSquare, 
  AlertTriangle, 
  Dumbbell, 
  Heart,
  ChevronRight,
  TrendingUp,
  Stethoscope,
  Sparkles,
  ClipboardList,
  RotateCcw
} from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { cn } from '../utils';
import { useLanguage } from '../context/LanguageContext';
import { supabaseService } from '../services/supabaseService';

interface CustomActivity {
  id: string;
  nameEn: string;
  nameKh: string;
  duration: number; // minutes
  calories: number;
  timeClass: string; // e.g. "Morning", "Evening"
}

export default function ActivitiesPage() {
  const { t, language } = useLanguage();
  const navigate = useNavigate();
  const location = useLocation();

  const currentUser = supabaseService.getCurrentUser();
  const userSuffix = currentUser?.id || 'demo_tester';

  // Toggle tab: 'symptoms' or 'fitness'
  // Detect if url path is '/symptom' to open symptom tab by default
  const [activeTab, setActiveTab] = useState<'symptoms' | 'fitness'>(() => {
    if (location.pathname.includes('symptom')) {
      return 'symptoms';
    }
    return 'fitness';
  });

  // Trackers States (persisted per user)
  const [waterCups, setWaterCups] = useState<number>(() => {
    const saved = localStorage.getItem(`healith_water_${userSuffix}`);
    return saved ? parseInt(saved) : 4;
  });
  const [sleepHours, setSleepHours] = useState<number>(() => {
    const saved = localStorage.getItem(`healith_sleep_${userSuffix}`);
    return saved ? parseInt(saved) : 7;
  });
  const [stepCounts, setStepCounts] = useState<number>(() => {
    const saved = localStorage.getItem(`healith_steps_${userSuffix}`);
    return saved ? parseInt(saved) : 6400;
  });
  const [caloriesBurned, setCaloriesBurned] = useState<number>(() => {
    const saved = localStorage.getItem(`healith_calories_${userSuffix}`);
    return saved ? parseInt(saved) : 380;
  });

  // Custom added sports/activities logging
  const [customActivities, setCustomActivities] = useState<CustomActivity[]>(() => {
    const saved = localStorage.getItem(`healith_custom_acts_${userSuffix}`);
    if (saved) return JSON.parse(saved);
    // Defaults representative of young Cambodian students/professionals
    return [
      { id: '1', nameEn: 'Gym Exercise', nameKh: 'ហាត់ប្រាណនៅក្លឹបហាត់ប្រាណ', duration: 45, calories: 250, timeClass: 'Morning' },
      { id: '2', nameEn: 'Jogging near Riverside', nameKh: 'រត់ហាត់ប្រាណមាត់ទន្លេ', duration: 30, calories: 180, timeClass: 'Evening' },
    ];
  });

  // New activity form inputs
  const [newActEn, setNewActEn] = useState('');
  const [newActKh, setNewActKh] = useState('');
  const [newActDur, setNewActDur] = useState(20);
  const [newActCal, setNewActCal] = useState(120);

  // --- SYMPTOM CHECKLIST STATES (Representing user screenshot layout precisely) ---
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>(() => {
    const saved = localStorage.getItem(`healith_logged_symptoms_${userSuffix}`);
    return saved ? JSON.parse(saved) : [];
  });

  interface SymptomAnalysisResult {
    severity: 'Moderate' | 'Severe/Emergency';
    titleEn: string;
    titleKh: string;
    instructionEn: string;
    instructionKh: string;
    possibleDiseasesEn: string;
    possibleDiseasesKh: string;
    suggestedRemediesEn: string;
    suggestedRemediesKh: string;
    specialistEn: string;
    specialistKh: string;
  }

  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [sidebarPulse, setSidebarPulse] = useState(false); // Decorative pulse hint
  const [analysisCompleted, setAnalysisCompleted] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<SymptomAnalysisResult | null>(() => {
    const saved = localStorage.getItem(`healith_analysis_res_${userSuffix}`);
    return saved ? JSON.parse(saved) : null;
  });

  const symptomList = [
    {
      id: 'fever',
      titleEn: 'Fever (High body temperature)',
      titleKh: 'តើមានគ្រុនក្តៅ (កំដៅខ្លួនឡើងខ្ពស់) ដែរឬទេ?',
      infoEn: 'Body temp above 38°C. Drink water and rest.',
      infoKh: 'សីតុណ្ហភាពខ្លួនលើសពី ៣៨°C។ ញ៉ាំទឹកឲ្យបានច្រើន និងសម្រាក។'
    },
    {
      id: 'cough',
      titleEn: 'Cough',
      titleKh: 'តើមានអាការក្អកដែរឬទេ?',
      infoEn: 'Dry or wet throat tickle. Avoid ice foods.',
      infoKh: 'អាការស្ងួតក ឬរមាស់បំពង់ក។ ជៀសវាងភេសជ្ជៈត្រជាក់ខ្លាំង។'
    },
    {
      id: 'headache',
      titleEn: 'Headache',
      titleKh: 'តើមានអាការឈឺក្បាលដែរឬទេ?',
      infoEn: 'Dull or sharp head ache. May indicate dehydration.',
      infoKh: 'មានអារម្មណ៍ឈឺខ្ទោកនៅក្នុងក្បាល។ លោកអ្នកប្រហែលជាខ្វះជាតិទឹក។'
    },
    {
      id: 'fatigue',
      titleEn: 'Fatigue / Body Weakness',
      titleKh: 'តើមានអាការហត់នឿយ ឬអស់កម្លាំងក្នុងខ្លួនដែរឬទេ?',
      infoEn: 'Low physical energy. Try basic stretching sessions.',
      infoKh: 'មិនសូវមានថាមពលរាងកាយ។ សាកល្បងលំហាត់ប្រាណពត់ខ្លួនស្រាលៗ។'
    },
    {
      id: 'chest_pain',
      titleEn: 'Chest Pain or Tightness',
      titleKh: 'តើមានអាការឈឺទ្រូង ឬថប់បេះដូងដែរឬទេ?',
      infoEn: 'Pressure or constriction chest area. Severe warn indicator!',
      infoKh: 'អារម្មណ៍ណែន ឬចុកថប់នៅដើមទ្រូង។ នេះជាសញ្ញាព្រមានធ្ងន់ធ្ងរ!'
    },
    {
      id: 'breath',
      titleEn: 'Shortness of Breath',
      titleKh: 'តើពិបាកដកដង្ហើម ឬដកដង្ហើមខ្លីៗដែរឬទេ?',
      infoEn: 'Struggling to draw oxygen fully. Seek doctor referral.',
      infoKh: 'ពិបាកជំនះទាញខ្យល់ដកដង្ហើមឲ្យវែង។ គួរពិគ្រោះជាមួយគ្រូពេទ្យជំនាញ។'
    },
    {
      id: 'allergy',
      titleEn: 'Allergic Reactions (Itchy eyes, Hives, Rash)',
      titleKh: 'តើមានប្រតិកម្មអាឡែស៊ី (រកាំភ្នែក កន្ទួលក្រហម ហើមកន្ទាលត្រអាក) ដែរឬទេ?',
      infoEn: 'Atmospheric or food allergens. Oral antihistamines or Calamine can help.',
      infoKh: 'ប្រតិកម្មនឹងលម្អងផ្កា ធូលី ឬគ្រឿងសមុទ្រ។ ថ្នាំប្រឆាំងអ៊ីស្តាមីន ឬ Calamine អាចជួយបាន។'
    },
    {
      id: 'insomnia',
      titleEn: 'Insomnia / Sleep Difficulty',
      titleKh: 'តើជួបប្រទះបញ្ហាគេងមិនលក់ ឬភ្ញាក់កណ្ដាលយប់ដែរឬទេ?',
      infoEn: 'Difficulty falling or staying asleep. Avoid blue light screens before bed.',
      infoKh: 'ពិបាកចូលគេង ឬដេកផ្ងាររាប់ម៉ោង។ ជៀសវាងទូរស័ព្ទ ឬកាហ្វេ១ម៉ោងមុនគេង។'
    }
  ];

  // Save states incrementally to simulation persistent cloud
  useEffect(() => {
    localStorage.setItem(`healith_water_${userSuffix}`, waterCups.toString());
  }, [waterCups, userSuffix]);

  useEffect(() => {
    localStorage.setItem(`healith_sleep_${userSuffix}`, sleepHours.toString());
  }, [sleepHours, userSuffix]);

  useEffect(() => {
    localStorage.setItem(`healith_steps_${userSuffix}`, stepCounts.toString());
  }, [stepCounts, userSuffix]);

  useEffect(() => {
    localStorage.setItem(`healith_calories_${userSuffix}`, caloriesBurned.toString());
  }, [caloriesBurned, userSuffix]);

  useEffect(() => {
    localStorage.setItem(`healith_custom_acts_${userSuffix}`, JSON.stringify(customActivities));
  }, [customActivities, userSuffix]);

  useEffect(() => {
    localStorage.setItem(`healith_logged_symptoms_${userSuffix}`, JSON.stringify(selectedSymptoms));
  }, [selectedSymptoms, userSuffix]);

  useEffect(() => {
    if (analysisResult) {
      localStorage.setItem(`healith_analysis_res_${userSuffix}`, JSON.stringify(analysisResult));
    } else {
      localStorage.removeItem(`healith_analysis_res_${userSuffix}`);
    }
  }, [analysisResult, userSuffix]);

  // Handle toggling symptoms in array
  const handleToggleSymptom = (id: string) => {
    setIsAnalyzing(false);
    setAnalysisCompleted(false);
    setAnalysisResult(null);
    setSelectedSymptoms(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const handleAnalyzeSymptoms = async () => {
    if (selectedSymptoms.length === 0) return;
    setIsAnalyzing(true);
    setAnalysisCompleted(false);
    setAnalysisResult(null);
    
    // Retrieve patient profile details from localStorage
    const age = localStorage.getItem(`healith_patient_age_${userSuffix}`) || '26 years';
    const gender = localStorage.getItem(`healith_patient_gender_${userSuffix}`) || 'Female';
    const locationStr = localStorage.getItem(`healith_patient_location_${userSuffix}`) || 'Sangkat Srah Chork, Phnom Penh';

    try {
      const mappedSymptomLabels = selectedSymptoms.map(id => {
        const item = symptomList.find(x => x.id === id);
        return item ? `${item.titleEn} (${item.titleKh})` : id;
      });

      const response = await fetch('/api/analyze-symptoms', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          symptoms: mappedSymptomLabels,
          patientInfo: {
            age,
            gender,
            location: locationStr
          }
        })
      });

      if (!response.ok) {
        throw new Error('Analysis request failed');
      }

      const result = await response.json();
      setAnalysisResult(result);
      setAnalysisCompleted(true);
    } catch (err) {
      console.error('Symptom analysis API error:', err);
      // Fallback safely to a high-quality, localized Khmer/English emergency-aware mock logic
      const hasEmergency = selectedSymptoms.includes('chest_pain') || selectedSymptoms.includes('breath');
      setAnalysisResult({
        severity: hasEmergency ? 'Severe/Emergency' : 'Moderate',
        titleEn: hasEmergency 
          ? '⚠️ EMERGENCY EVALUATION ADVISEMENT' 
          : '⚠️ Daily Health Recommendations',
        titleKh: hasEmergency 
          ? '⚠️ ការណែនាំស្វែងរកការព្យាបាលបន្ទាន់' 
          : '⚠️ វិធីថែទាំសុខភាពប្រចាំថ្ងៃ',
        instructionEn: hasEmergency
          ? 'Severe risk indicators detected (chest tightness or heavy breathing). Please visit Calmette Hospital or the nearest emergency ward in Phnom Penh immediately.'
          : 'Primary symptoms logged (fever, cough or headache). Ensure you stay warm, avoid frozen food or cold drinks, gargle water, and rest well.',
        instructionKh: hasEmergency
          ? 'ពិនិត្យឃើញសញ្ញាព្រមានធ្ងន់ធ្ងរ (តឹងទ្រូង ឬពិបាកដកដង្ហើម)។ សូមប្រញាប់ទៅមន្ទីរពេទ្យកាល់ម៉ែត ឬបន្ទប់សង្គ្រោះបន្ទាន់ដែលនៅជិតលោកអ្នកបំផុត។'
          : 'ពិនិត្យឃើញសញ្ញាស្រាល (ក្អក គ្រុនក្ដៅ ឬឈឺក្បាល)។ សូមសម្រាកឲ្យបានច្រើន ញ៉ាំទឹកក្ដៅឧណ្ហៗ និងជៀសវាងភេសជ្ជៈត្រជាក់។',
        possibleDiseasesEn: hasEmergency 
          ? '• Potential Acute Coronary Syndrome or Angina\n• Possible respiratory tract inflammation, severe asthma, or bronchospasm'
          : '• Common Cold or Viral Influenza\n• Stress, Tension headache, or early signs of seasonal pharyngitis',
        possibleDiseasesKh: hasEmergency 
          ? '• អាចជាសញ្ញានៃជំងឺសរសៃឈាមបេះដូង ឬជំងឺថប់បេះដូង\n• អាចរលាកទងសួត ឬហឺតធ្ងន់ធ្ងរ'
          : '• ជំងឺផ្ដាសាយធម្មតា ឬផ្ដាសាយធំវីរុស\n• ស្រ្តេស ឈឺក្បាលតានតឹង ឬរលាកបំពង់កបឋម',
        suggestedRemediesEn: '• Stay thoroughly hydrated with room-temperature water\n• Monitor temperatures regularly\n• Rest completely and avoid strain',
        suggestedRemediesKh: '• ពិសារទឹកស្អាតកម្រិតធម្មតា ឬទឹកក្តៅឧណ្ហៗ\n• វាស់កំដៅខ្លួនជាប្រចាំ\n• សម្រាកឲ្យបានច្រើន និងជៀសវាងការធ្វើការធ្ងន់',
        specialistEn: hasEmergency ? 'Emergency Medicine / Cardiology Division' : 'General Practitioner / Internal Medicine',
        specialistKh: hasEmergency ? 'ផ្នែកសង្គ្រោះបន្ទាន់ ឬបេះដូង' : 'ផ្នែករោគទូទៅ ឬជំងឺទូទៅ'
      });
      setAnalysisCompleted(true);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Add custom workout activity
  const handleAddCustomActivity = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newActEn.trim()) return;
    const nameKhmer = newActKh.trim() || newActEn;
    const item: CustomActivity = {
      id: Date.now().toString(),
      nameEn: newActEn,
      nameKh: nameKhmer,
      duration: newActDur,
      calories: newActCal,
      timeClass: new Date().getHours() < 12 ? 'Morning' : 'Evening'
    };
    setCustomActivities(prev => [...prev, item]);
    setCaloriesBurned(prev => prev + newActCal);
    
    // Reset form
    setNewActEn('');
    setNewActKh('');
  };

  const handleDeleteCustomActivity = (id: string, calories: number) => {
    setCustomActivities(prev => prev.filter(x => x.id !== id));
    setCaloriesBurned(prev => Math.max(0, prev - calories));
  };

  // Automatic smart assessment diagnostic feedback
  const getSymptomFeedback = () => {
    if (selectedSymptoms.length === 0) return null;
    
    const hasEmergency = selectedSymptoms.includes('chest_pain') || selectedSymptoms.includes('breath');
    const hasFever = selectedSymptoms.includes('fever');

    return {
      severity: hasEmergency ? 'Emergency/Severe' : 'Moderate',
      titleEn: hasEmergency 
        ? '⚠️ RED ALERT: Medical Evaluation Advised' 
        : '⚠️ Daily Care Advice for Selected Symptoms',
      titleKh: hasEmergency 
        ? '⚠️ ដំណឹងព្រមាន៖ គួរស្វែងរកការពិគ្រោះបន្ទាន់' 
        : '⚠️ ការណែនាំថែទាំខ្លួនជាប្រចាំ',
      instructionEn: hasEmergency
        ? 'Severe symptoms (Chest Pain / Breathing issues) detected. Please immediately visit Calmette, Khmer-Soviet Friendship, or another hospital listed in our Hospitals tab.'
        : `Primary indicators logged: ${selectedSymptoms.map(s => symptomList.find(sl => sl.id === s)?.titleEn.split('(')[0].trim()).join(', ')}. Keep warm, hydration, and ask physical therapists.`,
      instructionKh: hasEmergency
        ? 'រោគសញ្ញាធ្ងន់ធ្ងរ (ឈឺទ្រូង ឬដកដង្ហើមថប់ៗ) ត្រូវបានជ្រើសរើស។ សូមអញ្ជើញទៅកាន់មន្ទីរពេទ្យកាល់ម៉ែត មិត្តភាពខ្មែរ-សូវៀត ឬមន្ទីរពេទ្យដែលនៅជិតលោកអ្នកបំផុត។'
        : `អាការៈដែលបានជ្រើសរើស៖ ${selectedSymptoms.map(s => symptomList.find(sl => sl.id === s)?.titleKh.split('(')[0] || s).join(', ')}។ សូមពិសារទឹកក្តៅឧណ្ហៗ សម្រាកឲ្យបានគ្រប់គ្រាន់ និងជៀសវាងការប្រាណធ្ងន់ៗ។`
    };
  };

  const symptomFeedback = getSymptomFeedback();

  // Chat referral
  const handleConsultAIAboutSymptoms = () => {
    if (selectedSymptoms.length === 0) {
      navigate('/chat');
      return;
    }
    const loggedStr = selectedSymptoms.map(s => {
      const sym = symptomList.find(x => x.id === s);
      return `${sym?.titleEn} (${sym?.titleKh})`;
    }).join(', ');
    
    const query = t(
      `I am experiencing the following symptoms: ${loggedStr}. Can you analyze what might be causing them, share healthy behaviors, and recommend specialized medical care?`,
      `ខ្ញុំមានអាការៈ និងរោគសញ្ញាដូចជា៖ ${loggedStr}។ តើវាអាចបណ្ដាលមកពីមូលហេតុអ្វីខ្លះ? សូមណែនាំវិធីថែទាំខ្លួន និងមន្ទីរពេទ្យសាកសម។`
    );
    
    // Store in temp session state so ChatPage pre-fills
    sessionStorage.setItem('healith_prefill_chat', query);
    navigate('/chat');
  };

  return (
    <div className="p-4 space-y-5 select-none bg-gradient-to-b from-[#FFFDFE] to-[#FFF9FB] min-h-screen pb-12">
      
      {/* Page Header */}
      <div className="text-center py-4 space-y-1">
        <div className="w-12 h-12 bg-pink-100 rounded-2xl flex items-center justify-center mx-auto text-primary shadow-sm">
          <ClipboardList className="w-6 h-6" />
        </div>
        <h2 className="text-2xl font-serif font-black text-primary-dark mt-1">
          {t('Health Dashboard', 'ការកត់ត្រាសុខភាព')}
        </h2>
        <p className="text-xs text-[#8E6D7A] font-semibold">
          {t('Track daily wellness metrics and symptoms easily', 'ការតាមដានរោគសញ្ញា និងសកម្មភាពរាងកាយងាយៗ')}
        </p>
      </div>

      {/* Tabs Selector with Khmer Localization */}
      <div className="flex bg-[#F9F1F4] rounded-full p-1 border border-[#F2E4E9]">
        <button
          onClick={() => setActiveTab('fitness')}
          className={cn(
            "flex-1 py-3 text-xs font-bold rounded-full transition-all flex items-center justify-center gap-1.5 cursor-pointer",
            activeTab === 'fitness' ? "bg-primary text-white shadow-md scale-102" : "text-[#8E6D7A] hover:bg-pink-50/50"
          )}
        >
          <Dumbbell className="w-4 h-4" />
          <span>{t('Physical Activities', 'សកម្មភាពរាងកាយ')}</span>
        </button>
        <button
          onClick={() => setActiveTab('symptoms')}
          className={cn(
            "flex-1 py-3 text-xs font-bold rounded-full transition-all flex items-center justify-center gap-1.5 cursor-pointer",
            activeTab === 'symptoms' ? "bg-primary text-white shadow-md scale-102" : "text-[#8E6D7A] hover:bg-pink-50/50"
          )}
        >
          <Stethoscope className="w-4 h-4" />
          <span>{t('Symptom Assessment', 'វាយតម្លៃរោគសញ្ញា')}</span>
        </button>
      </div>

      {/* RENDER ACTIVE TAB */}
      <AnimatePresence mode="wait">
        {activeTab === 'fitness' ? (
          <motion.div
            key="fitness"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.25 }}
            className="space-y-4 text-left"
          >
            {/* Quick Metrics Grids */}
            <div className="grid grid-cols-2 gap-4">
              
              {/* Card - Steps */}
              <div className="bg-white p-5 rounded-3xl border border-[#F2E4E9] shadow-sm space-y-3 relative group overflow-hidden">
                <div className="absolute right-0 top-0 w-16 h-16 bg-[#FDF2F5] rounded-bl-[45px] pointer-events-none flex items-center justify-center pl-4 pb-4">
                  <Footprints className="w-5 h-5 text-primary" />
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-[#8E6D7A] uppercase tracking-wider">{t('Steps Walked', 'ចំនួនជំហានដើរ')}</span>
                  <h3 className="text-xl font-serif font-black text-rose-950">{stepCounts.toLocaleString()}</h3>
                  <p className="text-[10px] text-slate-400 font-medium">~{(stepCounts * 0.00075).toFixed(2)} km</p>
                </div>
                <div className="flex gap-1.5 pt-1.5">
                  <button 
                    onClick={() => setStepCounts(prev => Math.max(0, prev - 500))}
                    className="flex-1 py-1 text-xs font-black bg-slate-50 border border-slate-200 hover:bg-slate-100 rounded-xl transition-all cursor-pointer"
                  >
                    -500
                  </button>
                  <button 
                    onClick={() => setStepCounts(prev => prev + 1000)}
                    className="flex-1 py-1 text-xs font-black bg-pink-50 hover:bg-pink-100 text-primary rounded-xl transition-all border border-pink-100 cursor-pointer"
                  >
                    +1k
                  </button>
                </div>
              </div>

              {/* Card - Active Calories */}
              <div className="bg-white p-5 rounded-3xl border border-[#F2E4E9] shadow-sm space-y-3 relative group overflow-hidden">
                <div className="absolute right-0 top-0 w-16 h-16 bg-[#FFF6F0] rounded-bl-[45px] pointer-events-none flex items-center justify-center pl-4 pb-4">
                  <Flame className="w-5 h-5 text-orange-500" />
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-[#8E6D7A] uppercase tracking-wider">{t('Active Calories', 'ការដុតកាឡូរី')}</span>
                  <h3 className="text-xl font-serif font-black text-[#562210]">{caloriesBurned} kcal</h3>
                  <p className="text-[10px] text-slate-400 font-medium">{t('Target: 600 kcal', 'គោលដៅ៖ ៦០០ កាឡូរី')}</p>
                </div>
                <div className="flex gap-1.5 pt-1.5">
                  <button 
                    onClick={() => setCaloriesBurned(prev => Math.max(0, prev - 50))}
                    className="flex-1 py-1 text-xs font-black bg-slate-50 border border-slate-200 hover:bg-slate-100 rounded-xl transition-all cursor-pointer"
                  >
                    -50
                  </button>
                  <button 
                    onClick={() => setCaloriesBurned(prev => prev + 100)}
                    className="flex-1 py-1 text-xs font-black bg-orange-50 hover:bg-orange-100 text-orange-700 rounded-xl transition-all border border-orange-100 cursor-pointer"
                  >
                    +100
                  </button>
                </div>
              </div>

              {/* Card - Hydration level */}
              <div className="bg-white p-5 rounded-3xl border border-[#F2E4E9] shadow-sm space-y-3 relative group overflow-hidden">
                <div className="absolute right-0 top-0 w-16 h-16 bg-[#F0F7FF] rounded-bl-[45px] pointer-events-none flex items-center justify-center pl-4 pb-4">
                  <Droplet className="w-5 h-5 text-blue-500 fill-blue-500" />
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-[#8E6D7A] uppercase tracking-wider">{t('Water Intake', 'ពិសារទឹក')}</span>
                  <h3 className="text-xl font-serif font-black text-blue-950">{(waterCups * 0.25).toFixed(1)} / 2.5 L</h3>
                  <p className="text-[10px] text-slate-400 font-medium">{waterCups} {t('cups drunk', 'កែវ')}</p>
                </div>
                <div className="flex gap-1.5 pt-1.5">
                  <button 
                    onClick={() => setWaterCups(prev => Math.max(0, prev - 1))}
                    className="flex-1 py-1 text-xs font-black bg-slate-50 border border-slate-200 hover:bg-slate-100 rounded-xl transition-all cursor-pointer"
                  >
                    -1
                  </button>
                  <button 
                    onClick={() => setWaterCups(prev => prev + 1)}
                    className="flex-1 py-1 text-xs font-black bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-xl transition-all border border-blue-100 cursor-pointer"
                  >
                    +1
                  </button>
                </div>
              </div>

              {/* Card - Sleep duration */}
              <div className="bg-white p-5 rounded-3xl border border-[#F2E4E9] shadow-sm space-y-3 relative group overflow-hidden">
                <div className="absolute right-0 top-0 w-16 h-16 bg-indigo-50/50 rounded-bl-[45px] pointer-events-none flex items-center justify-center pl-4 pb-4">
                  <Moon className="w-5 h-5 text-indigo-500 fill-indigo-500" />
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-[#8E6D7A] uppercase tracking-wider">{t('Sleep Tracking', 'លំដាប់ដំណេក')}</span>
                  <h3 className="text-xl font-serif font-black text-indigo-950">{sleepHours} hrs</h3>
                  <p className="text-[10px] text-slate-400 font-medium">{t('7-8 hr recommended', '៧-៨ ម៉ោងគឺល្អបំផុត')}</p>
                </div>
                <div className="flex gap-1.5 pt-1.5">
                  <button 
                    onClick={() => setSleepHours(prev => Math.max(0, prev - 1))}
                    className="flex-1 py-1 text-xs font-black bg-slate-50 border border-slate-200 hover:bg-slate-100 rounded-xl transition-all cursor-pointer"
                  >
                    -1 hr
                  </button>
                  <button 
                    onClick={() => setSleepHours(prev => prev + 1)}
                    className="flex-1 py-1 text-xs font-black bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl transition-all border border-indigo-100 cursor-pointer"
                  >
                    +1 hr
                  </button>
                </div>
              </div>
            </div>

            {/* Custom Logged Activities Block */}
            <div className="bg-white p-6 rounded-[28px] border border-[#F2E4E9] shadow-sm space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-pink-100 flex items-center justify-center text-primary shrink-0">
                  <Dumbbell className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-serif font-black text-primary-dark text-base">
                    {t("Logged Activities Today", "សកម្មភាពប្រចាំថ្ងៃសម្រាប់ថ្ងៃនេះ")}
                  </h4>
                  <p className="text-[9px] text-[#8E6D7A] font-bold uppercase tracking-wider">{t("Track your specific local exercising sports", "កត់ត្រាហាត់ប្រាណ កីឡា ឬការងារតូចៗ")}</p>
                </div>
              </div>

              {/* Dynamic Activities List */}
              <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
                {customActivities.length === 0 ? (
                  <p className="text-xs text-slate-400 italic py-4 text-center">
                    {t('No specific sports logged yet. Add one below!', 'មិនទាន់មានលំហាត់ប្រាណកត់ត្រានៅឡើយទេ។ សូមបន្ថែមនៅខាងក្រោម!')}
                  </p>
                ) : (
                  customActivities.map((act) => (
                    <div 
                      key={act.id} 
                      className="p-3 bg-[#FFFAFC]/60 rounded-2xl border border-pink-100/40 flex items-center justify-between gap-3 shadow-xs hover:bg-pink-100/10 transition-all"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-8 h-8 rounded-full bg-orange-100/50 flex items-center justify-center text-orange-500 shrink-0">
                          <Heart className="w-4 h-4 text-orange-600 fill-orange-500/20" />
                        </div>
                        <div className="min-w-0">
                          <h5 className="text-xs font-black text-primary-dark truncate">
                            {language === 'kh' ? act.nameKh : act.nameEn}
                          </h5>
                          <p className="text-[10px] text-[#8E6D7A] flex items-center gap-2 font-medium">
                            <span className="bg-pink-50 px-1.5 py-0.5 rounded text-[8px] font-bold tracking-tight">{act.timeClass}</span>
                            <span>{act.duration} mins</span>
                            <span>•</span>
                            <span className="text-orange-600 font-bold">{act.calories} kcal</span>
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={() => handleDeleteCustomActivity(act.id, act.calories)}
                        className="p-2 text-rose-500 hover:bg-rose-50 rounded-xl cursor-pointer transition-colors active:scale-95 shrink-0"
                        title={t('Delete item', 'លុប')}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))
                )}
              </div>

              {/* Add Workout Form */}
              <form onSubmit={handleAddCustomActivity} className="pt-3 border-t border-dashed border-[#F2E4E9] space-y-3">
                <h5 className="text-[10px] uppercase font-bold tracking-wider text-[#8E6D7A]">{t('Log a custom fitness activity', 'បន្ថែមការហាត់ប្រាណថ្មី')}</h5>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    required
                    required-message="English label required"
                    placeholder="Activity Name (English)"
                    value={newActEn}
                    onChange={(e) => setNewActEn(e.target.value)}
                    className="bg-slate-50 border border-[#F2E4E9] rounded-xl p-2 px-3 text-xs focus:ring-1 focus:ring-primary focus:border-primary focus:outline-none w-full"
                  />
                  <input
                    type="text"
                    placeholder="ឈ្មោះសកម្មភាព (ខ្មែរ)"
                    value={newActKh}
                    onChange={(e) => setNewActKh(e.target.value)}
                    className="bg-slate-50 border border-[#F2E4E9] rounded-xl p-2 px-3 text-xs focus:ring-1 focus:ring-primary focus:border-primary focus:outline-none w-full"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="bg-slate-50 border border-[#F2E4E9] rounded-xl px-3 py-1 flex flex-col gap-0.5">
                    <span className="text-[9px] text-[#8E6D7A] font-bold block">{t('Duration (mins)', 'រយៈពេល (នាទី)')}</span>
                    <input
                      type="number"
                      min={1}
                      max={300}
                      value={newActDur}
                      onChange={(e) => setNewActDur(parseInt(e.target.value) || 1)}
                      className="p-0 border-none outline-none focus:ring-0 bg-transparent text-xs font-black text-rose-950 w-full"
                    />
                  </div>
                  <div className="bg-slate-50 border border-[#F2E4E9] rounded-xl px-3 py-1 flex flex-col gap-0.5">
                    <span className="text-[9px] text-[#8E6D7A] font-bold block">{t('Calories Burned', 'កាឡូរីត្រូវដុត')}</span>
                    <input
                      type="number"
                      min={1}
                      max={2000}
                      value={newActCal}
                      onChange={(e) => setNewActCal(parseInt(e.target.value) || 1)}
                      className="p-0 border-none outline-none focus:ring-0 bg-transparent text-xs font-black text-rose-950 w-full"
                    />
                  </div>
                </div>
                <button
                  type="submit"
                  className="w-full py-2.5 bg-primary hover:bg-primary-dark text-white rounded-xl font-bold text-xs shadow-md shadow-primary/10 transition-all cursor-pointer flex items-center justify-center gap-1"
                >
                  <Plus className="w-4 h-4" />
                  {t('Add to Daily Log', 'បញ្ចូលក្នងកំណត់ហេតុប្រចាំថ្ងៃ')}
                </button>
              </form>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="symptoms"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.25 }}
            className="space-y-4 text-left"
          >
            {/* Header / Banner block just like screenshot */}
            <div className="bg-white p-6 rounded-[28px] border border-[#F2E4E9] space-y-4 shadow-sm">
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 bg-[#FFF0F4] rounded-2xl flex items-center justify-center text-[#E07090] shrink-0 shadow-sm">
                  <Stethoscope className="w-6 h-6 stroke-[2.5]" />
                </div>
                <div>
                  <h3 className="font-serif font-black text-[#5C2A40] text-lg leading-tight">
                    {t('Symptom Assessment', 'វាយតម្លៃរោគសញ្ញា')}
                  </h3>
                  <p className="text-[10px] text-[#8E6D7A] font-bold uppercase tracking-wider mt-0.5">
                    {t('Understand your symptoms in simple steps', 'យល់ដឹងពីរោគសញ្ញារបស់អ្នកក្នុងជំហានងាយៗ')}
                  </p>
                </div>
              </div>

              {/* Disclaimer from user mockup - only shown when not yet completed */}
              {!analysisCompleted && (
                <div className="bg-[#FFFDFD] p-4 rounded-3xl border border-red-150 flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
                  <p className="text-[10px] text-rose-800 leading-relaxed font-semibold">
                    {t(
                      "Disclaimer: Results are educational/informational only. This is not a formal medical diagnosis. If you feel very unwell, please seek emergency medical action immediately.",
                      "សេចក្តីបញ្ជាក់៖ លទ្ធផលនេះគឺសម្រាប់ស្វែងយល់ ឬជាជំនួយការឯកសារប៉ុណ្ណោះ វាមិនមែនជាការធ្វើរោគវិនិច្ឆ័យវេជ្ជសាស្ត្រផ្លូវការឡើយ។ ប្រសិនបើលោកអ្នកមានអារម្មណ៍មិនស្រួលខ្លួនខ្លាំង សូមស្វែងរកការព្យាបាលបន្ទាន់ជាបន្ទាន់។"
                    )}
                  </p>
                </div>
              )}
            </div>

            {/* IF COMPLETED, SHOW THE PREMIUM HIGH-FIDELITY SUMMARY OF CONDITIONS */}
            {analysisCompleted && analysisResult ? (
              <div className="space-y-4 animate-fadeIn">
                {/* 1. SECTION LABEL + START OVER ACTION */}
                <div className="flex items-center justify-between px-1.5 pt-1">
                  <span className="text-[11px] font-black tracking-widest text-[#8E6D7A] uppercase">
                    {t('POSSIBLE HEALTH CONDITIONS', 'លទ្ធផលជំងឺដែលអាចកត់សម្គាល់')}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedSymptoms([]);
                      setAnalysisCompleted(false);
                      setAnalysisResult(null);
                    }}
                    className="flex items-center gap-1 text-[11px] font-black text-[#E1678C] hover:text-[#C54A70] transition-all cursor-pointer select-none"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>{t('Start Over', 'ចាប់ផ្ដើមឡើងវិញ')}</span>
                  </button>
                </div>

                {/* 2. THE HIGH-FIDELITY RESULT CARD (MATCHES MOCKUP DESIGN PRECISELY) */}
                <motion.div
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white p-6 rounded-[32px] border border-[#F2E4E9] shadow-sm relative space-y-4 text-left"
                >
                  {/* Severity Badge & Icon */}
                  <div className="flex items-center justify-between">
                    {analysisResult.severity === 'Severe/Emergency' ? (
                      <span className="bg-rose-50 text-rose-700 border border-rose-100 text-[10px] font-bold uppercase tracking-wider px-3 py-1 rounded-full">
                        {t('HIGH SEVERITY - SEEK CLINICAL ADVICE', 'កម្រិតខ្ពស់ - គួរពិគ្រោះជាមួយគ្រូពេទ្យ')}
                      </span>
                    ) : (
                      <span className="bg-[#EAFDF5] text-emerald-700 border border-emerald-50 text-[10px] font-bold uppercase tracking-wider px-3 py-1 rounded-full">
                        {t('LOW SEVERITY - LOCAL CARE & REST', 'កម្រិតស្រាល - ការថែទាំតាមផ្ទះ & សម្រាក')}
                      </span>
                    )}
                    
                    <AlertTriangle className={cn(
                      "w-5 h-5",
                      analysisResult.severity === 'Severe/Emergency' ? "text-rose-600" : "text-amber-500"
                    )} />
                  </div>

                  {/* Title Header */}
                  <div className="space-y-1">
                    <h4 className="font-sans font-black text-xl text-slate-900 leading-snug">
                      {analysisResult.titleEn}
                    </h4>
                    <p className="text-sm font-bold text-[#E07090] leading-normal font-sans">
                      {analysisResult.titleKh}
                    </p>
                  </div>

                  {/* Grey Information Box with bilingual support */}
                  <div className="bg-[#F8FAFC] p-5 rounded-[22px] border border-slate-100 space-y-3 leading-relaxed mt-1">
                    <p className="text-xs text-slate-600 font-medium">
                      {analysisResult.instructionEn}
                    </p>
                    <p className="text-xs text-slate-800 font-bold leading-relaxed border-t border-slate-150 pt-2.5">
                      {analysisResult.instructionKh}
                    </p>
                  </div>

                  {/* Recommended Guidelines block */}
                  <div className="space-y-2 pt-2">
                    <div className="flex items-center gap-1.5 pt-1">
                      <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500 shrink-0" />
                      <h5 className="font-black text-[10px] text-[#8E6D7A] tracking-widest uppercase">
                        {t('RECOMMENDED GUIDELINES', 'ការណែនាំអំពីការថែទាំដែលគួរធ្វើ')}
                      </h5>
                    </div>

                    <div className="space-y-2.5 mt-2">
                      {(() => {
                        const parseBulletList = (text: string | string[] | undefined): string[] => {
                          if (!text) return [];
                          if (Array.isArray(text)) return text;
                          return text
                            .split('\n')
                            .map(line => line.replace(/^[•\-\*\d\.\s]+/, '').trim())
                            .filter(line => line.length > 0);
                        };

                        const guidelinesEn = parseBulletList(analysisResult.suggestedRemediesEn);
                        const guidelinesKh = parseBulletList(analysisResult.suggestedRemediesKh);
                        const guidelines = language === 'kh' && guidelinesKh.length > 0 ? guidelinesKh : guidelinesEn;

                        return guidelines.map((guideline, idx) => (
                          <div key={idx} className="bg-white p-3 pr-4 rounded-xl shadow-[0_1px_3px_rgba(0,0,0,0.015)] flex items-center gap-3 border border-slate-50">
                            <div className="w-5 h-5 bg-[#FFF0F4] border border-pink-100 rounded-full flex items-center justify-center shrink-0">
                              <Check className="w-3 h-3 text-pink-600 stroke-[3]" />
                            </div>
                            <p className="text-xs text-slate-700 font-semibold leading-normal">
                              {guideline}
                            </p>
                          </div>
                        ));
                      })()}
                    </div>
                  </div>

                  {/* Additional Clinical Referral tags */}
                  {analysisResult.specialistEn && (
                    <div className="space-y-1.5 pt-3 border-t border-slate-100 mt-2">
                      <h5 className="font-black text-[9px] text-[#8E6D7A] tracking-widest uppercase">
                        {t('RECOMMENDED CLINICAL SPECIALTY', 'ផ្នែកគ្រូពេទ្យឯកទេសណែនាំ')}
                      </h5>
                      <span className="text-[10px] font-bold text-primary bg-[#FFF1F5] border border-pink-100 px-3 py-1 rounded-full inline-block">
                        {language === 'kh' ? analysisResult.specialistKh : analysisResult.specialistEn}
                      </span>
                    </div>
                  )}
                </motion.div>

                {/* 3. DISCLAIMER BANNER AT THE BOTTOM */}
                <div className="bg-[#FFF0F4] border border-[#FDE2EC] text-rose-800 rounded-[24px] p-4 px-6 text-center mt-3 shadow-inner">
                  <p className="text-[10.5px] leading-relaxed font-semibold">
                    💡 <span className="font-black">{t('Disclaimer', 'ការបញ្ជាក់')}</span>: {t(
                      "Results are educational/informational only. This is not a formal medical diagnosis. If you feel very unwell, please seek emergency medical action immediately.",
                      "លទ្ធផលនេះគឺសម្រាប់ស្វែងយល់ ឬជាជំនួយការឯកសារប៉ុណ្ណោះ វាមិនមែនជាការធ្វើរោគវិនិច្ឆ័យវេជ្ជសាស្ត្រផ្លូវការឡើយ។ ប្រសិនបើលោកអ្នកមានអារម្មណ៍មិនស្រួលខ្លួនខ្លាំង សូមស្វែងរកការព្យាបាលបន្ទាន់ជាបន្ទាន់។"
                    )}
                  </p>
                </div>

                {/* 4. SMART DOCTOR AI CONSULTATION TRANSITION CARD */}
                <motion.div 
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-white p-5 rounded-[28px] border border-[#FAF2F5] shadow-sm flex flex-col gap-3 mt-1 text-left"
                >
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-primary shrink-0" />
                    <h4 className="font-black text-xs text-[#8E6D7A] uppercase tracking-wider">
                      {t('AI Consultation Referral', 'ពិគ្រោះបន្ថែមជាមួយប្រព័ន្ធឆ្លាតវៃ')}
                    </h4>
                  </div>
                  <p className="text-xs text-[#8E6D7A] leading-relaxed">
                    {t(
                      "Our specialized Cambodian medical AI is ready to discuss precise solutions, advise on healthy living steps, and suggest specific hospital timings.",
                      "ជំនួយការវេជ្ជសាស្ត្រ AI របស់ពួកយើង រួចរាល់ក្នុងការពិគ្រោះលម្អិត បង្ហាញការការពារខ្លួន និងណែនាំគ្រូពេទ្យឯកទេសសម្រាប់លោកអ្នក។"
                    )}
                  </p>

                  <div className="flex gap-2 pt-1">
                    <button
                      onClick={() => {
                        setSelectedSymptoms([]);
                        setAnalysisCompleted(false);
                        setAnalysisResult(null);
                      }}
                      className="px-4 py-3 bg-[#FAF2F5] hover:bg-rose-50 text-rose-600 border border-[#F2E4E9] rounded-xl text-xs font-black transition-all cursor-pointer select-none"
                    >
                      {t('Clear', 'ជម្រះ')}
                    </button>
                    <button
                      onClick={handleConsultAIAboutSymptoms}
                      className="flex-1 py-3 bg-primary hover:bg-primary-dark text-white rounded-xl text-xs font-black shadow-md shadow-primary/10 transition-all flex items-center justify-center gap-1.5 cursor-pointer select-none"
                    >
                      <MessageSquare className="w-4 h-4 fill-white/10" />
                      <span>
                        {t('Ask Doctor AI', 'ពិគ្រោះជាមួយ Doctor AI')}
                      </span>
                      <ChevronRight className="w-4 h-4 text-white/50" />
                    </button>
                  </div>
                </motion.div>
              </div>
            ) : (
              <>
                {/* SYMPTOM CHECK SELECTION LIST (PRECISLY MATCHING MOCKUP COMPOSITION) */}
                <div className="space-y-3">
                  <div className="px-2">
                    <h4 className="text-[10px] font-black tracking-widest text-[#8E6D7A] uppercase">
                      {t('SELECT ALL SYMPTOMS THAT APPLY TO YOU:', 'សូមជ្រើសរើសរោគសញ្ញាទាំងអស់ដែលត្រូវនឹងលោកអ្នក៖')}
                    </h4>
                  </div>

                  <div className="space-y-2.5">
                    {symptomList.map((item) => {
                      const isChecked = selectedSymptoms.includes(item.id);
                      return (
                        <button
                          key={item.id}
                          onClick={() => handleToggleSymptom(item.id)}
                          className={cn(
                            "w-full text-left p-4 rounded-[22px] border transition-all cursor-pointer flex items-start justify-between gap-4 select-none duration-150 relative",
                            isChecked 
                              ? "bg-[#FFF2F6] border-primary shadow-sm scale-[1.01]" 
                              : "bg-white border-[#F2E4E9] hover:bg-pink-50/20 hover:border-pink-300"
                          )}
                        >
                          <div className="space-y-1 pr-4">
                            {/* Title block with English / Khmer matching mockup */}
                            <h4 className="text-[13px] font-black text-rose-950 leading-tight">
                              {item.titleEn}
                            </h4>
                            <p className="text-xs text-[#8E6D7A] leading-snug font-medium">
                              {item.titleKh}
                            </p>
                            
                            {/* Expanded details help when active */}
                            {isChecked && (
                              <motion.p 
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: "auto" }}
                                className="text-[10px] text-[#A6446E] italic pt-1.5 font-bold transition-all"
                              >
                                💡 {language === 'kh' ? item.infoKh : item.infoEn}
                              </motion.p>
                            )}
                          </div>

                          {/* Custom circular indicator box matching layout */}
                          <div className="shrink-0 mt-1">
                            <div className={cn(
                              "w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all duration-200",
                              isChecked 
                                ? "border-primary bg-primary text-white" 
                                : "border-slate-200 bg-white"
                            )}>
                              {isChecked && <Check className="w-3.5 h-3.5 stroke-[3.5]" />}
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Analyze Trigger Action Button */}
                {selectedSymptoms.length > 0 && !isAnalyzing && !analysisCompleted && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="pt-2 text-center"
                  >
                    <button
                      type="button"
                      onClick={handleAnalyzeSymptoms}
                      className="w-full py-4 bg-primary hover:bg-primary-dark text-white rounded-3xl font-black text-sm tracking-wide shadow-lg shadow-primary/10 transition-all hover:scale-[1.01] active:scale-[0.99] cursor-pointer flex items-center justify-center gap-2 border border-primary/25"
                    >
                      <Sparkles className="w-5 h-5 text-[#FFE0EA] " />
                      <span>{t('Analyze Symptoms Now', 'វាយតម្លៃរោគសញ្ញាឥឡូវនេះ')}</span>
                      <ChevronRight className="w-4 h-4 text-white/70" />
                    </button>
                  </motion.div>
                )}

                {/* Custom Premium Animated Analyzing Loader */}
                {isAnalyzing && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-white p-7 rounded-[28px] border border-pink-200/50 flex flex-col items-center justify-center space-y-4 text-center py-10 shadow-sm"
                  >
                    <div className="relative flex items-center justify-center">
                      <div className="w-14 h-14 rounded-full border-4 border-dashed border-pink-150 border-t-primary animate-spin" />
                      <Sparkles className="w-5 h-5 text-primary absolute" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="font-serif font-black text-primary-dark text-sm">
                        {t('Healith AI is analyzing symptoms...', 'ជំនួយការ AI កុងវិភាគរោគសញ្ញា...')}
                      </h4>
                      <p className="text-[10px] text-[#8E6D7A] font-medium leading-relaxed max-w-xs mx-auto">
                        {t('Checking risk indicators, recommending local home remedies & clinic guidelines', 'កំពុងផ្ទៀងផ្ទាត់កម្រិតគ្រោះថ្នាក់ វិធីព្យាបាលបឋម និងស្វែងរកវេជ្ជបណ្ឌិតជំនាញ')}
                      </p>
                    </div>
                  </motion.div>
                )}
              </>
            )}

          </motion.div>
        )}
      </AnimatePresence>

      {/* Daily Motivation health advice */}
      <section className="bg-white/40 p-4 rounded-2xl border border-[#FAF2F5] flex items-center justify-center gap-2.5">
        <TrendingUp className="w-4 h-4 text-emerald-500 shrink-0" />
        <p className="text-[10px] text-[#8E6D7A] font-bold leading-normal italic text-center">
          {t('💡 Tracking metrics daily helps doctors understand physical parameters better.', '💡 ការកត់ត្រាសូចនាករប្រចាំថ្ងៃជួយឲ្យគ្រូពេទ្យពិនិត្យអាការៈបានត្រឹមត្រូវជាងមុន។')}
        </p>
      </section>

    </div>
  );
}
