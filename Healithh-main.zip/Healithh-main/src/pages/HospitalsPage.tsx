/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, Search, Star, Phone, Clock, ShieldCheck, ChevronRight, X, ExternalLink, Filter, Heart } from 'lucide-react';
import { HOSPITALS } from '../constants';
import { Hospital } from '../types';
import { supabaseService } from '../services/supabaseService';
import { cn } from '../utils';
import { useLanguage } from '../context/LanguageContext';

let API_KEY = '';
try {
  API_KEY = (typeof process !== 'undefined' && process.env?.GOOGLE_MAPS_PLATFORM_KEY) || '';
} catch {
  // fallback if process is not defined
}
const hasValidKey = Boolean(API_KEY) && API_KEY !== 'YOUR_API_KEY';

export default function HospitalsPage() {
  const { t, language } = useLanguage();
  const [search, setSearch] = useState('');
  const [emergencyOnly, setEmergencyOnly] = useState(false);
  const [showBookmarksOnly, setShowBookmarksOnly] = useState(false);
  const [selectedHospital, setSelectedHospital] = useState<Hospital | null>(null);
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);

  // Load bookmarks on mount
  useEffect(() => {
    const fetchBookmarks = async () => {
      const records = await supabaseService.getBookmarks();
      const hospitalIds = records
        .filter(r => r.item_type === 'hospital')
        .map(r => r.item_id);
      setBookmarkedIds(hospitalIds);
    };
    fetchBookmarks();
  }, []);

  const handleToggleBookmark = async (hospitalId: string) => {
    const isNowBookmarked = await supabaseService.toggleBookmark(hospitalId, 'hospital');
    if (isNowBookmarked) {
      setBookmarkedIds(prev => [...prev, hospitalId]);
    } else {
      setBookmarkedIds(prev => prev.filter(id => id !== hospitalId));
    }
  };

  const filteredHospitals = HOSPITALS.filter(h => {
    const matchesSearch = h.nameEn.toLowerCase().includes(search.toLowerCase()) || h.nameKh.includes(search);
    const matchesEmergency = !emergencyOnly || h.isEmergency;
    const matchesBookmarks = !showBookmarksOnly || bookmarkedIds.includes(h.id);
    return matchesSearch && matchesEmergency && matchesBookmarks;
  });


  return (
    <div className="p-4 space-y-6">
      {/* Search & Filter Header */}
      <div className="space-y-4">
        <div className="relative">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-[#D6BAC6]" />
          <input
            type="text"
            placeholder={t('Search hospitals by name...', 'ស្វែងរកមន្ទីរពេទ្យ...')}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-white border border-[#F2E4E9] rounded-[24px] pl-14 pr-5 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-primary/10 focus:border-primary shadow-sm transition-all text-[#4A3B43]"
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="flex gap-2">
            <button
              onClick={() => setEmergencyOnly(!emergencyOnly)}
              className={cn(
                "px-5 py-2.5 rounded-2xl text-[11px] font-bold border flex items-center gap-2 transition-all uppercase tracking-widest cursor-pointer",
                emergencyOnly
                  ? "bg-rose-50 border-rose-200 text-rose-600 shadow-sm"
                  : "bg-white border-[#F2E4E9] text-[#8E6D7A]"
              )}
            >
              <ShieldCheck className="w-4 h-4" />
              Emergency 24/7
            </button>
            <button
              onClick={() => setShowBookmarksOnly(!showBookmarksOnly)}
              className={cn(
                "px-5 py-2.5 rounded-2xl text-[11px] font-bold border flex items-center gap-2 transition-all uppercase tracking-widest cursor-pointer",
                showBookmarksOnly
                  ? "bg-pink-100 border-pink-200 text-pink-700 shadow-sm"
                  : "bg-white border-[#F2E4E9] text-[#8E6D7A]"
              )}
            >
              <Heart className={cn("w-4 h-4", showBookmarksOnly ? "fill-pink-700 text-pink-700" : "")} />
              {t('Saved', 'ពេញចិត្ត')}
            </button>
          </div>
          <button className="p-3 bg-white border border-[#F2E4E9] rounded-2xl text-[#D6BAC6] hover:text-primary transition-colors shadow-sm cursor-pointer">
            <Filter className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Hospital List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-[10px] font-bold text-[#8E6D7A] uppercase tracking-[0.2em]">
            {filteredHospitals.length} Top Facilities
          </h3>
          <div className="text-[10px] font-bold text-primary px-3 py-1 bg-accent/40 rounded-full">Phnom Penh</div>
        </div>
        <div className="grid gap-4">
          {filteredHospitals.map((hospital) => (
            <HospitalCard
              key={hospital.id}
              hospital={hospital}
              onClick={() => setSelectedHospital(hospital)}
              lang={language}
              t={t}
              isBookmarked={bookmarkedIds.includes(hospital.id)}
              onToggleBookmark={() => handleToggleBookmark(hospital.id)}
            />
          ))}
          {filteredHospitals.length === 0 && (
            <div className="text-center py-16 space-y-4 bg-white/50 rounded-[32px] border border-dashed border-[#F2E4E9]">
              <div className="bg-accent rounded-full w-14 h-14 flex items-center justify-center mx-auto">
                <Heart className="w-6 h-6 text-primary" />
              </div>
              <p className="text-[#8E6D7A] text-sm font-medium italic">No matching hospitals found.</p>
            </div>
          )}
        </div>
      </div>

      {/* Hospital Modal */}
      <AnimatePresence>
        {selectedHospital && (
          <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center p-4 bg-primary-dark/40 backdrop-blur-md">
            <motion.div
              initial={{ y: "100%", opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: "100%", opacity: 0 }}
              className="bg-white w-full max-w-lg rounded-t-[40px] sm:rounded-[40px] overflow-hidden max-h-[90vh] flex flex-col shadow-2xl"
            >
              <div className="relative h-56 overflow-hidden shrink-0">
                <img
                  src={selectedHospital.imageUrl}
                  alt={selectedHospital.nameEn}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <button
                  onClick={() => setSelectedHospital(null)}
                  className="absolute top-5 right-5 p-2.5 bg-black/20 backdrop-blur-md rounded-full text-white hover:bg-black/40 transition-colors cursor-pointer z-10"
                >
                  <X className="w-5 h-5" />
                </button>
                <button
                  onClick={() => handleToggleBookmark(selectedHospital.id)}
                  className="absolute top-5 left-5 p-2.5 bg-white/90 backdrop-blur-sm rounded-full text-primary hover:bg-white transition-colors shadow-md cursor-pointer z-10 flex items-center justify-center"
                  title="Toggle Saved Bookmark"
                >
                  <Heart className={cn("w-5 h-5 transition-all active:scale-90", bookmarkedIds.includes(selectedHospital.id) ? "fill-primary text-primary" : "text-slate-400")} />
                </button>

                <div className="absolute bottom-5 left-5 flex gap-2">
                   <div className="px-4 py-1.5 bg-white/90 backdrop-blur-sm rounded-full text-[10px] font-bold text-primary-dark uppercase tracking-widest border border-primary/20">
                    {selectedHospital.priceRange} Price Tier
                  </div>
                  {selectedHospital.isEmergency && (
                    <div className="px-4 py-1.5 bg-rose-600 text-white rounded-full text-[10px] font-bold uppercase tracking-widest border border-rose-500 shadow-lg shadow-rose-600/20">
                      Emergency 24/7
                    </div>
                  )}
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-8 space-y-8">
                <div className="flex justify-between items-start gap-4">
                  <div className="space-y-1">
                    <h2 className="text-2xl font-serif font-bold text-primary-dark leading-tight">{selectedHospital.nameEn}</h2>
                    <p className="text-xl font-medium text-primary tracking-tight leading-tight">{selectedHospital.nameKh}</p>
                  </div>
                  <div className="flex items-center gap-1.5 px-3 py-2 bg-accent/30 rounded-2xl border border-accent">
                    <Star className="w-4 h-4 text-primary fill-primary" />
                    <span className="text-xs font-bold text-primary-dark">{selectedHospital.rating}</span>
                  </div>
                </div>

                {/* Map Preview Placeholder */}
                <div className="w-full h-44 bg-[#F9F1F4] rounded-3xl border border-[#F2E4E9] overflow-hidden relative shadow-inner">
                   {!hasValidKey ? (
                     <div className="inset-0 flex flex-col items-center justify-center p-6 text-center">
                        <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm mb-3">
                          <MapPin className="w-6 h-6 text-primary opacity-30" />
                        </div>
                        <p className="text-[10px] font-bold text-[#8E6D7A] uppercase tracking-widest leading-loose">
                          Interactive Health Map <br /> Key Registration Pending
                        </p>
                        <a href="https://console.cloud.google.com/google/maps-apis/start" target="_blank" className="text-[10px] text-primary mt-2 font-bold underline underline-offset-4">Learn More</a>
                     </div>
                   ) : (
                     <div className="inset-0 flex items-center justify-center bg-[#FCE6F1]/20">
                        <p className="text-xs font-bold text-[#8E6D7A] italic animate-pulse">Establishing Connection...</p>
                     </div>
                   )}
                </div>

                <div className="space-y-5">
                  <InfoRow icon={<MapPin className="w-5 h-5" />} title="Location" value={selectedHospital.address} />
                  <InfoRow icon={<Phone className="w-5 h-5" />} title="Line Contact" value={selectedHospital.contact} isLink />
                  <InfoRow icon={<Clock className="w-5 h-5" />} title="Operational" value={selectedHospital.hours} />
                </div>

                <div className="space-y-4 pt-2">
                  <h5 className="text-[10px] font-bold text-[#D6BAC6] uppercase tracking-[0.2em]">Core Medical Services</h5>
                  <div className="flex flex-wrap gap-2.5">
                    {selectedHospital.services.map((service, i) => (
                      <span key={i} className="px-4 py-2 bg-white border border-[#F2E4E9] rounded-2xl text-[12px] font-bold text-[#4A3B43] shadow-sm">
                        {service}
                      </span>
                    ))}
                  </div>
                </div>

                <button className="w-full py-5 bg-primary-dark text-white rounded-[24px] font-bold flex items-center justify-center gap-3 shadow-xl shadow-primary-dark/20 hover:bg-primary transition-all active:scale-95 group">
                  <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center group-hover:bg-white/20">
                    <Phone className="w-4 h-4" />
                  </div>
                  Secure Direct Line
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

interface HospitalCardProps {
  hospital: Hospital;
  onClick: () => void;
  lang: string;
  t: (en: string, kh: string) => string;
  isBookmarked: boolean;
  onToggleBookmark: () => void;
}

const HospitalCard: React.FC<HospitalCardProps> = ({ hospital, onClick, lang, t, isBookmarked, onToggleBookmark }) => {
  return (
    <motion.div
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className="bg-white p-5 rounded-[32px] border border-[#F2E4E9] space-y-5 cursor-pointer hover:shadow-xl transition-all group overflow-hidden relative"
    >
      <div className="flex gap-5">
        <div className="w-20 h-20 rounded-2xl overflow-hidden shrink-0 shadow-sm">
          <img src={hospital.imageUrl} alt={hospital.nameEn} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" referrerPolicy="no-referrer" />
        </div>
        <div className="flex-1 min-w-0 flex flex-col justify-center">
          <div className="flex justify-between items-start">
            <h4 className="font-serif font-bold text-primary-dark text-lg truncate leading-tight">
              {lang === 'en' ? hospital.nameEn : hospital.nameKh}
            </h4>
            <div className="flex items-center gap-2 ml-2 shrink-0">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleBookmark();
                }}
                className="p-1.5 bg-pink-50/50 hover:bg-pink-100/80 rounded-lg text-[#8E6D7A] transition-colors cursor-pointer"
                title={isBookmarked ? "Remove from bookmarks" : "Add to bookmarks"}
              >
                <Heart className={cn("w-3.5 h-3.5 transition-all active:scale-95", isBookmarked ? "fill-primary text-primary" : "text-slate-400")} />
              </button>
              <div className="flex items-center gap-1.5 px-2 py-1 bg-accent/40 rounded-lg">
                <Star className="w-3 h-3 text-primary fill-primary" />
                <span className="text-[10px] font-bold text-primary-dark">{hospital.rating}</span>
              </div>
            </div>
          </div>
          <p className="text-[13px] text-primary font-medium truncate mt-1 italic">
            {lang === 'kh' ? hospital.nameEn : hospital.nameKh}
          </p>
          <div className="flex items-center gap-4 mt-3">
             <span className="text-[9px] font-bold text-[#D6BAC6] flex items-center gap-1.5 uppercase tracking-widest leading-none">
              <Clock className="w-3 h-3" /> {hospital.hours}
            </span>
             <span className="text-[9px] font-bold text-[#D6BAC6] uppercase tracking-widest leading-none flex items-center gap-1.5">
              <div className="w-1 h-1 rounded-full bg-[#FCE6F1]" /> {hospital.priceRange} {t('TIER', 'កម្រិត')}
            </span>
          </div>
        </div>
      </div>
      <div className="pt-4 border-t border-bg-natural flex items-center justify-between">
        <div className="flex items-center gap-2 text-[10px] text-[#D6BAC6] truncate max-w-[80%] font-bold uppercase tracking-wider">
          <MapPin className="w-3 h-3 shrink-0 text-primary opacity-40" />
          {hospital.address}
        </div>
        <div className="p-2 bg-accent rounded-full group-hover:bg-primary group-hover:text-white transition-colors">
          <ChevronRight className="w-4 h-4" />
        </div>
      </div>
    </motion.div>
  );
}

function InfoRow({ icon, title, value, isLink }: { icon: React.ReactNode; title: string; value: string; isLink?: boolean }) {
  return (
    <div className="flex gap-4">
      <div className="w-9 h-9 rounded-xl bg-[#F9F1F4] flex items-center justify-center text-[#D6BAC6] shrink-0">
        {icon}
      </div>
      <div>
        <h6 className="text-[10px] font-bold text-[#D6BAC6] uppercase tracking-widest leading-tight">{title}</h6>
        {isLink ? (
          <a href={`tel:${value}`} className="text-sm font-bold text-primary flex items-center gap-1 underline underline-offset-2">
            {value} <ExternalLink className="w-3 h-3" />
          </a>
        ) : (
          <p className="text-sm font-medium text-[#4A3B43] leading-snug">{value}</p>
        )}
      </div>
    </div>
  );
}
