/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Bot, User, ShieldAlert, Sparkles, Loader2, Info, Database, Trash2, Copy, Check } from 'lucide-react';
import { ChatMessage } from '../types';
import { geminiService } from '../services/geminiService';
import { supabaseService } from '../services/supabaseService';
import { cn } from '../utils';
import { useLanguage } from '../context/LanguageContext';

export default function ChatPage() {
  const { t, language } = useLanguage();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showConfig, setShowConfig] = useState(false);
  const [copied, setCopied] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Clear chat messages from Supabase (or localStorage fallback) on mount / refresh
  useEffect(() => {
    const clearHistoryOnRefresh = async () => {
      await supabaseService.clearMessages();
      setMessages([
        {
          id: '0',
          role: 'model',
          text: t(
            'Hello! I am Healith AI. I can explain symptoms, diseases, and suggest basic prevention methods in Khmer or English. How can I help you today?',
            'សួស្តី! ខ្ញុំគឺ Healith AI។ ខ្ញុំអាចពន្យល់ពីរោគសញ្ញា ជំងឺ និងណែនាំវិធីបង្ការជាភាសាខ្មែរ ឬអង់គ្លេស។ តើខ្ញុំអាចជួយអ្នកអ្វីបានខ្លះនៅថ្ងៃនេះ?'
          ),
          timestamp: Date.now(),
        },
      ]);
    };
    clearHistoryOnRefresh();
  }, [t]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: input,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    // Persist user message to Supabase
    await supabaseService.saveMessage(userMessage);

    try {
      // Pass the current language to the service for better context
      const chatPrompt = `[User Language: ${language === 'kh' ? 'Khmer' : 'English'}] ${input}`;
      
      const currentUser = supabaseService.getCurrentUser();
      const suf = currentUser?.id || 'demo_tester';
      const patientInfo = {
        age: localStorage.getItem(`healith_patient_age_${suf}`) || '26 years',
        gender: localStorage.getItem(`healith_patient_gender_${suf}`) || 'Female',
        location: localStorage.getItem(`healith_patient_location_${suf}`) || 'Sangkat Srah Chork, Phnom Penh',
      };

      // Pass messages + newest userMessage to keep full chat history contextual
      const response = await geminiService.chat(chatPrompt, [...messages, userMessage], patientInfo);
      
      const aiMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: response || t('Sorry, I couldn\'t process that. Please try again.', 'សុំទោស ខ្ញុំមិនអាចដំណើរការវាបានទេ។ សូមព្យាយាមម្តងទៀត។'),
        timestamp: Date.now(),
      };
      
      setMessages((prev) => [...prev, aiMessage]);
      
      // Persist AI response message to Supabase
      await supabaseService.saveMessage(aiMessage);
    } catch (error: any) {
      const errorMsg = error?.message || String(error);
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: `${t('Error: Connection lost. Please check your API key.', 'កំហុស៖ ការតភ្ជាប់ត្រូវបានបាត់បង់។ សូមពិនិត្យមើល API key របស់អ្នក។')} (${errorMsg})`,
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearHistory = async () => {
    if (window.confirm(t('Are you sure you want to clear your chat history?', 'តើអ្នកពិតជាចង់លុបប្រវត្តិនៃការសន្ទនាមែនទេ?'))) {
      await supabaseService.clearMessages();
      setMessages([
        {
          id: '0',
          role: 'model',
          text: t(
            'Hello! I am Healith AI. I can explain symptoms, diseases, and suggest basic prevention methods in Khmer or English. How can I help you today?',
            'សួស្តី! ខ្ញុំគឺ Healith AI។ ខ្ញុំអាចពន្យល់ពីរោគសញ្ញា ជំងឺ និងណែនាំវិធីបង្ការជាភាសាខ្មែរ ឬអង់គ្លេស។ តើខ្ញុំអាចជួយអ្នកអ្វីបានខ្លះនៅថ្ងៃនេះ?'
          ),
          timestamp: Date.now(),
        },
      ]);
    }
  };

  const handleCopySQL = () => {
    navigator.clipboard.writeText(supabaseService.getDatabaseSetupSQL());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null);

  const handleCopyMessage = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMessageId(id);
    setTimeout(() => setCopiedMessageId(null), 2000);
  };

  const renderFormattedContent = (text: string) => {
    const lines = text.split('\n');
    return lines.map((line, index) => {
      let content = line;
      
      // Handle Bold text **bold**
      const boldRegex = /\*\*(.*?)\*\*/g;
      const parts = [];
      let lastIdx = 0;
      let match;
      
      while ((match = boldRegex.exec(line)) !== null) {
        if (match.index > lastIdx) {
          parts.push(line.substring(lastIdx, match.index));
        }
        parts.push(
          <strong key={match.index} className="font-bold text-[#2A1D23] bg-[#FFF0F4] px-1 rounded-sm border border-pink-100/30">
            {match[1]}
          </strong>
        );
        lastIdx = boldRegex.lastIndex;
      }
      if (lastIdx < line.length) {
        parts.push(line.substring(lastIdx));
      }

      const formattedLine = parts.length > 0 ? parts : line;

      // Check for headings
      if (line.startsWith('### ')) {
        return (
          <h4 key={index} className="font-serif font-black text-[#5F1932] text-[14px] mt-4 mb-2 first:mt-0 tracking-tight flex items-center gap-1.5 border-b border-pink-100/30 pb-1">
            <span className="w-1.5 h-1.5 rounded-full bg-primary" />
            {line.replace('### ', '')}
          </h4>
        );
      }
      if (line.startsWith('## ') || line.startsWith('# ')) {
        return (
          <h3 key={index} className="font-serif font-black text-primary-dark text-base mt-5 mb-2.5 first:mt-0 tracking-tight border-b border-pink-100/40 pb-1">
            {line.replace(/^#+\s+/, '')}
          </h3>
        );
      }

      // Check for list items
      if (line.trim().startsWith('- ') || line.trim().startsWith('* ')) {
        const itemText = line.replace(/^\s*[-*]\s+/, '');
        let cleanItemParts = [];
        let itemLastIdx = 0;
        let itemMatch;
        while ((itemMatch = boldRegex.exec(itemText)) !== null) {
          if (itemMatch.index > itemLastIdx) {
            cleanItemParts.push(itemText.substring(itemLastIdx, itemMatch.index));
          }
          cleanItemParts.push(
            <strong key={itemMatch.index} className="font-bold text-[#200B14]">
              {itemMatch[1]}
            </strong>
          );
          itemLastIdx = boldRegex.lastIndex;
        }
        if (itemLastIdx < itemText.length) {
          cleanItemParts.push(itemText.substring(itemLastIdx));
        }

        return (
          <div key={index} className="flex items-start gap-2 ml-1 mt-1.5 leading-relaxed text-[#4A3B43]/90">
            <span className="text-primary text-[10px] select-none mt-1 shrink-0">✦</span>
            <span className="text-[13px]">{cleanItemParts.length > 0 ? cleanItemParts : itemText}</span>
          </div>
        );
      }

      // Default normal block or empty
      if (line.trim() === '') {
        return <div key={index} className="h-2" />;
      }

      return (
        <p key={index} className="text-[13px] leading-relaxed text-[#4A3B43] mt-2 first:mt-0">
          {formattedLine}
        </p>
      );
    });
  };

  const isSupabaseLive = supabaseService.isConfigured();

  return (
    <div className="fixed top-16 bottom-18 left-0 right-0 max-w-lg mx-auto flex flex-col bg-white border-x border-[#F2E4E9] z-20">
      {/* Chat Header Info */}
      <div className="bg-white px-5 py-3 border-b border-[#F2E4E9] flex items-center justify-between shrink-0 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-pink-100/60 border border-pink-100 flex items-center justify-center text-primary shadow-xs shrink-0 animate-pulse-slow">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-serif font-black text-primary-dark text-sm leading-tight">
              {t('Healith AI Helper', 'ជំនួយការសុខភាព AI')}
            </h2>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
              <p className="text-[9px] text-[#8E6D7A] font-bold uppercase tracking-wider leading-none">
                {t('Online Consultation', 'ពិគ្រោះយោបល់ផ្ទាល់')}
              </p>
            </div>
          </div>
        </div>

        {/* Action Header Items */}
        <div className="flex items-center gap-2">
          {/* Cloud Database Integration button */}
          <button
            onClick={() => setShowConfig(true)}
            className={cn(
              "p-2 rounded-xl border flex items-center gap-1.5 transition-all text-[11px] font-bold cursor-pointer hover:scale-102 active:scale-98",
              isSupabaseLive 
                ? "bg-emerald-50/60 border-emerald-100 text-emerald-800" 
                : "bg-pink-50/40 border-[#F2E4E9] text-[#8E6D7A] hover:bg-pink-50"
            )}
            title={isSupabaseLive ? "Cloud storage connected" : "Local offline storage mode"}
          >
            <Database className="w-3.5 h-3.5" />
            <span className="hidden xs:inline">{isSupabaseLive ? 'Cloud DB' : 'Offline'}</span>
          </button>

          {/* Clean conversation trash index */}
          <button
            onClick={handleClearHistory}
            className="p-2 rounded-xl bg-rose-50 hover:bg-rose-100/80 border border-rose-100 text-[#C1446E] transition-all cursor-pointer hover:scale-102 active:scale-98"
            title={t('Clear history list', 'លុបប្រវត្តិ')}
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Safety Notice Strip */}
      <div className="bg-[#FFF5F8] px-4 py-2 flex items-center justify-between gap-3 border-b border-[#F2E4E9]/60 shrink-0 select-none">
        <div className="flex items-center gap-2">
          <Info className="w-3.5 h-3.5 text-primary" />
          <p className="text-[10px] text-[#A28290] font-semibold tracking-wide uppercase">
            {t('AI models make mistakes. In emergency, dial 119.', 'AI អាចមានការភាន់ច្រឡំ។ ករណីអាសន្ន សូមទូរស័ព្ទទៅលេខ ១១៩។')}
          </p>
        </div>
        <div className="flex items-center gap-1 text-[9px] bg-white border border-pink-100 px-2 py-0.5 rounded-full text-primary font-black shrink-0 tracking-wider">
          {language === 'kh' ? 'ខ្មែរ / ENG' : 'ENG / KH'}
        </div>
      </div>

      {/* Messages Thread list */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-5 bg-[#FFFBFC]">
        <AnimatePresence initial={false}>
          {messages.length <= 1 ? (
            /* Beautified Welcome Mascot view */
            <motion.div 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-col items-center justify-center text-center py-6 px-2 space-y-6 max-w-sm mx-auto select-none"
            >
              <div className="relative w-36 h-36 mt-2">
                <svg viewBox="0 0 200 200" className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
                  {/* Cute glowing back shadow */}
                  <circle cx="100" cy="100" r="75" fill="#FFB7C5" fillOpacity="0.25" className="blur-md" />
                  
                  {/* Speech bubble main body */}
                  <rect x="25" y="30" width="150" height="120" rx="60" fill="url(#botGradient)" stroke="#FF8EA4" strokeWidth="4.5" />
                  
                  {/* Speech pointer tail */}
                  <path d="M70 148 l-20 22 q-2 2 -4 -1 l2 -21 z" fill="#FFF0F3" stroke="#FF8EA4" strokeWidth="4" strokeLinejoin="round" />
                  <path d="M70 148 l-20 22 q-2 2 -4 -1 l2 -21 z" fill="#FFEFF2" />

                  {/* Red/White Medical Badge top-right */}
                  <circle cx="160" cy="40" r="20" fill="#FFF" stroke="#FF5C7F" strokeWidth="3" />
                  <path d="M160 30 v20 M150 40 h20" stroke="#FF5C7F" strokeWidth="5" strokeLinecap="round" />

                  {/* Heartbeat pulse badge */}
                  <rect x="135" y="112" width="30" height="22" rx="6" fill="#FFF" stroke="#FF5C7F" strokeWidth="2.2" />
                  <path d="M140 123 h4 l3 -6 l3 12 l3 -9 l2 3 h5" stroke="#FF5C7F" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" fill="none" />

                  {/* Smiling Happy big eyes */}
                  <circle cx="75" cy="85" r="9" fill="#D32F2F" />
                  <circle cx="72" cy="82" r="3.5" fill="#FFF" />
                  <circle cx="125" cy="85" r="9" fill="#D32F2F" />
                  <circle cx="122" cy="82" r="3.5" fill="#FFF" />

                  {/* Blushing cheeks as seen in image mockup */}
                  <circle cx="62" cy="98" r="8" fill="#FF8A8A" fillOpacity="0.75" />
                  <circle cx="138" cy="98" r="8" fill="#FF8A8A" fillOpacity="0.75" />

                  {/* Cute smiling mouth */}
                  <path d="M92 102 q8 7 16 0" stroke="#8A001A" strokeWidth="3.5" strokeLinecap="round" fill="none" />
                  <path d="M95 102 q5 5 10 0" fill="#FF5C7F" />
                </svg>

                {/* Gradients */}
                <svg width="0" height="0">
                  <defs>
                    <linearGradient id="botGradient" x1="0" y1="1" x2="1" y2="0">
                      <stop offset="0%" stopColor="#FFF0F3" />
                      <stop offset="100%" stopColor="#FFE4E8" />
                    </linearGradient>
                  </defs>
                </svg>
              </div>

              <div className="space-y-2">
                <h3 className="text-xl font-serif font-black text-rose-950 tracking-tight leading-tight">
                  {t('Ask our Medical AI companion', 'សួរនាំជំនួយការ AI របស់ Healith')}
                </h3>
                <p className="text-xs text-[#8E6D7A] font-medium leading-relaxed max-w-[90%] mx-auto">
                  {t('I can analyze your symptoms, describe healthy behaviors, and recommend specialized departments. Start by describing how you feel.', 'ខ្ញុំអាចជួយផ្ដល់ព័ត៌មានពីរោគសញ្ញា បង្ហាញការថែទាំសុខភាព និងណែនាំមន្ទីរពេទ្យ។ សូមសរសេរពីអាការៈរបស់អ្នក។')}
                </p>
              </div>

              {/* Suggestions grid inside welcome message window */}
              <div className="w-full space-y-2 pt-2">
                {[
                  {
                    en: "What foods are good for high blood pressure?",
                    kh: "តើអាហារអ្វីខ្លះដែលល្អសម្រាប់សម្ពាធឈាមខ្ពស់?"
                  },
                  {
                    en: "I have a sore throat and wet cough, what should I do?",
                    kh: "ខ្ញុំឈឺក និងក្អកមានស្លេស្ម តើគួរបង្ការបែបណាខ្លះ?"
                  },
                  {
                    en: "Suggest a healthy diet plan for digestion problems",
                    kh: "ណែនាំរបបអាហារដែលមានសុខភាពល្អសម្រាប់ប្រព័ន្ធរំលាយអាហារ"
                  }
                ].map((q, ix) => (
                  <button
                    key={ix}
                    type="button"
                    onClick={() => setInput(language === 'kh' ? q.kh : q.en)}
                    className="w-full text-left bg-white p-3 rounded-xl border border-pink-100 hover:border-primary text-xs font-semibold text-[#4A3B43] hover:bg-pink-50/20 active:scale-99 transition-all cursor-pointer shadow-2xs leading-relaxed"
                  >
                    {language === 'kh' ? q.kh : q.en}
                  </button>
                ))}
              </div>
            </motion.div>
          ) : (
            messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={cn(
                  "flex w-full gap-3",
                  msg.role === 'user' ? "flex-row-reverse" : "flex-row"
                )}
              >
                {/* Profile Badge icon */}
                <div className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center shrink-0 border border-[#F2E4E9] shadow-2xs select-none",
                  msg.role === 'user'
                    ? "bg-primary text-white"
                    : "bg-[#FFF0F4] text-primary"
                )}>
                  {msg.role === 'user' ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
                </div>

                {/* Main Message box */}
                <div className="flex flex-col max-w-[85%] space-y-1">
                  <div className={cn(
                    "rounded-[20px] px-4 py-3 text-[13px] shadow-2xs border",
                    msg.role === 'user'
                      ? "bg-primary text-white border-primary rounded-tr-none"
                      : "bg-white text-[#4A3B43] border-[#F2E4E9] rounded-tl-none"
                  )}>
                    {msg.role === 'user' ? (
                      <p className="whitespace-pre-wrap leading-relaxed text-pink-50/100 font-medium">{msg.text}</p>
                    ) : (
                      <div className="space-y-1">
                        {renderFormattedContent(msg.text)}
                      </div>
                    )}
                  </div>

                  {/* Metadata and Quick copy tools row */}
                  <div className={cn(
                    "flex items-center gap-3 text-[9px] px-1 font-bold uppercase tracking-wider text-[#A28290] mt-0.5",
                    msg.role === 'user' ? "justify-end" : "justify-start"
                  )}>
                    <span>
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    
                    {msg.role === 'model' && (
                      <button
                        onClick={() => handleCopyMessage(msg.text, msg.id)}
                        className="inline-flex items-center gap-1 text-[#8E6D7A] hover:text-primary cursor-pointer active:scale-95 py-0.5 px-1 rounded hover:bg-pink-50/50"
                        title="Copy raw text response"
                      >
                        {copiedMessageId === msg.id ? (
                          <>
                            <Check className="w-3" />
                            <span className="text-[8px] text-emerald-600">{t('Copied', 'ចម្លងទុកគន្លឹះ')}</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3" />
                            <span className="text-[8px]">{t('Copy', 'ចម្លង')}</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            ))
          )}

          {/* Loader indicator state */}
          {isLoading && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-3">
              <div className="w-8 h-8 rounded-full bg-[#FFF0F4] text-primary flex items-center justify-center border border-[#F2E4E9] shadow-2xs shrink-0">
                <Bot className="w-3.5 h-3.5" />
              </div>
              <div className="bg-white border border-[#F1E5E9] rounded-[20px] rounded-tl-none px-4 py-3.5 shadow-2xs">
                <div className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce [animation-delay:-0.3s]" />
                  <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce [animation-delay:-0.15s]" />
                  <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce" />
                  <span className="text-[10px] text-[#8E6D7A] font-bold uppercase tracking-wide ml-1.5">{t('Healith AI is analyzing...', 'AI កំពុងវិភាគព័ត៌មាន...')}</span>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Suggestion Chips Bar right above Input Box when active */}
      {messages.length > 1 && (
        <div className="px-4 py-1.5 bg-white border-t border-[#F2E4E9]/40 flex gap-2 overflow-x-auto shrink-0 scrollbar-none">
          <button
            onClick={() => setInput(t("Suggest healthy foods", "ណែនាំអាហារដែលផ្តល់សុខភាព"))}
            className="px-3 py-1 flex items-center gap-1.5 bg-[#FFF0F4]/60 border border-pink-100 hover:border-primary text-[10px] font-bold text-[#8E6D7A] hover:text-primary rounded-full transition-all cursor-pointer whitespace-nowrap shrink-0"
          >
            🥦 {t("Diet Suggestion", "អាហារសុខភាព")}
          </button>
          <button
            onClick={() => setInput(t("When are symptoms severe?", "តើរោគសញ្ញាពេលណាទើបធ្ងន់ធ្ងរ?"))}
            className="px-3 py-1 flex items-center gap-1.5 bg-[#FFF0F4]/60 border border-pink-100 hover:border-primary text-[10px] font-bold text-[#8E6D7A] hover:text-primary rounded-full transition-all cursor-pointer whitespace-nowrap shrink-0"
          >
            ⚠️ {t("Severity guide", "កម្រិតរោគសញ្ញា")}
          </button>
          <button
            onClick={() => setInput(t("Tell me a simple symptom precaution", "ប្រាប់វិធីបង្ការរោគសញ្ញាសាមញ្ញ"))}
            className="px-3 py-1 flex items-center gap-1.5 bg-[#FFF0F4]/60 border border-pink-100 hover:border-primary text-[10px] font-bold text-[#8E6D7A] hover:text-primary rounded-full transition-all cursor-pointer whitespace-nowrap shrink-0"
          >
            🏡 {t("Self precaution", "វិធីបង្ការខ្លួនឯង")}
          </button>
        </div>
      )}

      {/* Input Form Box */}
      <div className="p-4 bg-white border-t border-[#F2E4E9] shrink-0">
        <form onSubmit={handleSubmit} className="relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={t("Ask Healith AI about symptoms, diseases...", "សួរ Healith AI ពីរោគសញ្ញា ជំងឺ សុខភាព...")}
            className="w-full bg-[#FAF5F7] border border-[#F2E4E9] rounded-2xl py-3.5 pl-5 pr-14 text-[13px] font-semibold text-[#4A3B43] placeholder-[#CBB0BD] focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary leading-tight transition-all outline-none"
            disabled={isLoading}
          />
          <motion.button
            whileTap={{ scale: 0.95 }}
            type="submit"
            disabled={!input.trim() || isLoading}
            className="absolute right-1.5 top-1.5 w-10 h-10 bg-primary hover:bg-primary-dark text-white rounded-xl flex items-center justify-center shadow-md shadow-primary/10 disabled:opacity-30 disabled:scale-100 transition-all cursor-pointer"
          >
            <Send className="w-4 h-4" />
          </motion.button>
        </form>
        <p className="text-[10px] text-center text-[#B295A2] font-semibold mt-2.5">
          {t("Secure Health Information System", "ប្រព័ន្ធការពារព័ត៌មានសុខភាពឌីជីថល")}
        </p>
      </div>

      {/* Supabase Configuration Info Drawer Modal */}
      <AnimatePresence>
        {showConfig && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowConfig(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />

            {/* Content Drawer */}
            <motion.div
              initial={{ y: "100%", opacity: 0.5 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: "100%", opacity: 0.5 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="relative w-full sm:max-w-md bg-white rounded-t-[32px] sm:rounded-[32px] overflow-hidden shadow-2xl z-10 border border-[#F2E4E9] flex flex-col max-h-[85vh]"
            >
              {/* Header */}
              <div className="p-5 border-b border-[#F2E4E9] flex items-center justify-between bg-gradient-to-r from-[#FFFAFC] to-white">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-pink-100 flex items-center justify-center text-primary">
                    <Database className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-serif font-bold text-primary-dark text-base leading-none">Supabase Sync</h3>
                    <p className="text-[10px] text-[#8E6D7A] font-semibold tracking-wider uppercase mt-1">Database Storage</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowConfig(false)}
                  className="text-xs font-bold text-slate-400 hover:text-slate-600 px-3 py-1.5 rounded-full bg-slate-100 transition-colors cursor-pointer"
                >
                  Close
                </button>
              </div>

              {/* Dynamic Body */}
              <div className="p-6 overflow-y-auto space-y-5 text-sm">
                <div className="flex items-center gap-3 p-4 rounded-2xl bg-slate-50 border border-slate-100">
                  <span className={cn(
                    "w-3 h-3 rounded-full shrink-0",
                    isSupabaseLive ? "bg-emerald-500 animate-pulse" : "bg-amber-500"
                  )} />
                  <div>
                    <p className="font-bold text-[#4A3B43] text-xs">
                      Status: {isSupabaseLive ? 'Connected to Cloud DB' : 'Using Local Storage Mode'}
                    </p>
                    <p className="text-[11px] text-[#8E6D7A] leading-relaxed mt-0.5">
                      {isSupabaseLive 
                        ? 'Your chat history is successfully synchronized to Supabase.' 
                        : 'Credentials are not configured in your settings. Chat and bookmarks are safely saved in local browser storage.'}
                    </p>
                  </div>
                </div>

                {!isSupabaseLive ? (
                  <div className="space-y-4">
                    <div className="space-y-1">
                      <h4 className="font-bold text-[#4A3B43] text-xs uppercase tracking-wider">How to connect your Supabase DB:</h4>
                      <p className="text-xs text-[#8E6D7A] leading-relaxed">
                        To enable persistent cloud backup for Chat & Bookmark records, configure your Supabase variables in the **Secrets/Settings** panel:
                      </p>
                    </div>

                    <div className="bg-[#41393D] text-pink-100 p-4 rounded-2xl font-mono text-xs space-y-2 select-text shadow-sm">
                      <p className="opacity-60 text-[10px] border-b border-pink-100/10 pb-1.5 font-sans">Required Env Variables:</p>
                      <p className="break-all"><span className="text-[#EB92BE]">VITE_SUPABASE_URL</span>=https://your-proj.supabase.co</p>
                      <p className="break-all"><span className="text-[#EB92BE]">VITE_SUPABASE_ANON_KEY</span>=your-anon-key</p>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <p className="text-xs text-[#8E6D7A] leading-relaxed">
                      All systems operational! Chat messages and bookmarked resources are securely stored in your personal Supabase project at:
                    </p>
                    <p className="font-mono text-xs text-primary bg-pink-50/50 p-2 border border-pink-100/40 rounded-xl truncate">
                      {supabaseService.getSupabaseUrl()}
                    </p>
                  </div>
                )}

                {/* SQL setup box */}
                <div className="space-y-2 pt-2">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-[#4A3B43] text-xs uppercase tracking-wider">Required SQL Schema</h4>
                    <button
                      onClick={handleCopySQL}
                      className="text-xs text-primary hover:text-primary-dark font-bold flex items-center gap-1 bg-pink-50 px-2.5 py-1.5 rounded-lg transition-all cursor-pointer"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      {copied ? 'Copied' : 'Copy SQL'}
                    </button>
                  </div>
                  <pre className="w-full bg-slate-900 text-slate-100 p-4 rounded-xl text-[10px] font-mono overflow-x-auto max-h-40 leading-relaxed shadow-inner">
                    {supabaseService.getDatabaseSetupSQL()}
                  </pre>
                  <p className="text-[10px] text-[#8E6D7A] italic text-center">
                    Copy and run this inside your Supabase SQL Editor to prepare both the <code className="font-mono font-bold bg-slate-100 px-1 py-0.5 rounded">chat_messages</code> and <code className="font-mono font-bold bg-slate-100 px-1 py-0.5 rounded">bookmarks</code> tables.
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
