/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Book, Heart, ChevronRight, X, ChevronDown, Sparkles, BookOpen, AlertTriangle } from 'lucide-react';
import { HEALTH_ARTICLES } from '../constants';
import { Category, HealthArticle } from '../types';
import { supabaseService } from '../services/supabaseService';
import { cn } from '../utils';
import { useLanguage } from '../context/LanguageContext';
import { useLocation } from 'react-router-dom';

export default function DictionaryPage() {
  const { t, language } = useLanguage();
  const location = useLocation();

  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<Category | 'All'>('All');
  const [selectedArticle, setSelectedArticle] = useState<HealthArticle | null>(null);
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);
  const [showSavedOnly, setShowSavedOnly] = useState(false);

  // Check for search query parameters passed from Home Page
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const q = params.get('q');
    if (q) {
      setSearch(q);
    }
  }, [location.search]);

  // Load bookmarked article IDs
  useEffect(() => {
    const fetchBookmarks = async () => {
      const records = await supabaseService.getBookmarks();
      const articleIds = records
        .filter(r => r.item_type === 'article')
        .map(r => r.item_id);
      setBookmarkedIds(articleIds);
    };
    fetchBookmarks();
  }, []);

  const handleToggleBookmark = async (articleId: string) => {
    const isNowBookmarked = await supabaseService.toggleBookmark(articleId, 'article');
    if (isNowBookmarked) {
      setBookmarkedIds(prev => [...prev, articleId]);
    } else {
      setBookmarkedIds(prev => prev.filter(id => id !== articleId));
    }
  };

  const filteredArticles = HEALTH_ARTICLES.filter((article) => {
    const nameEn = article.titleEn.toLowerCase();
    const nameKh = article.titleKh.toLowerCase();
    const query = search.toLowerCase();
    
    const matchesSearch = nameEn.includes(query) || nameKh.includes(query);
    const matchesCategory = selectedCategory === 'All' || article.category === selectedCategory;
    const matchesSaved = !showSavedOnly || bookmarkedIds.includes(article.id);
    return matchesSearch && matchesCategory && matchesSaved;
  });

  // Unique Grouping Logic matching Image 2 mockup representation:
  // e.g., Grouping by primary letter of title depending on Khmer or English selection
  const groupArticlesByInitial = () => {
    const groups: { [key: string]: HealthArticle[] } = {};
    
    filteredArticles.forEach(article => {
      const title = language === 'kh' ? article.titleKh : article.titleEn;
      const initial = title.trim().charAt(0).toUpperCase();
      if (!groups[initial]) {
        groups[initial] = [];
      }
      groups[initial].push(article);
    });

    // Sort keys alphabetically
    return Object.keys(groups)
      .sort((a, b) => a.localeCompare(b, language === 'kh' ? 'km' : 'en'))
      .reduce((obj: { [key: string]: HealthArticle[] }, key) => {
        obj[key] = groups[key];
        return obj;
      }, {});
  };

  const groupedData = groupArticlesByInitial();

  return (
    <div className="p-4 space-y-5 bg-gradient-to-b from-white to-[#FFFBFD] min-h-screen pb-12">
      
      {/* Search Header layout matching Mockup 3 */}
      <div className="space-y-4">
        <div>
          <h2 className="text-2xl font-serif font-black text-primary-dark tracking-tight">
            {t('Health Dictionary', 'វចនានុក្រមសុខភាព')}
          </h2>
          <p className="text-[11px] text-[#8E6D7A] font-bold uppercase tracking-widest mt-0.5">
            {t('Cambodian Clinical Reference glossary', 'វចនានុក្រមពន្យល់ជំងឺ និងរោគសញ្ញា')}
          </p>
        </div>

        <div className="relative">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-[#D6BAC6]" />
          <input
            type="text"
            placeholder={t('Search symptoms or disease dictionary...', 'ស្វែងរក រោគសញ្ញា ឬជំងឺផ្សេងៗ...')}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-white border border-[#F2E4E9] rounded-[24px] pl-14 pr-5 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-primary/10 focus:border-primary shadow-sm transition-all"
          />
        </div>

        {/* Categories toggler */}
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
          {['All', ...Object.values(Category)].map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat as any)}
              className={cn(
                "px-5 py-2.5 rounded-full text-[10px] font-extrabold whitespace-nowrap border transition-all uppercase tracking-widest cursor-pointer",
                selectedCategory === cat
                  ? "bg-primary border-primary-dark text-white shadow-md shadow-primary/20"
                  : "bg-white border-[#F2E4E9] text-[#8E6D7A] hover:border-primary/30"
              )}
            >
              {language === 'kh' 
                ? (cat === 'All' ? 'ទាំងអស់' : cat === 'Disease' ? 'ជំងឺ' : cat === 'Prevention' ? 'ការការពារ' : cat === 'Nutrition' ? 'អាហារូបត្ថម្ភ' : cat === 'Mental Health' ? 'ផ្លូវចិត្ត' : 'ជំនួយសង្គ្រោះ') 
                : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Group List displaying letters under header e.g. "ក", "ផ" etc */}
      <div className="space-y-6">
        <div className="flex items-center justify-between px-1 shrink-0">
          <h3 className="text-[10px] font-bold text-[#8E6D7A] uppercase tracking-[0.2em]">
            {filteredArticles.length} {t('Medical Terms Match', 'ពាក្យគន្លឹះដែលបានរកឃើញ')}
          </h3>
          <button
            onClick={() => setShowSavedOnly(!showSavedOnly)}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-bold transition-all border cursor-pointer",
              showSavedOnly 
                ? "bg-pink-150 border-pink-200 text-pink-700 font-semibold" 
                : "border-[#F2E4E9] text-[#8E6D7A]"
            )}
            title="Toggle Bookmarked Items Only"
          >
            <Heart className={cn("w-3.5 h-3.5", showSavedOnly ? "fill-pink-700 text-pink-700" : "")} />
            {t('Bookmarks', 'រក្សាទុក')}
          </button>
        </div>

        <div className="space-y-6">
          {Object.keys(groupedData).map((initialLetter) => (
            <div key={initialLetter} className="space-y-3">
              {/* Bold Large initial letter header as shown in screenshot mockup */}
              <h3 className="text-2xl font-serif font-black text-primary border-b border-pink-100/60 pb-1 mt-4">
                {initialLetter}
              </h3>

              <div className="grid gap-4">
                {groupedData[initialLetter].map((article) => {
                  const isSaved = bookmarkedIds.includes(article.id);
                  return (
                    <motion.div
                      key={article.id}
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-white p-5 rounded-[24px] border border-[#F2E4E9] shadow-sm space-y-3 relative overflow-hidden group hover:shadow-md transition-all"
                    >
                      {/* Flex Header of the block */}
                      <div className="flex justify-between items-start gap-4">
                        <div onClick={() => setSelectedArticle(article)} className="cursor-pointer flex-1 min-w-0">
                          <h4 className="font-serif font-bold text-primary-dark text-lg leading-tight transition-all group-hover:text-primary">
                            {language === 'kh' ? article.titleKh : article.titleEn}
                          </h4>
                          <p className="text-xs text-[#8E6D7A] font-medium leading-none mt-1">
                            {language === 'kh' ? article.titleEn : article.titleKh}
                          </p>
                        </div>
                        
                        <div className="flex items-center gap-1 shrink-0">
                          {/* Bookmark heart icon */}
                          <button
                            onClick={() => handleToggleBookmark(article.id)}
                            className="p-2 hover:bg-[#FFF0F5] bg-pink-50/20 text-[#8E6D7A] rounded-full transition-all cursor-pointer"
                            title="Bookmark Term"
                          >
                            <Heart className={cn("w-4 h-4 transition-all active:scale-90", isSaved ? "fill-primary text-primary" : "text-slate-300")} />
                          </button>
                          
                          {/* Full analysis chevron trigger */}
                          <button
                            onClick={() => setSelectedArticle(article)}
                            className="p-2 hover:bg-slate-50 text-slate-400 hover:text-primary rounded-full transition-all cursor-pointer"
                            title="View Details"
                          >
                            <ChevronRight className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* Diagnostic breakdown matching Mockup 3 structure exactly */}
                      <div className="text-xs space-y-2.5 pt-2 border-t border-slate-50">
                        {/* 1. Causes (មូលហេតុ) */}
                        {article.causes && article.causes.length > 0 && (
                          <div className="space-y-1">
                            <span className="text-[11px] font-bold text-slate-800 bg-[#E6F3FF] text-[#1D5C93] px-2 py-0.5 rounded-md">
                              {t('Causes', 'មូលហេតុ')}
                            </span>
                            <ul className="list-disc pl-5 space-y-0.5 text-[#4A3B43] font-medium mt-1">
                              {article.causes.map((item, ix) => (
                                <li key={ix} className="leading-relaxed">{item}</li>
                              ))}
                            </ul>
                          </div>
                        )}

                        {/* 2. Symptoms (រោគសញ្ញា) */}
                        {article.symptoms && article.symptoms.length > 0 && (
                          <div className="space-y-1">
                            <span className="text-[11px] font-bold text-[#5C1D24] bg-[#FFF0F2] text-rose-700 px-2 py-0.5 rounded-md">
                              {t('Symptoms', 'រោគសញ្ញា')}
                            </span>
                            <ul className="list-disc pl-5 space-y-0.5 text-[#4A3B43] font-medium mt-1">
                              {article.symptoms.map((item, ix) => (
                                <li key={ix} className="leading-relaxed">{item}</li>
                              ))}
                            </ul>
                          </div>
                        )}

                        {/* 3. Preventions (ការការពារ/ព្យាបាល) */}
                        {article.prevention && article.prevention.length > 0 && (
                          <div className="space-y-1">
                            <span className="text-[11px] font-bold text-[#1D5C24] bg-[#F0FFF2] text-emerald-700 px-2 py-0.5 rounded-md">
                              {t('Prevention & Treatment', 'ការការពារ និងព្យាបាល')}
                            </span>
                            <ul className="list-disc pl-5 space-y-0.5 text-[#4A3B43] font-medium mt-1">
                              {article.prevention.map((item, ix) => (
                                <li key={ix} className="leading-relaxed">{item}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          ))}

          {Object.keys(groupedData).length === 0 && (
            <div className="text-center py-16 space-y-4 bg-white/50 rounded-[32px] border border-dashed border-[#F2E4E9]">
              <div className="bg-pink-50 rounded-full w-14 h-14 flex items-center justify-center mx-auto">
                <Book className="w-6 h-6 text-primary" />
              </div>
              <p className="text-[#8E6D7A] text-sm font-semibold italic">
                {t('No matches found in our Dictionary.', 'រកមិនឃើញពាក្យគន្លឹះក្នុងវចនានុក្រមរបស់យើងទេ។')}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Detailed Modal view trigger for advanced information */}
      <AnimatePresence>
        {selectedArticle && (
          <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center p-4 bg-primary-dark/40 backdrop-blur-md">
            <motion.div
              initial={{ y: "100%", opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: "100%", opacity: 0 }}
              className="bg-white w-full max-w-lg rounded-t-[40px] sm:rounded-[40px] overflow-hidden max-h-[90vh] flex flex-col shadow-2xl"
            >
              <div className="relative h-48 overflow-hidden shrink-0">
                <img
                  src={selectedArticle.imageUrl}
                  alt={selectedArticle.titleEn}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <button
                  onClick={() => setSelectedArticle(null)}
                  className="absolute top-5 right-5 p-2.5 bg-black/30 backdrop-blur-md rounded-full text-white hover:bg-black/55 transition-colors cursor-pointer z-10"
                >
                  <X className="w-5 h-5" />
                </button>
                <div className="absolute top-5 left-5 flex gap-2 z-10">
                  <div className="px-4 py-1.5 bg-white/90 backdrop-blur-sm rounded-full text-[10px] font-bold text-primary uppercase tracking-widest border border-primary/20 shadow-sm leading-none">
                    {selectedArticle.category}
                  </div>
                  <button
                    onClick={() => handleToggleBookmark(selectedArticle.id)}
                    className="p-2 bg-white/90 backdrop-blur-sm rounded-full text-primary hover:bg-white transition-colors shadow-md cursor-pointer flex items-center justify-center"
                    title="Toggle Saved Bookmark"
                  >
                    <Heart className={cn("w-4 h-4 transition-all active:scale-90", bookmarkedIds.includes(selectedArticle.id) ? "fill-primary text-primary" : "text-slate-400")} />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-8 space-y-6">
                <div className="space-y-1">
                  <h2 className="text-2xl font-serif font-black text-primary-dark tracking-tight leading-tight">
                    {language === 'kh' ? selectedArticle.titleKh : selectedArticle.titleEn}
                  </h2>
                  <p className="text-sm font-semibold text-primary leading-none">
                    {language === 'kh' ? selectedArticle.titleEn : selectedArticle.titleKh}
                  </p>
                </div>

                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <h5 className="text-[10px] font-bold text-[#D6BAC6] uppercase tracking-widest">{t('Clinical Summary Overview', 'ការវាយតម្លៃគ្លីនិក')}</h5>
                    <p className="text-xs text-[#4A3B43] leading-relaxed">
                      {language === 'kh' ? selectedArticle.contentKh : selectedArticle.contentEn}
                    </p>
                  </div>
                  
                  {selectedArticle.treatments && (
                    <div className="space-y-1.5">
                      <h5 className="text-[10px] font-bold text-[#D6BAC6] uppercase tracking-widest">{t('Standard Diagnostic Actions', 'សកម្មភាពព្យាបាលជាមូលដ្ឋាន')}</h5>
                      <ul className="list-disc pl-5 space-y-0.5 text-xs text-[#4A3B43]">
                        {selectedArticle.treatments.map((item, ix) => (
                          <li key={ix} className="leading-relaxed">{item}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Optional When to see a doctor warning */}
                  {(selectedArticle.whenToSeeDoctorEn || selectedArticle.whenToSeeDoctorKh) && (
                    <div className="space-y-1.5 p-4 rounded-2xl bg-rose-50 border border-rose-100">
                      <h5 className="text-[10px] font-bold text-rose-800 uppercase tracking-widest flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                        <span>{t('When to Consult a Doctor', 'ករណីត្រូវជួបគ្រូពេទ្យជាបន្ទាន់')}</span>
                      </h5>
                      <p className="text-xs text-rose-950 leading-relaxed font-semibold">
                        {language === 'kh' ? selectedArticle.whenToSeeDoctorKh : selectedArticle.whenToSeeDoctorEn}
                      </p>
                    </div>
                  )}

                  {/* Optional Related Topics / Conditions */}
                  {(selectedArticle.relatedEn || selectedArticle.relatedKh) && (
                    <div className="space-y-1.5">
                      <h5 className="text-[10px] font-bold text-[#D6BAC6] uppercase tracking-widest">{t('Related Health Conditions', 'ប្រភេទជំងឺពាក់ព័ន្ធផ្សេងទៀត')}</h5>
                      <div className="flex flex-wrap gap-2 pt-1">
                        {(language === 'kh' ? selectedArticle.relatedKh : selectedArticle.relatedEn)?.map((rel, idx) => (
                          <span key={idx} className="bg-pink-50/55 border border-pink-100 text-primary-dark font-semibold text-[10.5px] px-3 py-1 rounded-full">
                            {rel}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
