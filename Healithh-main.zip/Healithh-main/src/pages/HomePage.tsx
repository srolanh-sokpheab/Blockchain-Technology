/**
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  Mic, 
  Plus, 
  Activity, 
  Book, 
  ChevronLeft, 
  ChevronRight, 
  Heart, 
  Smile, 
  Moon, 
  TrendingUp, 
  Droplet, 
  Flame, 
  Calendar as CalendarIcon, 
  User, 
  Volume2, 
  ChevronDown, 
  Share2,  
  PlusCircle, 
  Trash2,
  Lock,
  CheckCircle2,
  BookOpen,
  Footprints,
  FileText
} from 'lucide-react';
import { Link, useNavigate, useOutletContext } from 'react-router-dom';
import { cn } from '../utils';
import { useLanguage } from '../context/LanguageContext';
import { supabaseService } from '../services/supabaseService';
import AuthModal from '../components/AuthModal';

export default function HomePage() {
  const { t, language } = useLanguage();
  const navigate = useNavigate();
  const outletContext = useOutletContext<{ onAuthChange?: () => void }>() || {};

  const [searchQuery, setSearchQuery] = useState('');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<any>(null);

  // Stats Drawer State
  const [showStatsDrawer, setShowStatsDrawer] = useState(false);
  // Activities Drawer State
  const [showActivitiesDrawer, setShowActivitiesDrawer] = useState(false);
  // Feeds Drawer State
  const [showFeedsDrawer, setShowFeedsDrawer] = useState(false);
  // Selected feed article
  const [selectedFeedIndex, setSelectedFeedIndex] = useState<number | null>(null);

  // Daily trackers (persisted locally)
  const [waterCups, setWaterCups] = useState(4);
  const [sleepHours, setSleepHours] = useState(7);
  const [stepCounts, setStepCounts] = useState(6400);
  const [caloriesBurned, setCaloriesBurned] = useState(380);

  // Calendar State
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [viewDate, setViewDate] = useState<Date>(new Date());
  const [showDayLogModal, setShowDayLogModal] = useState(false);
  const [dayLogText, setDayLogText] = useState('');
  const [dayLogMood, setDayLogMood] = useState('Calm');
  const [savedLogs, setSavedLogs] = useState<{ [key: string]: { text: string; mood: string } }>({});

  // Sync user info on mount & update
  useEffect(() => {
    setCurrentUser(supabaseService.getCurrentUser());
  }, []);

  // Poll current user occasionally
  useEffect(() => {
    const checkUser = setInterval(() => {
      setCurrentUser(supabaseService.getCurrentUser());
    }, 1000);
    return () => clearInterval(checkUser);
  }, []);

  // Fetch saved logs from local storage on mount
  useEffect(() => {
    const local = localStorage.getItem('healith_calendar_logs');
    if (local) {
      setSavedLogs(JSON.parse(local));
    }
  }, []);

  const handleAuthChangeCallback = () => {
    setCurrentUser(supabaseService.getCurrentUser());
    if (outletContext.onAuthChange) {
      outletContext.onAuthChange();
    }
  };

  // Search redirection handler
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    // Route to Health Dictionary page with query param
    navigate(`/dictionary?q=${encodeURIComponent(searchQuery)}`);
  };

  // Quick action voice search
  const handleVoiceSearchMock = () => {
    const suggestions = [
      t('Dengue', 'គ្រុនឈាម'),
      t('Cold', 'ផ្តាសាយ'),
      t('Heat stroke', 'ការគាំងកម្តៅ'),
      t('Gastritis', 'រលាកក្រពះ')
    ];
    const random = suggestions[Math.floor(Math.random() * suggestions.length)];
    setSearchQuery(random);
  };

  // Save selected calendar day logs
  const handleSaveDayLog = () => {
    const key = selectedDate.toDateString();
    const updated = {
      ...savedLogs,
      [key]: { text: dayLogText, mood: dayLogMood }
    };
    setSavedLogs(updated);
    localStorage.setItem('healith_calendar_logs', JSON.stringify(updated));
    setShowDayLogModal(false);
  };

  const handleClearDayLog = () => {
    const key = selectedDate.toDateString();
    const updated = { ...savedLogs };
    delete updated[key];
    setSavedLogs(updated);
    localStorage.setItem('healith_calendar_logs', JSON.stringify(updated));
    setDayLogText('');
    setShowDayLogModal(false);
  };

  // Open daily calendar day log
  const handleDayClick = (date: Date) => {
    setSelectedDate(date);
    const key = date.toDateString();
    const existing = savedLogs[key];
    if (existing) {
      setDayLogText(existing.text);
      setDayLogMood(existing.mood);
    } else {
      setDayLogText('');
      setDayLogMood('Calm');
    }
    setShowDayLogModal(true);
  };

  // Generate Calendar Days
  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (year: number, month: number) => {
    return new Date(year, month, 1).getDay();
  };

  const generateDaysGrid = () => {
    const year = viewDate.getFullYear();
    const month = viewDate.getMonth();
    
    const totalDays = getDaysInMonth(year, month);
    const firstDay = getFirstDayOfMonth(year, month);
    
    const days = [];
    
    // Previous Month padding
    const prevMonthDays = getDaysInMonth(year, month - 1);
    for (let i = firstDay - 1; i >= 0; i--) {
      days.push({
        dayNum: prevMonthDays - i,
        isCurrentMonth: false,
        date: new Date(year, month - 1, prevMonthDays - i)
      });
    }
    
    // Current Month days
    for (let i = 1; i <= totalDays; i++) {
      days.push({
        dayNum: i,
        isCurrentMonth: true,
        date: new Date(year, month, i)
      });
    }

    // Next Month padding to standard 42 cell square
    const remaining = 42 - days.length;
    for (let i = 1; i <= remaining; i++) {
      days.push({
        dayNum: i,
        isCurrentMonth: false,
        date: new Date(year, month + 1, i)
      });
    }

    return days;
  };

  const handlePrevMonth = () => {
    setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() + 1, 1));
  };

  const englishMonths = [
    'January', 'February', 'March', 'April', 'May', 'June', 
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const khmerMonths = [
    'មករា', 'កុម្ភៈ', 'មីនា', 'មេសា', 'ឧសភា', 'មិថុនា',
    'កក្កដា', 'សីហា', 'កញ្ញា', 'តុលា', 'វិច្ឆិកា', 'ធ្នូ'
  ];

  const khmerWeekdays = ['អា', 'ច', 'អ', 'ព', 'ព្រ', 'សុ', 'ស'];
  const englishWeekdays = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

  // Feed items tailored specifically for young cambodians
  const localFeedArticles = [
    {
      titleEn: 'Hydration and Extreme Heat Protection in Phnom Penh',
      titleKh: 'ការការពារខ្លួនពីកម្តៅក្តៅខ្លាំងនៅភ្នំពេញ និងការញ៉ាំទឹក',
      descEn: 'As regional temperatures peak at 39°C, health planners recommend young professionals drink a minimum of 3 liters of water per day.',
      descKh: 'នៅពេលដែលសីតុណ្ហភាពឡើងដល់ ៣៩°C អ្នកជំនាញណែនាំឲ្យយុវជនខ្មែរញ៉ាំទឹកឲ្យបានយ៉ាងតិច ៣លីត្រ ក្នុងមួយថ្ងៃ។',
      author: 'Dr. Chantra K.',
      mins: '3 min read'
    },
    {
      titleEn: 'Combating the Mosquito Surge: Proactive Vector Defense',
      titleKh: 'ការប្រយុទ្ធប្រឆាំងការកើនឡើងមូសខ្លា៖ ការពារជាមុន',
      descEn: 'Essential guide on clearing flowerpots and puddles after early tropical rain showers across local housing quarters to eliminate mosquito nurseries.',
      descKh: 'ការណែនាំសំខាន់ៗអំពីការសម្អាតប្រភពទឹកដក់ រចនាសម្ព័ន្ធផ្កា និងថូផ្កា ក្រោយជំនន់ទឹកភ្លៀងទំបន់ត្រូពិក ដើម្បីលុបបំបាត់ជម្រកមូសខ្លា។',
      author: 'Ministry of Health Advisor',
      textEn: 'Ensure to use larvicide inside decorative water barrels.',
      textKh: 'ត្រូវប្រាកដថាប្រើប្រាស់ថ្នាំអាប៊េតដាក់ក្នុងអាងទឹកដើម្បីសម្លាប់ពងមូសខ្លា។',
      mins: '4 min read'
    },
    {
      titleEn: 'Circadian Sleep Rhythm for University & Tech Students',
      titleKh: 'វដ្តគេងសរីរាង្គសម្រាប់និស្សិតសាកលវិទ្យាល័យ និងយុវជនរវល់',
      descEn: 'How screen light limits natural melatonin secretion. Practical habits to avoid chronic stress during midterm preparation stages.',
      descKh: 'ស្វែងយល់ពីរបៀបដែលពន្លឺអេក្រង់ទូរស័ព្ទទប់ស្កាត់អរម៉ូនមេឡាតូនីន និងទម្លាប់គេងឲ្យបានល្អអំឡុងពេលប្រឡង។',
      author: 'Sreypich Meas (Clinical Wellness Leader)',
      mins: '5 min read'
    }
  ];

  return (
    <div className="p-4 space-y-5 select-none bg-gradient-to-b from-[#FFFDFE] to-[#FFF9FB] min-h-screen pb-12">
      
      {/* Search Input Layout with Mic Trigger */}
      <form onSubmit={handleSearchSubmit} className="relative w-full">
        <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8E6D7A]/50" />
        <input
          type="text"
          placeholder={t('Search symptoms, medical terms...', 'ស្វែងរក រោគសញ្ញា ឬជំងឺផ្សេងៗ...')}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full bg-slate-50 border border-[#F2E4E9] rounded-[24px] pl-13 pr-12 py-3.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/10 focus:border-primary shadow-sm transition-all"
        />
        <button
          type="button"
          onClick={handleVoiceSearchMock}
          className="absolute right-3.5 top-1/2 -translate-y-1/2 p-2 rounded-full hover:bg-pink-50 text-primary active:scale-90 transition-all cursor-pointer"
          title={t('Quick Sample search', 'ការស្វែងរកគំរូ')}
        >
          <Mic className="w-4 h-4" />
        </button>
      </form>

      {/* Hero Container: Welcome Message + Beautiful SVG Doctor Illustration */}
      <div 
        onClick={() => setIsAuthModalOpen(true)}
        className="relative overflow-hidden rounded-[30px] bg-gradient-to-r from-[#FFF0F5] to-[#FFE4E1] p-6 text-[#4A3B43] shadow-sm border border-pink-100/60 cursor-pointer hover:shadow-md transition-all group shrink-0"
      >
        <div className="relative z-10 max-w-[60%] space-y-2">
          <h2 className="text-2xl font-serif font-black tracking-tight text-primary-dark">
            {currentUser 
              ? `${t('Welcome back,', 'ស្វាគមន៍មកវិញ')} ${currentUser.name.split(' ')[0]}!` 
              : t('Welcome back...', 'សួស្តី ស្វាគមន៍មកកាន់...')}
          </h2>
          <p className="text-xs text-[#8E6D7A] leading-relaxed font-semibold">
            {t("I hope you're well. How can I help you today?", "ខ្ញុំសង្ឃឹមថាអ្នកសុខសប្បាយជាទេ។ តើខ្ញុំអាចជួយអ្វីខ្លះនៅថ្ងៃនេះ?")}
          </p>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/75 backdrop-blur-sm rounded-full text-[10px] font-bold text-primary border border-pink-200/50 mt-1 uppercase tracking-wider group-hover:bg-primary group-hover:text-white transition-all shadow-sm">
            <Plus className="w-3 h-3" />
            {currentUser ? t('My Account Info', 'ព័ត៌មានគណនី') : t('Sign In / Register', 'ចុះឈ្មោះ / ចូល')}
          </div>
        </div>

        {/* CSS/SVG Doctor Avatar Frame - Perfectly rendered and highly crisp */}
        <div className="absolute top-0 right-1 w-36 h-full flex items-center justify-end pointer-events-none">
          <svg className="w-28 h-28 transform group-hover:scale-105 group-hover:rotate-1 transition-all duration-300" viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            {/* Background Blush cloud */}
            <circle cx="100" cy="110" r="70" fill="#FFB7C5" fillOpacity="0.32" />
            <circle cx="120" cy="100" r="50" fill="#F4C2C2" fillOpacity="0.25" />
            
            {/* Stethoscope */}
            <path d="M70 110C70 140 130 140 130 110" stroke="#8E6D7A" strokeWidth="4" strokeLinecap="round" />
            
            {/* Body Coat */}
            <path d="M50 170c0-20 15-35 35-35h30c20 0 35 15 35 35v15H50v-15z" fill="#FFF" />
            <path d="M85 135l15 30 15-30" fill="#E6C8D4" />
            
            {/* Doctor Shirt Tie */}
            <path d="M100 135v12" stroke="#D32F2F" strokeWidth="3" />

            {/* Face */}
            <circle cx="100" cy="100" r="32" fill="#FDD7CB" />
            
            {/* Cute Hair and glasses */}
            <path d="M68 95c0-20 15-32 32-32s32 12 32 32c0 2-4 0-4-6 0-14-11-20-28-20S72 81 72 95z" fill="#4E342E" />
            <circle cx="88" cy="100" r="8" stroke="#D32F2F" strokeWidth="2.5" />
            <circle cx="112" cy="100" r="8" stroke="#D32F2F" strokeWidth="2.5" />
            <line x1="96" y1="100" x2="104" y2="100" stroke="#D32F2F" strokeWidth="2" />

            {/* Cheeks blush */}
            <circle cx="78" cy="107" r="4" fill="#FF8A8A" fillOpacity="0.7" />
            <circle cx="122" cy="107" r="4" fill="#FF8A8A" fillOpacity="0.7" />

            {/* Smile */}
            <path d="M96 112q4 3 8 0" stroke="#4E342E" strokeWidth="2" strokeLinecap="round" />
            
            {/* Cute Medical Tab */}
            <rect x="125" y="115" width="28" height="38" rx="4" fill="#EFF1F3" stroke="#8E6D7A" strokeWidth="2" />
            {/* Red Heart on table */}
            <path d="M139 128a2 2 0 00-2.8-2.8l-.2.1-.2-.1a2 2 0 00-2.8 2.8l3 3.3 3-3.3z" fill="#E91E63" />
          </svg>
        </div>
      </div>

      {/* Dynamic Bento Block Section (Health Stats + Miniature Buttons) */}
      <section className="grid grid-cols-2 gap-4">
        
        {/* Health Stats Widget Card */}
        <div 
          onClick={() => setShowStatsDrawer(true)}
          className="p-5 rounded-[28px] bg-gradient-to-b from-white to-[#FAF6F8] border border-[#F2E4E9] shadow-sm hover:shadow-md transition-all flex flex-col justify-between gap-5 cursor-pointer"
        >
          {/* Statistical layout visuals - mirroring mockup's 3 bar parameters */}
          <div className="flex items-end justify-center gap-2.5 h-16 pt-2 select-none">
            {/* Bar 1 */}
            <div className="flex flex-col items-center gap-1.5 h-full justify-end">
              <span className="w-2.5 h-2.5 rounded-full bg-pink-300" />
              <motion.div 
                initial={{ height: 0 }}
                animate={{ height: "40%" }}
                className="w-3 rounded-t-lg bg-pink-100"
              />
            </div>
            {/* Bar 2 (Active highlighted) */}
            <div className="flex flex-col items-center gap-1.5 h-full justify-end">
              <span className="w-2.5 h-2.5 rounded-full bg-primary" />
              <motion.div 
                initial={{ height: 0 }}
                animate={{ height: "85%" }}
                className="w-3 rounded-t-lg bg-pink-200"
              />
            </div>
            {/* Bar 3 */}
            <div className="flex flex-col items-center gap-1.5 h-full justify-end">
              <span className="w-2.5 h-2.5 rounded-full bg-pink-400" />
              <motion.div 
                initial={{ height: 0 }}
                animate={{ height: "60%" }}
                className="w-3 rounded-t-lg bg-pink-100"
              />
            </div>
          </div>

          <div>
            <h4 className="font-serif font-black text-rose-950 text-base leading-tight">{t('Health Stats', 'សូចនាករសុខភាព')}</h4>
            <p className="text-[10px] text-[#8E6D7A] font-bold uppercase tracking-wider mt-1 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              {t('Check diagnostics', 'ពិនិត្យទិន្នន័យប្រចាំថ្ងៃ')}
            </p>
          </div>
        </div>

        {/* Double row small cards */}
        <div className="flex flex-col gap-3">
          
          {/* 1. Health Dictionary Link Wrapper */}
          <Link to="/dictionary">
            <motion.div 
              whileTap={{ scale: 0.98 }}
              className="px-4 py-3 bg-white hover:bg-pink-50/50 rounded-2xl border border-pink-100 flex items-center justify-between gap-3 shadow-sm hover:border-primary/20 transition-all cursor-pointer group"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-lg bg-pink-100 text-primary flex items-center justify-center shrink-0">
                  <BookOpen className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <h4 className="font-serif font-extrabold text-sm text-primary-dark truncate">{t('Dictionary', 'វចនានុក្រម')}</h4>
                  <p className="text-[9px] text-[#8E6D7A] truncate font-medium">{t('Symptoms glossary', 'ពាក្យគន្លឹះជំងឺរោគសញ្ញា')}</p>
                </div>
              </div>
              <div className="w-5 h-5 rounded-full bg-pink-50 text-primary flex items-center justify-center text-xs font-bold font-mono group-hover:bg-primary group-hover:text-white transition-all shrink-0">
                +
              </div>
            </motion.div>
          </Link>

          {/* 2. Activities Link Card Direct Navigation */}
          <Link to="/activities">
            <div 
              className="px-4 py-3 bg-white hover:bg-pink-50/50 rounded-2xl border border-pink-100 flex items-center justify-between gap-3 shadow-sm hover:border-primary/20 transition-all cursor-pointer group animate-fade-in"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-lg bg-pink-100 text-primary flex items-center justify-center shrink-0">
                  <Footprints className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <h4 className="font-serif font-extrabold text-sm text-primary-dark truncate">{t('Activities', 'សកម្មភាព')}</h4>
                  <p className="text-[9px] text-[#8E6D7A] truncate font-medium">{t('Track daily progress', 'កត់ត្រាលំហាត់ប្រាណប្រចាំថ្ងៃ')}</p>
                </div>
              </div>
              <div className="w-5 h-5 rounded-full bg-pink-50 text-primary flex items-center justify-center text-xs font-bold font-mono group-hover:bg-primary group-hover:text-white transition-all shrink-0">
                +
              </div>
            </div>
          </Link>

          {/* 3. Local Health Feeds */}
          <div 
            onClick={() => setShowFeedsDrawer(true)}
            className="px-4 py-3 bg-white hover:bg-pink-50/50 rounded-2xl border border-pink-100 flex items-center justify-between gap-3 shadow-sm hover:border-primary/20 transition-all cursor-pointer group"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-lg bg-pink-100 text-primary flex items-center justify-center shrink-0">
                <FileText className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <h4 className="font-serif font-extrabold text-sm text-primary-dark truncate">{t('Feeds', 'ព័ត៌មាន')}</h4>
                <p className="text-[9px] text-[#8E6D7A] truncate font-medium">{t('Cambodian insights', 'អត្ថបទខ្លីៗពីបញ្ហាសុខភាព')}</p>
              </div>
            </div>
            <div className="w-5 h-5 rounded-full bg-pink-50 text-primary flex items-center justify-center text-xs font-bold font-mono group-hover:bg-primary group-hover:text-white transition-all shrink-0">
              +
            </div>
          </div>

        </div>
      </section>

      {/* Interactive Beautiful Calendar Card Widget */}
      <section className="bg-white p-5 rounded-[28px] border border-[#F2E4E9] shadow-sm space-y-4 shrink-0">
        
        {/* Calendar Navigation header */}
        <div className="flex items-center justify-between">
          <button 
            onClick={handlePrevMonth}
            className="p-2 border border-slate-100 hover:bg-slate-50 text-slate-500 rounded-full cursor-pointer transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          {/* Interactive dropdown label layout resembling mockup */}
          <div className="flex items-center gap-1 text-sm font-bold text-primary-dark">
            <span className="bg-pink-50/50 px-3 py-1.5 rounded-xl border border-pink-100/50 flex items-center gap-1.5">
              {language === 'kh' ? khmerMonths[viewDate.getMonth()] : englishMonths[viewDate.getMonth()]}
              <ChevronDown className="w-3.5 h-3.5 text-[#8E6D7A]" />
            </span>
            <span className="bg-pink-50/50 px-3 py-1.5 rounded-xl border border-pink-100/50 flex items-center gap-1.5">
              {viewDate.getFullYear()}
              <ChevronDown className="w-3.5 h-3.5 text-[#8E6D7A]" />
            </span>
          </div>

          <button 
            onClick={handleNextMonth}
            className="p-2 border border-slate-100 hover:bg-slate-50 text-slate-500 rounded-full cursor-pointer transition-colors"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Days of Week header */}
        <div className="grid grid-cols-7 text-center gap-1">
          {(language === 'kh' ? khmerWeekdays : englishWeekdays).map((day, ix) => (
            <span key={day} className={cn(
              "text-[10px] font-bold uppercase tracking-wider py-1.5",
              ix === 0 ? "text-rose-500" : "text-[#8E6D7A]"
            )}>
              {day}
            </span>
          ))}
        </div>

        {/* Days grid layout highlights selected, today, in/out month and logged entries */}
        <div className="grid grid-cols-7 gap-1.5 text-center">
          {generateDaysGrid().map((item, index) => {
            const isToday = item.date.toDateString() === new Date().toDateString();
            const isTarget = item.date.toDateString() === selectedDate.toDateString();
            const logExist = savedLogs[item.date.toDateString()];
            
            // Mock highlights representing days 9 and 13 as shown in home screenshot
            const forcesMockHighlight = item.isCurrentMonth && (item.dayNum === 9 || item.dayNum === 13);
            
            return (
              <button
                key={index}
                onClick={() => handleDayClick(item.date)}
                className={cn(
                  "aspect-square rounded-2xl flex flex-col items-center justify-center text-[11px] font-extrabold relative transition-all duration-300 cursor-pointer",
                  !item.isCurrentMonth && "text-slate-300 pointer-events-none",
                  item.isCurrentMonth && !isToday && !isTarget && "text-slate-700 hover:bg-pink-50/60",
                  // Highlights in black rounded rects matching layout image 1
                  forcesMockHighlight && "bg-[#2A292C] text-white shadow-sm scale-102",
                  isToday && !forcesMockHighlight && "bg-primary text-white scale-102 shadow-glow",
                  isTarget && !forcesMockHighlight && !isToday && "border-2 border-primary bg-pink-50/30"
                )}
              >
                <span>{item.dayNum}</span>
                
                {/* Micro indicators showing logged symptoms/moods */}
                {logExist && (
                  <span className={cn(
                    "absolute bottom-1 w-1.5 h-1.5 rounded-full",
                    logExist.mood === 'Sore' || logExist.mood === 'Tired' ? "bg-rose-500 animate-pulse" : "bg-emerald-500"
                  )} />
                )}
              </button>
            );
          })}
        </div>

        {/* Health status summary indicator */}
        <p className="text-[10px] text-[#8E6D7A] text-center italic mt-2">
          {t('💡 Pro Tip: Tap any day count to record symptom notes & moods.', '💡 គំនិតល្អ៖ លោកអ្នកអាចចុចលើកាលបរិច្ឆេទដើម្បីកត់ត្រាអាការសុខភាព ឬអារម្មណ៍របស់អ្នក។')}
        </p>

      </section>

      {/* Core Educational/Disclaimers block in Cambodian style */}
      <section className="p-4 bg-white rounded-3xl border border-[#F2E4E9] shadow-inner-sm text-[11px] leading-relaxed italic text-center text-[#8E6D7A]">
        {t(
          'Healith is built to support healthcare reference access. Do not replace clinical doctors prescriptions.',
          'Healith ត្រូវ​បាន​បង្កើត​ឡើង​សម្រាប់​ជា​ជំនួយការ​ស្វែងយល់​ជា​មូលដ្ឋាន​ប៉ុណ្ណោះ។ សូម​កុំ​ជំនួស​ការពិគ្រោះ ឬ​វេជ្ជបញ្ជា​របស់​គ្រូពេទ្យ​ផ្ទាល់។'
        )}
      </section>

      {/* --- ALL INTERACTIVE MODALS AND DRAWERS --- */}

      {/* 1. CALENDAR DAY LOGGING DIALOG MODAL */}
      <AnimatePresence>
        {showDayLogModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowDayLogModal(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-xs"
            />
            {/* Modal Body */}
            <motion.div
              initial={{ y: "100%", opacity: 0.5 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: "100%", opacity: 0.5 }}
              className="relative w-full sm:max-w-md bg-white rounded-t-[32px] sm:rounded-[36px] overflow-hidden shadow-2xl z-10 border border-[#F2E4E9]"
            >
              <div className="p-6 border-b border-[#F2E4E9] flex items-center justify-between bg-pink-50/30">
                <div className="flex items-center gap-2">
                  <CalendarIcon className="w-5 h-5 text-primary" />
                  <div>
                    <h3 className="font-serif font-bold text-primary-dark text-base">
                      {selectedDate.toLocaleDateString(language === 'kh' ? 'km-KH' : 'en-US', { day: 'numeric', month: 'long', year: 'numeric' })}
                    </h3>
                    <p className="text-[10px] text-[#8E6D7A] font-semibold tracking-wider uppercase mt-0.5">{t('Daily Parameter Log', 'កំណត់ហេតុជាប្រចាំថ្ងៃ')}</p>
                  </div>
                </div>
                <button onClick={() => setShowDayLogModal(false)} className="px-3 py-1.5 rounded-full text-xs font-bold text-slate-400 hover:bg-slate-100 cursor-pointer">
                  {t('Close', 'បិទ')}
                </button>
              </div>

              <div className="p-6 space-y-4 text-sm">
                
                {/* Mood picker */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-[#8E6D7A] uppercase tracking-wider">{t('My Mood State', 'អារម្មណ៍របស់ខ្ញុំ')}</label>
                  <div className="grid grid-cols-4 gap-2">
                    {[
                      { l: 'Calm', icon: <Smile className="w-4 h-4 text-emerald-500" /> },
                      { l: 'Happy', icon: <PlusCircle className="w-4 h-4 text-pink-500" /> },
                      { l: 'Tired', icon: <Moon className="w-4 h-4 text-amber-500" /> },
                      { l: 'Sore', icon: <Activity className="w-4 h-4 text-rose-500" /> }
                    ].map(item => (
                      <button
                        key={item.l}
                        type="button"
                        onClick={() => setDayLogMood(item.l)}
                        className={cn(
                          "flex flex-col items-center gap-1 p-2 rounded-xl border text-xs font-bold transition-all cursor-pointer",
                          dayLogMood === item.l ? "bg-pink-100 border-pink-300 text-pink-700" : "bg-white border-slate-100 text-slate-500"
                        )}
                      >
                        {item.icon}
                        <span>{t(item.l, item.l === 'Calm' ? 'ស្ងប់ស្ងាត់' : item.l === 'Happy' ? 'សប្បាយ' : item.l === 'Tired' ? 'ហត់នឿយ' : 'ឈឺខ្លួន')}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Logging input */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-[#8E6D7A] uppercase tracking-wider">{t('Symptoms or Health Notes', 'រោគសញ្ញា ឬកំណត់ចំណាំសុខភាព')}</label>
                  <textarea
                    rows={3}
                    placeholder={t('Example: Drank 8 glasses of water, slight dry throat...', 'ឧទាហរណ៍៖ បានផឹកទឹក៨កែវ មានអារម្មណ៍ស្ងួតកបន្តិច...')}
                    value={dayLogText}
                    onChange={(e) => setDayLogText(e.target.value)}
                    className="w-full bg-[#FFFAFC] border border-[#F2E4E9] rounded-xl p-3 text-xs focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary transition-all leading-relaxed"
                  />
                </div>

                {/* Actions */}
                <div className="grid grid-cols-2 gap-3 pt-2">
                  <button
                    onClick={handleClearDayLog}
                    className="bg-rose-50 text-rose-600 hover:bg-rose-100 p-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                    {t('Clear Notes', 'លុបចោល')}
                  </button>
                  <button
                    onClick={handleSaveDayLog}
                    className="bg-primary text-white hover:bg-primary-dark p-3 rounded-xl font-bold text-xs transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    {t('Save Log', 'រក្សាទុក')}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 2. HEALTH DIAGNOSTIC DRAWER */}
      <AnimatePresence>
        {showStatsDrawer && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowStatsDrawer(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-xs"
            />
            {/* Drawer Body */}
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              className="relative w-full sm:max-w-md bg-white rounded-t-[32px] sm:rounded-[36px] overflow-hidden shadow-2xl z-10 border border-[#F2E4E9] flex flex-col max-h-[85vh]"
            >
              <div className="p-6 border-b border-[#F2E4E9] flex items-center justify-between bg-gradient-to-r from-pink-50/20 to-pink-100/10 shrink-0">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-pink-100 flex items-center justify-center text-primary shadow-sm">
                    <Activity className="w-5 h-5 animate-pulse" />
                  </div>
                  <div>
                    <h3 className="font-serif font-black text-primary-dark text-lg">{t('Diagnostic Health Stats', 'ទិន្នន័យសុខភាពប្រចាំថ្ងៃ')}</h3>
                    <p className="text-[10px] text-[#8E6D7A] font-bold uppercase tracking-wider mt-0.5">{t('Wellness Parameters indicator', 'សូចនាករសុខភាពប្រចាំថ្ងៃ')}</p>
                  </div>
                </div>
                <button onClick={() => setShowStatsDrawer(false)} className="px-3.5 py-1.5 rounded-full text-xs font-bold text-slate-400 bg-slate-100 hover:bg-slate-200 cursor-pointer">
                  {t('Done', 'រួចរាល់')}
                </button>
              </div>

              <div className="p-6 overflow-y-auto space-y-5 text-sm">
                
                {/* 1. Pulse Rate card */}
                <div className="p-4 rounded-2xl bg-rose-50/50 border border-rose-100/50 flex items-center justify-between gap-5">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-[#FFF]/80 text-rose-500 flex items-center justify-center shadow-xs">
                      <Heart className="w-5 h-5 fill-rose-500 animate-pulse" />
                    </div>
                    <div>
                      <p className="text-xs text-[#8E6D7A] font-extrabold uppercase tracking-wide">{t('Average Pulse', 'ចង្វាក់បេះដូងមធ្យម')}</p>
                      <h4 className="text-xl font-serif font-black text-[#5C1D24]">78 BPM</h4>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xs bg-emerald-100 text-emerald-800 px-2.5 py-1 rounded-full font-bold uppercase tracking-wider">{t('Normal', 'ធម្មតា')}</span>
                  </div>
                </div>

                {/* 2. Hydration progress */}
                <div className="p-4 rounded-2xl bg-blue-50/50 border border-blue-100/50 space-y-3">
                  <div className="flex items-center justify-between gap-5">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-[#FFF]/80 text-blue-500 flex items-center justify-center shadow-xs">
                        <Droplet className="w-5 h-5 fill-blue-500" />
                      </div>
                      <div>
                        <p className="text-xs text-[#8E6D7A] font-extrabold uppercase tracking-wide">{t('Daily Hydration', 'ការញ៉ាំទឹកប្រចាំថ្ងៃ')}</p>
                        <h4 className="text-xl font-serif font-black text-[#1A4B6B]">{(waterCups * 0.25).toFixed(1)} / 2.5 Liters</h4>
                      </div>
                    </div>
                    <div className="flex bg-white rounded-lg p-0.5 border border-slate-100">
                      <button 
                        onClick={() => setWaterCups(Math.max(0, waterCups - 1))}
                        className="px-2.5 py-1 text-xs font-black hover:bg-slate-50 border-r border-slate-100 cursor-pointer"
                      >
                        -
                      </button>
                      <button 
                        onClick={() => setWaterCups(waterCups + 1)}
                        className="px-2.5 py-1 text-xs font-black hover:bg-slate-50 cursor-pointer text-blue-600"
                      >
                        +
                      </button>
                    </div>
                  </div>
                  <div className="relative w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div className="absolute top-0 left-0 bottom-0 bg-blue-500 transition-all duration-500" style={{ width: `${Math.min(100, (waterCups / 10) * 100)}%` }} />
                  </div>
                  <p className="text-[10px] text-[#8E6D7A] italic text-center">
                    {waterCups >= 10 ? t('🎉 Fully hydrated today!', '🎉 ញ៉ាំទឹកបានគ្រប់គ្រាន់សម្រាប់ថ្ងៃនេះ!') : t('Aim for 10 cups (2.5L) to balance peak temperature strain.', 'គួរញ៉ាំទឹកឲ្យបាន១០កែវ (២,៥លីត្រ) ដើម្បីទប់ទល់អាកាសធាតុក្តៅ។')}
                  </p>
                </div>

                {/* 3. Sleep parameters */}
                <div className="p-4 rounded-2xl bg-indigo-50/50 border border-indigo-100/50 space-y-3">
                  <div className="flex items-center justify-between gap-5">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-[#FFF]/80 text-indigo-500 flex items-center justify-center shadow-xs">
                        <Moon className="w-5 h-5 text-indigo-500 fill-indigo-500" />
                      </div>
                      <div>
                        <p className="text-xs text-[#8E6D7A] font-extrabold uppercase tracking-wide">{t('Sleep Tracking', 'លំដាប់ خواب ដំណេក')}</p>
                        <h4 className="text-xl font-serif font-black text-indigo-950">{sleepHours} Hours logged</h4>
                      </div>
                    </div>
                    <div className="flex bg-white rounded-lg p-0.5 border border-slate-100">
                      <button 
                        onClick={() => setSleepHours(Math.max(0, sleepHours - 1))}
                        className="px-2.5 py-1 text-xs font-black hover:bg-slate-50 border-r border-slate-100 cursor-pointer"
                      >
                        -
                      </button>
                      <button 
                        onClick={() => setSleepHours(sleepHours + 1)}
                        className="px-2.5 py-1 text-xs font-black hover:bg-slate-50 cursor-pointer text-indigo-600"
                      >
                        +
                      </button>
                    </div>
                  </div>
                  <p className="text-[10px] text-indigo-700 font-semibold italic text-center">
                    {sleepHours >= 7 && sleepHours <= 9 
                      ? t('✅ Optimal sleep duration recorded.', '✅ រយៈពេលនៃការគេងមានផាសុកភាពល្អ។') 
                      : t('Target between 7-9 hours daily for recovery.', 'ព្យាយាមគេងឲ្យបានយ៉ាងតិច ៧-៩ម៉ោង សម្រាប់ការស្តារកម្លាំងឡើងវិញ។')}
                  </p>
                </div>

              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 3. HEALTH ACTIVITIES LOGGER */}
      <AnimatePresence>
        {showActivitiesDrawer && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowActivitiesDrawer(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-xs"
            />
            {/* Drawer Body */}
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              className="relative w-full sm:max-w-md bg-white rounded-t-[32px] sm:rounded-[36px] overflow-hidden shadow-2xl z-10 border border-[#F2E4E9] flex flex-col max-h-[85vh]"
            >
              <div className="p-6 border-b border-[#F2E4E9] flex items-center justify-between bg-gradient-to-r from-pink-50/20 to-pink-100/10 shrink-0">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-pink-100 flex items-center justify-center text-primary shadow-sm">
                    <Footprints className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-serif font-black text-primary-dark text-lg">{t('Active Day Trackers', 'កត់ត្រាសកម្មភាពរាងកាយ')}</h3>
                    <p className="text-[10px] text-[#8E6D7A] font-bold uppercase tracking-wider mt-0.5">{t('Burn calorie and steps indicator', 'ការដុតបំផ្លាញកាឡូរី និងចម្ងាយដើរ')}</p>
                  </div>
                </div>
                <button onClick={() => setShowActivitiesDrawer(false)} className="px-3.5 py-1.5 rounded-full text-xs font-bold text-slate-400 bg-slate-100 hover:bg-slate-200 cursor-pointer">
                  {t('Done', 'រួចរាល់')}
                </button>
              </div>

              <div className="p-6 overflow-y-auto space-y-6 text-sm">
                
                {/* Steps tracker card */}
                <div className="bg-slate-50 p-5 rounded-3xl border border-slate-150 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs font-bold text-[#8E6D7A] uppercase tracking-wide">{t('Daily Walking Check', 'លំហាត់ប្រាណប្រចាំថ្ងៃ')}</p>
                      <h4 className="text-2xl font-serif font-black text-primary-dark">{stepCounts.toLocaleString()} {t('Steps', 'ជំហាន')}</h4>
                    </div>
                    <div className="flex gap-1.5 bg-white rounded-xl p-1 border border-slate-200">
                      <button onClick={() => setStepCounts(Math.max(0, stepCounts - 500))} className="px-2.5 py-1 text-xs font-black bg-slate-50 hover:bg-slate-100 rounded-lg cursor-pointer">-500</button>
                      <button onClick={() => setStepCounts(stepCounts + 1000)} className="px-2.5 py-1 text-xs font-black bg-pink-50 text-primary hover:bg-pink-100 rounded-lg cursor-pointer">+1000</button>
                    </div>
                  </div>
                  <div className="text-[11px] text-[#8E6D7A] flex items-center justify-between bg-white p-2.5 rounded-xl border border-slate-100">
                    <span>{t('Approx Distance:', 'ចម្ងាយប្រហាក់ប្រហែល៖')} <strong>{(stepCounts * 0.00075).toFixed(2)} km</strong></span>
                    <span>{t('Target:', 'គោលដៅ៖')} <strong>10,000 steps</strong></span>
                  </div>
                </div>

                {/* Calorie check card */}
                <div className="bg-orange-50/50 p-5 rounded-3xl border border-orange-100/50 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs font-bold text-[#8E6D7A] uppercase tracking-wide">{t('Calories Active Burn', 'កាឡូរីដែលបានដុតបំផ្លាញ')}</p>
                      <h4 className="text-2xl font-serif font-black text-orange-950">{caloriesBurned} kCal</h4>
                    </div>
                    <div className="flex gap-1.5 bg-white rounded-xl p-1 border border-slate-200">
                      <button onClick={() => setCaloriesBurned(Math.max(0, caloriesBurned - 50))} className="px-2.5 py-1 text-xs font-black bg-slate-50 hover:bg-slate-100 rounded-lg cursor-pointer">-50</button>
                      <button onClick={() => setCaloriesBurned(caloriesBurned + 100)} className="px-2.5 py-1 text-xs font-black bg-orange-50 text-orange-700 hover:bg-orange-100 rounded-lg cursor-pointer">+100</button>
                    </div>
                  </div>
                </div>

              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 4. LOCAL CAMBODIAN INSIGHT FEED READERS */}
      <AnimatePresence>
        {showFeedsDrawer && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowFeedsDrawer(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-xs"
            />
            {/* Drawer Body */}
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              className="relative w-full sm:max-w-md bg-white rounded-t-[32px] sm:rounded-[36px] overflow-hidden shadow-2xl z-10 border border-[#F2E4E9] flex flex-col max-h-[85vh]"
            >
              <div className="p-6 border-b border-[#F2E4E9] flex items-center justify-between bg-gradient-to-r from-pink-50/20 to-pink-100/10 shrink-0">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-pink-100 flex items-center justify-center text-primary shadow-sm">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-serif font-black text-primary-dark text-lg">{t('Health Feeds', 'ព័ត៌មាន និងការអប់រំសុខភាព')}</h3>
                    <p className="text-[10px] text-[#8E6D7A] font-bold uppercase tracking-wider mt-0.5">{t('Cambodian healthcare bulletins', 'អត្ថបទខ្លីប្រចាំថ្ងៃសម្រាប់យុវជនខ្មែរ')}</p>
                  </div>
                </div>
                <button onClick={() => setShowFeedsDrawer(false)} className="px-3.5 py-1.5 rounded-full text-xs font-bold text-slate-400 bg-slate-100 hover:bg-slate-200 cursor-pointer">
                  {t('Done', 'រួចរាល់')}
                </button>
              </div>

              <div className="p-6 overflow-y-auto space-y-4 text-sm">
                {localFeedArticles.map((art, idx) => (
                  <div 
                    key={idx}
                    onClick={() => setSelectedFeedIndex(selectedFeedIndex === idx ? null : idx)}
                    className="p-4 rounded-2xl bg-[#FFF]/40 border border-pink-150/40 hover:bg-pink-50/20 cursor-pointer transition-all space-y-2 group"
                  >
                    <div className="flex items-center justify-between text-[10px] font-bold text-[#8E6D7A] uppercase tracking-wide">
                      <span>{art.author}</span>
                      <span>{art.mins}</span>
                    </div>
                    <h4 className="font-serif font-black text-primary-dark text-base transition-colors group-hover:text-primary leading-tight">
                      {language === 'kh' ? art.titleKh : art.titleEn}
                    </h4>
                    <p className="text-xs text-[#8E6D7A] leading-relaxed">
                      {language === 'kh' ? art.descKh : art.descEn}
                    </p>

                    {selectedFeedIndex === idx && (
                      <motion.div 
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        className="pt-3 border-t border-dashed border-pink-200/40 text-xs italic text-[#4A3B43] font-medium"
                      >
                        {t(
                          art.textEn || 'Make sure to wash clean food containers, boil safe water feeds, avoid local standing water, and rest under cooling rooms.',
                          art.textKh || 'ត្រូវប្រាកដថាលាងទំលាប់សម្អាតអាងទឹក លាងបន្លែផ្លែឈើ ញ៉ាំទឹកឆ្អិន ជៀសវាងឈរក្រោមកម្តៅយូរ និងសម្រាកនៅកន្លែងត្រជាក់។'
                        )}
                      </motion.div>
                    )}
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 5. GUEST AUTH MODAL OVERLAY */}
      <AuthModal 
        isOpen={isAuthModalOpen} 
        onClose={() => setIsAuthModalOpen(false)} 
        onAuthSuccess={handleAuthChangeCallback} 
      />

    </div>
  );
}
