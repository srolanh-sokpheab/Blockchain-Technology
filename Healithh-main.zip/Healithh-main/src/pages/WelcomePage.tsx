/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, User, Mail, Lock, LogIn, UserPlus, CheckCircle, ShieldAlert, Sparkles, ChevronRight, HelpCircle } from 'lucide-react';
import { supabaseService } from '../services/supabaseService';
import { useLanguage } from '../context/LanguageContext';
import { cn } from '../utils';

interface WelcomePageProps {
  onAuthSuccess: () => void;
}

export default function WelcomePage({ onAuthSuccess }: WelcomePageProps) {
  const { language, setLanguage, t } = useLanguage();
  const [isRegister, setIsRegister] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');
    setLoading(true);

    if (!email.trim() || !password.trim()) {
      setError(t('Please fill in all fields.', 'សូមបំពេញព័ត៌មានដែលចាំបាច់ទាំងអស់។'));
      setLoading(false);
      return;
    }

    if (isRegister && !name.trim()) {
      setError(t('Please enter your name.', 'សូមបញ្ចូលឈ្មោះរបស់អ្នក។'));
      setLoading(false);
      return;
    }

    try {
      if (isRegister) {
        const res = await supabaseService.signUp(name, email, password);
        if (res.success) {
          setSuccessMsg(t('Registered successfully! Welcome to Healith.', 'ការចុះឈ្មោះបានជោគជ័យ! សូមស្វាគមន៍មកកាន់ Healith។'));
          setTimeout(() => {
            onAuthSuccess();
          }, 1200);
        } else {
          setError(res.error || t('Signup failed', 'ការចុះឈ្មោះបានបរាជ័យ'));
        }
      } else {
        const res = await supabaseService.signIn(email, password);
        if (res.success) {
          setSuccessMsg(t('Signed in successfully! Welcome back.', 'បានចូលគណនីដោយជោគជ័យ! សូមស្វាគមន៍មកវិញ។'));
          setTimeout(() => {
            onAuthSuccess();
          }, 1200);
        } else {
          setError(res.error || t('Invalid login details', 'អ៊ីមែល ឬលេខសម្ងាត់មិនត្រឹមត្រូវ'));
        }
      }
    } catch (err: any) {
      setError(err.message || t('An error occurred during authentication.', 'មានបញ្ហាខុសឆ្គងមួយបានកើតឡើង។'));
    } finally {
      setLoading(false);
    }
  };

  const handleGuestAccess = () => {
    // Generate standard test user as shown in mockups
    const demoUser = { id: 'demo_tester', name: 'Healith Tester', email: 'tester@healith.com' };
    localStorage.setItem('healith_current_user', JSON.stringify(demoUser));
    
    // Seed default patient details matching the mockup
    const defaultInfo = {
      age: '26 years',
      gender: 'Female',
      location: 'Sangkat Srah Chork, Phnom Penh'
    };
    
    localStorage.setItem('healith_patient_age_demo_tester', '26 years');
    localStorage.setItem('healith_patient_gender_demo_tester', 'Female');
    localStorage.setItem('healith_patient_location_demo_tester', 'Sangkat Srah Chork, Phnom Penh');
    
    onAuthSuccess();
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#FFF5F8] via-white to-[#FFF9FB] flex flex-col justify-between py-8 px-4 font-sans text-[#4A3B43]">
      
      {/* Top Bar for Language switching */}
      <div className="w-full max-w-md mx-auto flex justify-between items-center px-2">
        <div className="flex items-center gap-1.5 text-xs font-bold text-[#8E6D7A]">
          <Sparkles className="w-3.5 h-3.5 text-primary" />
          <span>HEALITH CAMBODIA</span>
        </div>
        
        {/* Language Pill */}
        <div className="flex bg-pink-50 rounded-full p-0.5 border border-[#F2E4E9]">
          <button
            onClick={() => setLanguage('en')}
            className={cn(
              "px-3 py-1 rounded-full text-[10px] font-black tracking-wide transition-all cursor-pointer",
              language === 'en' ? "bg-primary text-white shadow-sm" : "text-[#8E6D7A] hover:text-[#5F4651]"
            )}
          >
            English
          </button>
          <button
            onClick={() => setLanguage('kh')}
            className={cn(
              "px-3 py-1 rounded-full text-[10px] font-black tracking-wide transition-all cursor-pointer",
              language === 'kh' ? "bg-primary text-white shadow-sm" : "text-[#8E6D7A] hover:text-[#5F4651]"
            )}
          >
            ភាសាខ្មែរ
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="w-full max-w-md mx-auto my-auto py-6 space-y-8">
        
        {/* App Branding & Logo */}
        <div className="text-center space-y-3">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", stiffness: 100 }}
            className="w-20 h-20 rounded-[30px] bg-primary flex items-center justify-center mx-auto shadow-xl shadow-primary/20"
          >
            <Heart className="w-10 h-10 text-white fill-white animate-pulse" />
          </motion.div>
          
          <div className="space-y-1">
            <h1 className="text-3xl font-serif font-black text-primary-dark tracking-tight">
              Healith
            </h1>
            <p className="text-sm font-medium text-[#8E6D7A] max-w-[280px] mx-auto leading-relaxed">
              {t('Your smart digital medical handbook & AI companion.', 'មគ្គុទ្ទេសក៍សុខភាពឌីជីថលឆ្លាតវៃ និងជំនួយការ AI របស់អ្នក។')}
            </p>
          </div>
        </div>

        {/* Credentials Form Box */}
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1, duration: 0.4 }}
          className="bg-white rounded-[32px] p-6 shadow-xl shadow-rose-900/[0.02] border border-[#F2E4E9] space-y-6"
        >
          {/* Signin vs Register Toggle Tabs */}
          <div className="grid grid-cols-2 p-1 bg-[#FAF2F5] rounded-2xl border border-[#F2DCE4]">
            <button
              type="button"
              onClick={() => {
                setIsRegister(false);
                setError('');
                setSuccessMsg('');
              }}
              className={cn(
                "py-3 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5",
                !isRegister 
                  ? "bg-white text-primary-dark shadow-sm" 
                  : "text-[#8E6D7A] hover:text-[#5F4651]"
              )}
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>{t('Sign In', 'ចូលគណនី')}</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setIsRegister(true);
                setError('');
                setSuccessMsg('');
              }}
              className={cn(
                "py-3 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5",
                isRegister 
                  ? "bg-white text-primary-dark shadow-sm" 
                  : "text-[#8E6D7A] hover:text-[#5F4651]"
              )}
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>{t('Register', 'ចុះឈ្មោះ')}</span>
            </button>
          </div>

          {/* Form Prompts */}
          <form onSubmit={handleAuthSubmit} className="space-y-4">
            
            {/* Display status flags */}
            <AnimatePresence mode="wait">
              {error && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="p-3.5 rounded-2xl bg-rose-50 border border-rose-100 text-rose-700 text-xs flex items-center gap-2.5 overflow-hidden"
                >
                  <ShieldAlert className="w-4 h-4 shrink-0" />
                  <p className="font-semibold leading-normal">{error}</p>
                </motion.div>
              )}

              {successMsg && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-100 text-emerald-700 text-xs flex items-center gap-2.5 overflow-hidden"
                >
                  <CheckCircle className="w-4 h-4 shrink-0 animate-bounce" />
                  <p className="font-semibold leading-normal">{successMsg}</p>
                </motion.div>
              )}
            </AnimatePresence>

            {isRegister && (
              <div className="space-y-1">
                <label className="text-xs font-bold text-[#8E6D7A] uppercase tracking-wider pl-1">
                  {t('Full Name', 'ឈ្មោះពេញ')}
                </label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#D6BAC6]" />
                  <input
                    type="text"
                    required
                    placeholder={t('Enter your full name', 'បញ្ចូលឈ្មោះពេញរបស់អ្នក')}
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-[#FFFBFD] border border-[#F2E4E9] focus:border-primary rounded-2xl pl-12 pr-4 py-3.5 text-sm focus:outline-none focus:ring-4 focus:ring-primary/5 transition-all outline-none"
                  />
                </div>
              </div>
            )}

            <div className="space-y-1">
              <label className="text-xs font-bold text-[#8E6D7A] uppercase tracking-wider pl-1">
                {t('Email Address', 'អាសយដ្ឋានអ៊ីមែល')}
              </label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#D6BAC6]" />
                <input
                  type="email"
                  required
                  placeholder="yourname@gmail.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-[#FFFBFD] border border-[#F2E4E9] focus:border-primary rounded-2xl pl-12 pr-4 py-3.5 text-sm focus:outline-none focus:ring-4 focus:ring-primary/5 transition-all outline-none"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-[#8E6D7A] uppercase tracking-wider pl-1">
                {t('Password', 'លេខសម្ងាត់')}
              </label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#D6BAC6]" />
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-[#FFFBFD] border border-[#F2E4E9] focus:border-primary rounded-2xl pl-12 pr-4 py-3.5 text-sm focus:outline-none focus:ring-4 focus:ring-primary/5 transition-all outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-primary text-white p-4 rounded-2xl font-bold text-sm hover:bg-primary-dark transition-all active:scale-98 shadow-md shadow-primary/25 flex items-center justify-center gap-2 mt-4 cursor-pointer disabled:opacity-50"
            >
              {loading ? (
                <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  {isRegister ? <UserPlus className="w-4 h-4" /> : <LogIn className="w-4 h-4" />}
                  <span>{isRegister ? t('Create Free Account', 'ចុះឈ្មោះគណនីឥតគិតថ្លៃ') : t('Sign In to Continue', 'ចូលគណនីដើម្បីបន្ត')}</span>
                </>
              )}
            </button>
          </form>

          {/* Quick helper note */}
          <div className="pt-2 text-center text-[11px] text-[#A28290] leading-normal font-medium max-w-xs mx-auto">
            {t('Join thousands of Cambodian families accessing healthcare insights today.', 'ចូលរួមជាមួយក្រុមគ្រួសារខ្មែររាប់ពាន់នាក់ដើម្បីទទួលបានចំណេះដឹងសុខភាពនៅថ្ងៃនេះ។')}
          </div>
        </motion.div>

        {/* Guest Alternative Option */}
        <div className="text-center">
          <button
            onClick={handleGuestAccess}
            className="inline-flex items-center gap-1.5 text-xs text-[#8E6D7A] font-bold hover:text-primary transition-colors cursor-pointer py-2 px-4 rounded-xl hover:bg-[#FAF2F5]"
          >
            <span>{t('Continue as Guest / Local Mode', 'បន្តជាភ្ញៀវ / របៀបប្រើប្រាស់ក្នុងម៉ាស៊ីន')}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>

      {/* Cambodian Flag decorative ribbon and copyright */}
      <div className="w-full max-w-sm mx-auto text-center space-y-3 pt-4">
        {/* Real Cambodian Flag Ribbon */}
        <div className="flex justify-center items-center gap-1.5 opacity-85">
          <div className="h-1 w-8 bg-[#032F30] rounded-full" />
          <div className="h-1 w-12 bg-primary rounded-full" />
          <div className="h-1 w-8 bg-[#032F30] rounded-full" />
        </div>
        <p className="text-[10px] uppercase tracking-widest text-[#B299A4] font-bold">
          {t('Healith Digital Security • 2026', 'ប្រព័ន្ធសុវត្ថិភាពទិន្នន័យ Healith • ២០២៦')}
        </p>
      </div>

    </div>
  );
}
