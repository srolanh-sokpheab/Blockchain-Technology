/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ChatMessage } from "../types";

export class GeminiService {
  constructor() {
    // Safe empty constructor
  }

  async chat(message: string, history: ChatMessage[], patientInfo?: any): Promise<string> {
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ message, history, patientInfo }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return data.text || "";
    } catch (error) {
      console.error("Gemini Client Service Error:", error);
      throw error;
    }
  }
}

export const geminiService = new GeminiService();
