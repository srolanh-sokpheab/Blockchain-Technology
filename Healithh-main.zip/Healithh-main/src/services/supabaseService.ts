/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { ChatMessage } from '../types';

const SUPABASE_URL = (((import.meta as any).env?.VITE_SUPABASE_URL) || '').trim();
const SUPABASE_ANON_KEY = (((import.meta as any).env?.VITE_SUPABASE_ANON_KEY) || '').trim();

const isConfigured = Boolean(SUPABASE_URL) && 
                    Boolean(SUPABASE_ANON_KEY) && 
                    SUPABASE_URL !== 'YOUR_SUPABASE_URL' && 
                    SUPABASE_ANON_KEY !== 'YOUR_SUPABASE_ANON_KEY';

let supabase: SupabaseClient | null = null;

if (isConfigured) {
  try {
    supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
  } catch (error) {
    console.error('Supabase initialization failed:', error);
  }
}

let chatMessagesTableActive = true;
let bookmarksTableActive = true;

/**
 * Robust error handler that detects invalid Supabase API keys, JWT tokens,
 * network / fetch failures (e.g. "Failed to fetch"), CORS errors, expired sessions,
 * 401/403 authorization errors, and missing tables.
 * When any of these are encountered, it automatically sets `supabase = null`
 * so the entire service seamlessly and permanently falls back to local offline storage
 * without bothering the user or crashing the UI.
 */
function handleSupabaseError(error: any) {
  if (!error) return;
  const msg = (error.message || (typeof error === 'string' ? error : '') || '').toLowerCase();
  const status = error.status || error.code || 0;
  
  const isNetworkOrFetchError = 
    msg.includes('failed to fetch') ||
    msg.includes('fetch failed') ||
    msg.includes('networkerror') ||
    msg.includes('network error') ||
    msg.includes('network request failed') ||
    msg.includes('load failed') ||
    msg.includes('timeout') ||
    msg.includes('connection refused') ||
    msg.includes('cross-origin') ||
    msg.includes('cors') ||
    status === 0;

  const isAuthOrKeyError = 
    msg.includes('api key') || 
    msg.includes('invalid key') || 
    msg.includes('jwt') || 
    msg.includes('anon key') || 
    msg.includes('invalid token') ||
    msg.includes('invalid_api_key') ||
    msg.includes('auth session missing') ||
    status === 401 || 
    status === 403 ||
    status === 'PGRST301'; // Supabase status code for invalid API key / JWT

  const isSchemaError = 
    msg.includes('schema cache') || 
    msg.includes('does not exist') ||
    (msg.includes('relation') && msg.includes('does not exist'));

  if (isNetworkOrFetchError || isAuthOrKeyError || isSchemaError) {
    console.warn(`[Supabase Service fallback] Switching to offline local simulation due to: "${msg || status}".`);
    supabase = null;
    chatMessagesTableActive = false;
    bookmarksTableActive = false;
  }
}

export const supabaseService = {
  isConfigured: () => isConfigured && supabase !== null,
  getSupabaseUrl: () => SUPABASE_URL,
  isChatMessagesTableAvailable: () => chatMessagesTableActive,
  isBookmarksTableAvailable: () => bookmarksTableActive,
  
  // --- CHAT MESSAGES PERSISTENCE ---
  async getMessages(): Promise<ChatMessage[]> {
    if (!supabase || !chatMessagesTableActive) {
      // Fallback to localStorage
      const local = localStorage.getItem('healith_chat_history');
      return local ? JSON.parse(local) : [];
    }

    try {
      const { data, error } = await supabase
        .from('chat_messages')
        .select('*')
        .order('timestamp', { ascending: true });

      if (error) {
        handleSupabaseError(error);
        const local = localStorage.getItem('healith_chat_history');
        return local ? JSON.parse(local) : [];
      }

      return (data || []).map(item => ({
        id: item.id,
        role: item.role as 'user' | 'model',
        text: item.text,
        timestamp: Number(item.timestamp),
      }));
    } catch (e: any) {
      handleSupabaseError(e);
      const local = localStorage.getItem('healith_chat_history');
      return local ? JSON.parse(local) : [];
    }
  },

  async saveMessage(msg: ChatMessage): Promise<boolean> {
    // Always save to localStorage as a robust local copy
    try {
      const current = localStorage.getItem('healith_chat_history');
      const messages = current ? JSON.parse(current) : [];
      if (!messages.some((m: ChatMessage) => m.id === msg.id)) {
        messages.push(msg);
        localStorage.setItem('healith_chat_history', JSON.stringify(messages));
      }
    } catch (e) {
      console.error('Local save error:', e);
    }

    if (!supabase || !chatMessagesTableActive) return false;

    try {
      const { error } = await supabase
        .from('chat_messages')
        .insert([{
          id: msg.id,
          role: msg.role,
          text: msg.text,
          timestamp: msg.timestamp,
        }]);

      if (error) {
        handleSupabaseError(error);
        return false;
      }
      return true;
    } catch (e: any) {
      handleSupabaseError(e);
      return false;
    }
  },

  async clearMessages(): Promise<void> {
    localStorage.removeItem('healith_chat_history');
    if (!supabase || !chatMessagesTableActive) return;

    try {
      const { error } = await supabase.from('chat_messages').delete().neq('id', 'default-system-val-placeholder');
      if (error) {
        handleSupabaseError(error);
      }
    } catch (e) {
      handleSupabaseError(e);
    }
  },

  // --- BOOKMARKS (FAVORITE HOSPITALS / ARTICLES) ---
  async getBookmarks(): Promise<{ item_id: string; item_type: 'hospital' | 'article' }[]> {
    if (!supabase || !bookmarksTableActive) {
      const local = localStorage.getItem('healith_bookmarks_history');
      return local ? JSON.parse(local) : [];
    }

    try {
      const { data, error } = await supabase
        .from('bookmarks')
        .select('item_id, item_type');

      if (error) {
        handleSupabaseError(error);
        const local = localStorage.getItem('healith_bookmarks_history');
        return local ? JSON.parse(local) : [];
      }

      return data || [];
    } catch (e) {
      handleSupabaseError(e);
      const local = localStorage.getItem('healith_bookmarks_history');
      return local ? JSON.parse(local) : [];
    }
  },

  async toggleBookmark(itemId: string, itemType: 'hospital' | 'article'): Promise<boolean> {
    // Update local copy first
    let isBookmarkedLocal = false;
    try {
      const current = localStorage.getItem('healith_bookmarks_history');
      let bookmarks = current ? JSON.parse(current) : [];
      const index = bookmarks.findIndex((b: any) => b.item_id === itemId && b.item_type === itemType);
      
      if (index > -1) {
        bookmarks.splice(index, 1);
        isBookmarkedLocal = false;
      } else {
        bookmarks.push({ item_id: itemId, item_type: itemType });
        isBookmarkedLocal = true;
      }
      localStorage.setItem('healith_bookmarks_history', JSON.stringify(bookmarks));
    } catch (e) {
      console.error('Local bookmark toggle error:', e);
    }

    if (!supabase || !bookmarksTableActive) return isBookmarkedLocal;

    try {
      if (!isBookmarkedLocal) {
        const { error } = await supabase
          .from('bookmarks')
          .delete()
          .eq('item_id', itemId)
          .eq('item_type', itemType);

        if (error) {
          handleSupabaseError(error);
          return isBookmarkedLocal;
        }
      } else {
        const { error } = await supabase
          .from('bookmarks')
          .insert([{ item_id: itemId, item_type: itemType }]);

        if (error) {
          handleSupabaseError(error);
          return isBookmarkedLocal;
        }
      }
      return isBookmarkedLocal;
    } catch (e) {
      handleSupabaseError(e);
      return isBookmarkedLocal;
    }
  },

  // --- REGISTRATION / USER AUTH ---
  async signUp(name: string, email: string, password: string): Promise<{ success: boolean; error?: string; user?: any }> {
    const localSignUp = () => {
      const usersRaw = localStorage.getItem('healith_simulated_users');
      const users = usersRaw ? JSON.parse(usersRaw) : [];
      
      const existingUser = users.find((u: any) => u.email.toLowerCase() === email.toLowerCase());
      if (existingUser) {
        // Update user if already registered locally
        existingUser.name = name;
        existingUser.password = password;
      } else {
        const newUser = { id: 'u_' + Date.now(), name, email, password };
        users.push(newUser);
      }
      
      const targetUser = users.find((u: any) => u.email.toLowerCase() === email.toLowerCase()) || { id: 'u_' + Date.now(), name, email, password };
      localStorage.setItem('healith_simulated_users', JSON.stringify(users));
      const activeUser = { id: targetUser.id, name: targetUser.name, email: targetUser.email };
      localStorage.setItem('healith_current_user', JSON.stringify(activeUser));
      return { success: true, user: activeUser };
    };

    if (!supabase) {
      return localSignUp();
    }

    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: name,
          }
        }
      });

      if (error) {
        handleSupabaseError(error);
        if (!supabase) {
          return localSignUp();
        }
        return { success: false, error: error.message };
      }

      const activeUser = {
        id: data.user?.id || 'u_' + Date.now(),
        name: data.user?.user_metadata?.full_name || name,
        email: data.user?.email || email,
      };
      
      localStorage.setItem('healith_current_user', JSON.stringify(activeUser));
      return { success: true, user: activeUser };
    } catch (e: any) {
      handleSupabaseError(e);
      if (!supabase) {
        return localSignUp();
      }
      return { success: false, error: e.message || 'Signup failed' };
    }
  },

  async signIn(email: string, password: string): Promise<{ success: boolean; error?: string; user?: any }> {
    const localSignIn = () => {
      const usersRaw = localStorage.getItem('healith_simulated_users');
      const users = usersRaw ? JSON.parse(usersRaw) : [];
      let user = users.find((u: any) => u.email.toLowerCase() === email.toLowerCase());
      
      if (!user) {
        // If not found in local records, create the user profile automatically so they can seamlessly log in
        user = {
          id: 'u_' + Date.now(),
          name: email.split('@')[0].replace(/[^a-zA-Z0-9]/g, ' ').trim() || 'Member',
          email,
          password
        };
        users.push(user);
        localStorage.setItem('healith_simulated_users', JSON.stringify(users));
      } else if (user.password && user.password !== password) {
        return { success: false, error: 'Invalid email or password / អ៊ីមែល ឬពាក្យសម្ងាត់មិនត្រឹមត្រូវ' };
      }

      const activeUser = { id: user.id, name: user.name, email: user.email };
      localStorage.setItem('healith_current_user', JSON.stringify(activeUser));
      return { success: true, user: activeUser };
    };

    if (!supabase) {
      return localSignIn();
    }

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        handleSupabaseError(error);
        if (!supabase) {
          return localSignIn();
        }
        return { success: false, error: error.message };
      }

      const activeUser = {
        id: data.user?.id || '',
        name: data.user?.user_metadata?.full_name || data.user?.email?.split('@')[0] || 'User',
        email: data.user?.email || email,
      };
      
      localStorage.setItem('healith_current_user', JSON.stringify(activeUser));
      return { success: true, user: activeUser };
    } catch (e: any) {
      handleSupabaseError(e);
      if (!supabase) {
        return localSignIn();
      }
      return { success: false, error: e.message || 'Login failed' };
    }
  },

  async signOut(): Promise<void> {
    localStorage.removeItem('healith_current_user');
    if (supabase) {
      try {
        await supabase.auth.signOut();
      } catch (e) {
        console.error('Supabase signout failed:', e);
      }
    }
  },

  getCurrentUser(): { id: string; name: string; email: string } | null {
    const user = localStorage.getItem('healith_current_user');
    return user ? JSON.parse(user) : null;
  },

  async updateUser(name: string, email: string): Promise<{ success: boolean; error?: string; user?: any }> {
    const currentUserObj = this.getCurrentUser();
    if (!currentUserObj) {
      return { success: false, error: 'No user is currently logged in' };
    }

    const updatedUser = { ...currentUserObj, name, email };

    // 1. Local storage simulation update
    const usersRaw = localStorage.getItem('healith_simulated_users');
    if (usersRaw) {
      try {
        const users = JSON.parse(usersRaw);
        const index = users.findIndex((u: any) => u.id === currentUserObj.id);
        if (index > -1) {
          users[index] = { ...users[index], name, email };
          localStorage.setItem('healith_simulated_users', JSON.stringify(users));
        }
      } catch (e) {
        console.error('Error updating simulated user array:', e);
      }
    }

    // Always update current active user session
    localStorage.setItem('healith_current_user', JSON.stringify(updatedUser));

    // 2. Real Supabase auth update if configured
    if (supabase) {
      try {
        const { data: sessionData } = await supabase.auth.getSession();
        if (!sessionData || !sessionData.session) {
          // No active Supabase session (using local simulated user or demo system).
          // Success with simulated local state already saved!
          return { success: true, user: updatedUser };
        }

        const { data, error } = await supabase.auth.updateUser({
          email,
          data: { full_name: name }
        });

        if (error) {
          handleSupabaseError(error);
          if (!supabase) {
            return { success: true, user: updatedUser };
          }
          return { success: false, error: error.message };
        }

        const activeUser = {
          id: data.user?.id || updatedUser.id,
          name: data.user?.user_metadata?.full_name || name,
          email: data.user?.email || email,
        };
        localStorage.setItem('healith_current_user', JSON.stringify(activeUser));
        return { success: true, user: activeUser };
      } catch (e: any) {
        handleSupabaseError(e);
        // Fallback to local success if supabase errored out/fallback engaged
        if (!supabase) {
          return { success: true, user: updatedUser };
        }
        return { success: false, error: e.message || 'Failed to update remote user profile' };
      }
    }

    return { success: true, user: updatedUser };
  },

  // --- SQL SCHEMA HELPER INSTRUCTIONS ---
  getDatabaseSetupSQL(): string {
    return `-- Run this in your Supabase SQL Editor to prepare the database:

-- 1. Create chat_messages table to store helper conversations
create table if not exists chat_messages (
  id text primary key,
  role text not null,
  text text not null,
  timestamp bigint not null
);

-- Enable RLS & Row level security rules if wanted, or keep simple for public access:
alter table chat_messages enable row level security;
create policy "Allow public read/write access to messages"
  on chat_messages for all using (true);

-- 2. Create bookmarks table to store user-saved materials
create table if not exists bookmarks (
  id uuid default gen_random_uuid() primary key,
  item_id text not null,
  item_type text not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  unique (item_id, item_type)
);

alter table bookmarks enable row level security;
create policy "Allow public read/write access to bookmarks"
  on bookmarks for all using (true);
`;
  }
};
